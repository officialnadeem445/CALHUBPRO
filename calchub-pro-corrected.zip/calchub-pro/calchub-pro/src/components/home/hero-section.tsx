import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Calculator } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="py-20 px-4 text-center bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto max-w-4xl">
        <div className="flex justify-center mb-6">
          <Calculator className="h-16 w-16 text-primary" />
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          CalcHub Pro
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Your one-stop destination for fast, accurate online calculators and utilities.
          Perfect for students, creators, and professionals.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 max-w-md mx-auto">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Find a calculator..."
              className="pl-10 h-12"
            />
          </div>
          <Button size="lg" className="w-full sm:w-auto">
            Search
          </Button>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/calculators/age">
            <Button variant="outline" size="lg">
              Age Calculator
            </Button>
          </Link>
          <Link href="/calculators/bmi">
            <Button variant="outline" size="lg">
              BMI Calculator
            </Button>
          </Link>
          <Link href="/calculators/percentage">
            <Button variant="outline" size="lg">
              Percentage Calculator
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

