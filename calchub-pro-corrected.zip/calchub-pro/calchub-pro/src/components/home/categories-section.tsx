import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { categories, getCalculatorsByCategory } from '@/data/calculators';
import { 
  Calculator, 
  GraduationCap, 
  DollarSign, 
  Heart, 
  Clock, 
  Smile 
} from 'lucide-react';

const categoryIcons = {
  Calculator,
  GraduationCap,
  DollarSign,
  Heart,
  Clock,
  Smile,
};

export function CategoriesSection() {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Calculator Categories</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our comprehensive collection of calculators organized by category.
            From basic math to specialized financial and health calculations.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => {
            const IconComponent = categoryIcons[category.icon as keyof typeof categoryIcons];
            const calculators = getCalculatorsByCategory(category.id);
            
            return (
              <Link key={category.id} href={`/category/${category.id}`}>
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{category.name}</CardTitle>
                        <Badge variant="secondary" className="mt-1">
                          {calculators.length} calculators
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {calculators.slice(0, 3).map((calc) => (
                        <div key={calc.id} className="text-sm text-muted-foreground">
                          • {calc.title}
                        </div>
                      ))}
                      {calculators.length > 3 && (
                        <div className="text-sm text-muted-foreground">
                          • And {calculators.length - 3} more...
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

