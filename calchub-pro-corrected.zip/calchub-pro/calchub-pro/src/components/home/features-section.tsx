import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Zap, 
  Shield, 
  Smartphone, 
  Calculator, 
  Clock, 
  Users 
} from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Instant calculations with real-time results as you type.',
  },
  {
    icon: Shield,
    title: 'Privacy Focused',
    description: 'All calculations are performed locally. Your data never leaves your device.',
  },
  {
    icon: Smartphone,
    title: 'Mobile Friendly',
    description: 'Optimized for all devices with touch-friendly interfaces.',
  },
  {
    icon: Calculator,
    title: '21+ Calculators',
    description: 'Comprehensive collection covering math, finance, health, and more.',
  },
  {
    icon: Clock,
    title: 'Always Available',
    description: 'Access your favorite calculators 24/7 from anywhere.',
  },
  {
    icon: Users,
    title: 'Trusted by Thousands',
    description: 'Used by students, professionals, and businesses worldwide.',
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Why Choose CalcHub Pro?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built with modern technology and user experience in mind.
            Fast, reliable, and always accurate.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            
            return (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="mx-auto p-3 bg-primary/10 rounded-full w-fit">
                    <IconComponent className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

