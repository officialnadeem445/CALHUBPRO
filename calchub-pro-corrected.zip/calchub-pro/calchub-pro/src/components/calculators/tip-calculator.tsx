'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateTip, type TipResult } from '@/lib/utility-calculations';

export function TipCalculator() {
  const [billAmount, setBillAmount] = useState('');
  const [tipPercentage, setTipPercentage] = useState('18');
  const [numberOfPeople, setNumberOfPeople] = useState('1');
  const [result, setResult] = useState<TipResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tip-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setBillAmount(data.billAmount || '');
        setTipPercentage(data.tipPercentage || '18');
        setNumberOfPeople(data.numberOfPeople || '1');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('tip-calculator', JSON.stringify({ 
      billAmount, 
      tipPercentage, 
      numberOfPeople 
    }));
  }, [billAmount, tipPercentage, numberOfPeople]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!billAmount) {
      setError('Please enter bill amount');
      return;
    }

    const billNum = parseFloat(billAmount);
    const tipNum = parseFloat(tipPercentage);
    const peopleNum = parseInt(numberOfPeople);

    if (isNaN(billNum) || isNaN(tipNum) || isNaN(peopleNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (billNum <= 0) {
      setError('Bill amount must be greater than 0');
      return;
    }

    if (tipNum < 0) {
      setError('Tip percentage cannot be negative');
      return;
    }

    if (peopleNum <= 0) {
      setError('Number of people must be greater than 0');
      return;
    }

    try {
      const tipResult = calculateTip(billNum, tipNum, peopleNum);
      setResult(tipResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleQuickTip = (percentage: number) => {
    setTipPercentage(percentage.toString());
  };

  const formatResult = (result: TipResult) => {
    return `Tip: $${result.tipAmount}, Total: $${result.totalAmount}, Per Person: $${result.perPersonAmount}`;
  };

  const faqs = [
    {
      question: 'What is a standard tip percentage?',
      answer: 'Standard tip percentages vary by service: 15-20% for restaurants, 10-15% for food delivery, 15-20% for hair salons, and 15-20% for taxi/rideshare services.',
    },
    {
      question: 'Should I tip on the pre-tax or post-tax amount?',
      answer: 'It\'s generally acceptable to tip on either the pre-tax or post-tax amount. Many people tip on the pre-tax amount, but tipping on the total (post-tax) is also common and appreciated.',
    },
    {
      question: 'How do I split the bill evenly?',
      answer: 'Enter the total number of people in the "Number of People" field. The calculator will automatically divide the total amount (bill + tip) equally among all people.',
    },
  ];

  return (
    <CalculatorLayout
      title="Tip Calculator"
      description="Calculate tips and split bills easily"
      category="utility"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  ${result.tipAmount}
                </div>
                <div className="text-sm text-muted-foreground">Tip Amount</div>
              </div>
              
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  ${result.totalAmount}
                </div>
                <div className="text-sm text-muted-foreground">Total Amount</div>
              </div>
            </div>

            {parseInt(numberOfPeople) > 1 && (
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                    ${result.perPersonAmount}
                  </div>
                  <div className="text-sm text-muted-foreground">Per Person Total</div>
                </div>
                
                <div className="text-center p-4 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <div className="text-xl font-bold text-orange-600 dark:text-orange-400">
                    ${result.perPersonTip}
                  </div>
                  <div className="text-sm text-muted-foreground">Per Person Tip</div>
                </div>
              </div>
            )}

            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-lg">
                <span className="font-semibold">Bill:</span> ${parseFloat(billAmount).toFixed(2)} + 
                <span className="font-semibold"> Tip ({tipPercentage}%):</span> ${result.tipAmount} = 
                <span className="font-semibold"> Total:</span> ${result.totalAmount}
              </div>
              {parseInt(numberOfPeople) > 1 && (
                <div className="text-sm text-muted-foreground mt-2">
                  Split {numberOfPeople} ways
                </div>
              )}
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="billAmount">Bill Amount ($)</Label>
          <Input
            id="billAmount"
            type="number"
            value={billAmount}
            onChange={(e) => setBillAmount(e.target.value)}
            placeholder="e.g., 85.50"
            min="0"
            step="0.01"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipPercentage">Tip Percentage (%)</Label>
          <Input
            id="tipPercentage"
            type="number"
            value={tipPercentage}
            onChange={(e) => setTipPercentage(e.target.value)}
            placeholder="e.g., 18"
            min="0"
            max="100"
            step="0.1"
          />
          
          <div className="flex gap-2 mt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTip(15)}
              className="flex-1"
            >
              15%
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTip(18)}
              className="flex-1"
            >
              18%
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTip(20)}
              className="flex-1"
            >
              20%
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTip(25)}
              className="flex-1"
            >
              25%
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="numberOfPeople">Number of People</Label>
          <Input
            id="numberOfPeople"
            type="number"
            value={numberOfPeople}
            onChange={(e) => setNumberOfPeople(e.target.value)}
            placeholder="e.g., 4"
            min="1"
            max="50"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Tip
        </Button>
      </div>
    </CalculatorLayout>
  );
}

