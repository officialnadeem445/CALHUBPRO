'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { generatePassword, type PasswordOptions, type PasswordResult } from '@/lib/utility-calculations';

export function PasswordGenerator() {
  const [options, setOptions] = useState<PasswordOptions>({
    length: 12,
    includeUppercase: true,
    includeLowercase: true,
    includeNumbers: true,
    includeSymbols: true,
    excludeSimilar: false,
    excludeAmbiguous: false,
  });
  const [result, setResult] = useState<PasswordResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('password-generator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setOptions({ ...options, ...data });
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('password-generator', JSON.stringify(options));
  }, [options]);

  const handleGenerate = () => {
    setError('');
    setResult(null);

    try {
      const passwordResult = generatePassword(options);
      setResult(passwordResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const updateOption = <K extends keyof PasswordOptions>(
    key: K,
    value: PasswordOptions[K]
  ) => {
    setOptions(prev => ({ ...prev, [key]: value }));
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Very Weak': return 'text-red-600 dark:text-red-400';
      case 'Weak': return 'text-orange-600 dark:text-orange-400';
      case 'Fair': return 'text-yellow-600 dark:text-yellow-400';
      case 'Good': return 'text-blue-600 dark:text-blue-400';
      case 'Strong': return 'text-green-600 dark:text-green-400';
      case 'Very Strong': return 'text-emerald-600 dark:text-emerald-400';
      default: return 'text-muted-foreground';
    }
  };

  const getStrengthBg = (strength: string) => {
    switch (strength) {
      case 'Very Weak': return 'bg-red-50 dark:bg-red-950';
      case 'Weak': return 'bg-orange-50 dark:bg-orange-950';
      case 'Fair': return 'bg-yellow-50 dark:bg-yellow-950';
      case 'Good': return 'bg-blue-50 dark:bg-blue-950';
      case 'Strong': return 'bg-green-50 dark:bg-green-950';
      case 'Very Strong': return 'bg-emerald-50 dark:bg-emerald-950';
      default: return 'bg-muted';
    }
  };

  const faqs = [
    {
      question: 'What makes a password strong?',
      answer: 'A strong password is long (12+ characters), uses a mix of uppercase, lowercase, numbers, and symbols, and avoids common patterns or dictionary words.',
    },
    {
      question: 'Should I exclude similar characters?',
      answer: 'Excluding similar characters (like 0/O, 1/l/I) can help avoid confusion when typing passwords manually, especially for passwords that need to be shared or written down.',
    },
    {
      question: 'How is password strength calculated?',
      answer: 'Strength is based on length, character variety, and entropy. Longer passwords with more character types are stronger. We also check for common patterns that reduce security.',
    },
  ];

  return (
    <CalculatorLayout
      title="Password Generator"
      description="Generate secure passwords with customizable options"
      category="utility"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <div className="font-mono text-lg break-all select-all">
                {result.password}
              </div>
            </div>
            
            <div className={`text-center p-4 rounded-lg ${getStrengthBg(result.strength)}`}>
              <div className={`text-xl font-bold ${getStrengthColor(result.strength)}`}>
                {result.strength}
              </div>
              <div className="text-sm text-muted-foreground">Password Strength</div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.entropy.toFixed(1)}</div>
                <div className="text-sm text-muted-foreground">Entropy (bits)</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.estimatedCrackTime}</div>
                <div className="text-sm text-muted-foreground">Crack Time</div>
              </div>
            </div>

            <div className="space-y-2">
              <CopyButton text={result.password} className="w-full">
                Copy Password
              </CopyButton>
              <Button onClick={handleGenerate} variant="outline" className="w-full">
                Generate New Password
              </Button>
            </div>
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Password Length: {options.length}</Label>
          <Slider
            value={[options.length]}
            onValueChange={(value) => updateOption('length', value[0])}
            min={4}
            max={128}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>4</span>
            <span>128</span>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Character Types</Label>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="uppercase"
              checked={options.includeUppercase}
              onCheckedChange={(checked) => updateOption('includeUppercase', !!checked)}
            />
            <Label htmlFor="uppercase" className="text-sm">
              Uppercase Letters (A-Z)
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="lowercase"
              checked={options.includeLowercase}
              onCheckedChange={(checked) => updateOption('includeLowercase', !!checked)}
            />
            <Label htmlFor="lowercase" className="text-sm">
              Lowercase Letters (a-z)
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="numbers"
              checked={options.includeNumbers}
              onCheckedChange={(checked) => updateOption('includeNumbers', !!checked)}
            />
            <Label htmlFor="numbers" className="text-sm">
              Numbers (0-9)
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="symbols"
              checked={options.includeSymbols}
              onCheckedChange={(checked) => updateOption('includeSymbols', !!checked)}
            />
            <Label htmlFor="symbols" className="text-sm">
              Symbols (!@#$%^&*)
            </Label>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Advanced Options</Label>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="excludeSimilar"
              checked={options.excludeSimilar}
              onCheckedChange={(checked) => updateOption('excludeSimilar', !!checked)}
            />
            <Label htmlFor="excludeSimilar" className="text-sm">
              Exclude Similar Characters (0, O, 1, l, I)
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="excludeAmbiguous"
              checked={options.excludeAmbiguous}
              onCheckedChange={(checked) => updateOption('excludeAmbiguous', !!checked)}
            />
            <Label htmlFor="excludeAmbiguous" className="text-sm">
              Exclude Ambiguous Symbols ({`{ } [ ] ( ) / \\ ' " ~ , ; . < >`})
            </Label>
          </div>
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleGenerate} className="w-full">
          Generate Password
        </Button>
      </div>
    </CalculatorLayout>
  );
}

