'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';

export function ScientificCalculator() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);

      setDisplay(String(newValue));
      setPreviousValue(newValue);
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case '+':
        return firstValue + secondValue;
      case '-':
        return firstValue - secondValue;
      case '*':
        return firstValue * secondValue;
      case '/':
        return firstValue / secondValue;
      case '=':
        return secondValue;
      default:
        return secondValue;
    }
  };

  const performScientificOperation = (func: string) => {
    const inputValue = parseFloat(display);
    let result: number;

    switch (func) {
      case 'sin':
        result = Math.sin(inputValue * Math.PI / 180);
        break;
      case 'cos':
        result = Math.cos(inputValue * Math.PI / 180);
        break;
      case 'tan':
        result = Math.tan(inputValue * Math.PI / 180);
        break;
      case 'log':
        result = Math.log10(inputValue);
        break;
      case 'ln':
        result = Math.log(inputValue);
        break;
      case 'sqrt':
        result = Math.sqrt(inputValue);
        break;
      case 'square':
        result = inputValue * inputValue;
        break;
      case 'cube':
        result = inputValue * inputValue * inputValue;
        break;
      case 'factorial':
        result = factorial(inputValue);
        break;
      case 'reciprocal':
        result = 1 / inputValue;
        break;
      case 'pi':
        result = Math.PI;
        break;
      case 'e':
        result = Math.E;
        break;
      default:
        return;
    }

    setDisplay(String(result));
    setWaitingForOperand(true);
  };

  const factorial = (n: number): number => {
    if (n < 0 || !Number.isInteger(n)) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  };

  const faqs = [
    {
      question: 'How do I use trigonometric functions?',
      answer: 'Enter an angle in degrees and click sin, cos, or tan. The calculator automatically converts degrees to radians for calculation.',
    },
    {
      question: 'What is the difference between log and ln?',
      answer: 'log is the base-10 logarithm (common logarithm), while ln is the natural logarithm (base-e logarithm).',
    },
    {
      question: 'How do I calculate powers other than square or cube?',
      answer: 'For now, use the multiplication function repeatedly. Future versions will include a power function.',
    },
  ];

  return (
    <CalculatorLayout
      title="Scientific Calculator"
      description="Advanced calculator with scientific functions"
      category="basic"
      faqs={faqs}
      result={
        <div className="space-y-4">
          <div className="text-center p-4 bg-primary/10 rounded-lg">
            <div className="text-2xl font-bold text-primary break-all">
              {display}
            </div>
          </div>
          <CopyButton text={display} className="w-full" />
        </div>
      }
    >
      <div className="space-y-4">
        {/* Display */}
        <Input
          type="text"
          value={display}
          readOnly
          className="text-right text-xl font-mono h-12"
        />

        {/* Scientific Functions */}
        <div className="grid grid-cols-4 gap-2">
          <Button variant="outline" onClick={() => performScientificOperation('sin')}>
            sin
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('cos')}>
            cos
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('tan')}>
            tan
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('log')}>
            log
          </Button>
          
          <Button variant="outline" onClick={() => performScientificOperation('ln')}>
            ln
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('sqrt')}>
            √
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('square')}>
            x²
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('cube')}>
            x³
          </Button>
          
          <Button variant="outline" onClick={() => performScientificOperation('factorial')}>
            x!
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('reciprocal')}>
            1/x
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('pi')}>
            π
          </Button>
          <Button variant="outline" onClick={() => performScientificOperation('e')}>
            e
          </Button>
        </div>

        {/* Basic Calculator */}
        <div className="grid grid-cols-4 gap-2">
          <Button variant="destructive" onClick={clear} className="col-span-2">
            Clear
          </Button>
          <Button variant="outline" onClick={() => performOperation('/')}>
            ÷
          </Button>
          <Button variant="outline" onClick={() => performOperation('*')}>
            ×
          </Button>

          <Button variant="outline" onClick={() => inputDigit('7')}>
            7
          </Button>
          <Button variant="outline" onClick={() => inputDigit('8')}>
            8
          </Button>
          <Button variant="outline" onClick={() => inputDigit('9')}>
            9
          </Button>
          <Button variant="outline" onClick={() => performOperation('-')}>
            -
          </Button>

          <Button variant="outline" onClick={() => inputDigit('4')}>
            4
          </Button>
          <Button variant="outline" onClick={() => inputDigit('5')}>
            5
          </Button>
          <Button variant="outline" onClick={() => inputDigit('6')}>
            6
          </Button>
          <Button variant="outline" onClick={() => performOperation('+')}>
            +
          </Button>

          <Button variant="outline" onClick={() => inputDigit('1')}>
            1
          </Button>
          <Button variant="outline" onClick={() => inputDigit('2')}>
            2
          </Button>
          <Button variant="outline" onClick={() => inputDigit('3')}>
            3
          </Button>
          <Button 
            className="row-span-2" 
            onClick={() => performOperation('=')}
          >
            =
          </Button>

          <Button variant="outline" onClick={() => inputDigit('0')} className="col-span-2">
            0
          </Button>
          <Button variant="outline" onClick={inputDecimal}>
            .
          </Button>
        </div>
      </div>
    </CalculatorLayout>
  );
}

