'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateBMI, type BMIResult } from '@/lib/calculations';

export function BMICalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [result, setResult] = useState<BMIResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('bmi-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setWeight(data.weight || '');
        setHeight(data.height || '');
        setUnit(data.unit || 'metric');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('bmi-calculator', JSON.stringify({ weight, height, unit }));
  }, [weight, height, unit]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!weight || !height) {
      setError('Please enter both weight and height');
      return;
    }

    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height);

    if (isNaN(weightNum) || isNaN(heightNum) || weightNum <= 0 || heightNum <= 0) {
      setError('Please enter valid positive numbers');
      return;
    }

    try {
      const bmiResult = calculateBMI(weightNum, heightNum, unit);
      setResult(bmiResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: BMIResult) => {
    const weightUnit = unit === 'metric' ? 'kg' : 'lbs';
    return `BMI: ${result.bmi} (${result.category}). Healthy weight range: ${result.healthyWeightRange.min}-${result.healthyWeightRange.max} ${weightUnit}`;
  };

  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return 'text-blue-600';
    if (bmi < 25) return 'text-green-600';
    if (bmi < 30) return 'text-yellow-600';
    return 'text-red-600';
  };

  const faqs = [
    {
      question: 'What is BMI?',
      answer: 'Body Mass Index (BMI) is a measure of body fat based on height and weight. It\'s used as a screening tool to identify possible weight problems in adults.',
    },
    {
      question: 'What are the BMI categories?',
      answer: 'Underweight: Below 18.5, Normal weight: 18.5-24.9, Overweight: 25-29.9, Obese: 30 and above. These are general guidelines and may not apply to all individuals.',
    },
    {
      question: 'Is BMI accurate for everyone?',
      answer: 'BMI is a useful screening tool but has limitations. It doesn\'t distinguish between muscle and fat mass, so athletes or very muscular people may have high BMI despite being healthy.',
    },
  ];

  return (
    <CalculatorLayout
      title="BMI Calculator"
      description="Calculate your Body Mass Index and health status"
      category="health"
      faqs={faqs}
      disclaimer="This calculator provides general health information only and is not a substitute for professional medical advice. Consult with a healthcare provider for personalized health guidance."
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className={`text-3xl font-bold ${getBMIColor(result.bmi)}`}>
                {result.bmi}
              </div>
              <div className="text-lg font-semibold mt-2">{result.category}</div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm">
                <strong>Healthy weight range:</strong> {result.healthyWeightRange.min} - {result.healthyWeightRange.max} {unit === 'metric' ? 'kg' : 'lbs'}
              </p>
              
              {result.weightToLose && (
                <p className="text-sm text-orange-600">
                  To reach healthy weight, consider losing approximately {result.weightToLose} {unit === 'metric' ? 'kg' : 'lbs'}
                </p>
              )}
              
              {result.weightToGain && (
                <p className="text-sm text-blue-600">
                  To reach healthy weight, consider gaining approximately {result.weightToGain} {unit === 'metric' ? 'kg' : 'lbs'}
                </p>
              )}
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="unit">Unit System</Label>
          <Select value={unit} onValueChange={(value: 'metric' | 'imperial') => setUnit(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="metric">Metric (kg, cm)</SelectItem>
              <SelectItem value="imperial">Imperial (lbs, inches)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="weight">
            Weight ({unit === 'metric' ? 'kg' : 'lbs'})
          </Label>
          <Input
            id="weight"
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder={unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
            min="0"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="height">
            Height ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="height"
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder={unit === 'metric' ? 'e.g., 175' : 'e.g., 69'}
            min="0"
            step="0.1"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate BMI
        </Button>
      </div>
    </CalculatorLayout>
  );
}

