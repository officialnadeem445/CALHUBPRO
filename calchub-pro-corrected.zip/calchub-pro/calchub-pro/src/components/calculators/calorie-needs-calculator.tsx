'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  calculateCalorieNeeds, 
  poundsToKg, 
  feetInchesToCm,
  type CalorieNeedsResult,
  type ActivityLevel,
  type Gender 
} from '@/lib/health-calculations';

export function CalorieNeedsCalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<Gender>('male');
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>('moderate');
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lbs'>('lbs');
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft'>('ft');
  const [feet, setFeet] = useState('');
  const [inches, setInches] = useState('');
  const [result, setResult] = useState<CalorieNeedsResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('calorie-needs-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setWeight(data.weight || '');
        setHeight(data.height || '');
        setAge(data.age || '');
        setGender(data.gender || 'male');
        setActivityLevel(data.activityLevel || 'moderate');
        setWeightUnit(data.weightUnit || 'lbs');
        setHeightUnit(data.heightUnit || 'ft');
        setFeet(data.feet || '');
        setInches(data.inches || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('calorie-needs-calculator', JSON.stringify({ 
      weight, 
      height, 
      age, 
      gender, 
      activityLevel,
      weightUnit,
      heightUnit,
      feet,
      inches
    }));
  }, [weight, height, age, gender, activityLevel, weightUnit, heightUnit, feet, inches]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!weight || !age) {
      setError('Please enter weight and age');
      return;
    }

    let heightInCm: number;
    if (heightUnit === 'ft') {
      if (!feet) {
        setError('Please enter height in feet');
        return;
      }
      const feetNum = parseFloat(feet);
      const inchesNum = parseFloat(inches) || 0;
      if (isNaN(feetNum) || feetNum <= 0) {
        setError('Please enter valid height');
        return;
      }
      heightInCm = feetInchesToCm(feetNum, inchesNum);
    } else {
      if (!height) {
        setError('Please enter height in centimeters');
        return;
      }
      heightInCm = parseFloat(height);
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError('Please enter valid height');
        return;
      }
    }

    const weightNum = parseFloat(weight);
    const ageNum = parseFloat(age);

    if (isNaN(weightNum) || isNaN(ageNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (weightNum <= 0 || ageNum <= 0 || heightInCm <= 0) {
      setError('Weight, height, and age must be positive numbers');
      return;
    }

    try {
      const weightInKg = weightUnit === 'lbs' ? poundsToKg(weightNum) : weightNum;
      const calorieResult = calculateCalorieNeeds(weightInKg, heightInCm, ageNum, gender, activityLevel);
      setResult(calorieResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: CalorieNeedsResult) => {
    return `BMR: ${result.bmr} calories, TDEE: ${result.tdee} calories, Maintenance: ${result.maintenanceCalories} calories`;
  };

  const faqs = [
    {
      question: 'What is BMR?',
      answer: 'BMR (Basal Metabolic Rate) is the number of calories your body needs to maintain basic physiological functions at rest, such as breathing, circulation, and cell production.',
    },
    {
      question: 'What is TDEE?',
      answer: 'TDEE (Total Daily Energy Expenditure) is your BMR plus the calories burned through physical activity and exercise. This represents your total daily calorie needs.',
    },
    {
      question: 'How accurate are these calculations?',
      answer: 'These calculations use the Mifflin-St Jeor equation, which is considered one of the most accurate formulas. However, individual metabolism can vary by ±10-15%.',
    },
  ];

  return (
    <CalculatorLayout
      title="Calorie Needs Calculator"
      description="Calculate BMR and daily calorie needs"
      category="health"
      faqs={faqs}
      disclaimer="This calculator provides estimates based on standard formulas. Individual calorie needs may vary. Consult a healthcare professional for personalized nutrition advice."
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {result.bmr}
                </div>
                <div className="text-sm text-muted-foreground">BMR (Basal Metabolic Rate)</div>
                <div className="text-xs text-muted-foreground mt-1">Calories at rest</div>
              </div>
              
              <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {result.tdee}
                </div>
                <div className="text-sm text-muted-foreground">TDEE (Total Daily Energy)</div>
                <div className="text-xs text-muted-foreground mt-1">Including activity</div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-xl font-bold text-primary">{result.maintenanceCalories}</div>
                <div className="text-sm text-muted-foreground">Maintenance Calories</div>
                <div className="text-xs text-muted-foreground">To maintain current weight</div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-3 bg-red-50 dark:bg-red-950 rounded-lg">
                  <div className="text-lg font-bold text-red-600 dark:text-red-400">
                    {result.weightLossCalories}
                  </div>
                  <div className="text-sm text-muted-foreground">Weight Loss</div>
                  <div className="text-xs text-muted-foreground">~1 lb/week loss</div>
                </div>
                
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <div className="text-lg font-bold text-orange-600 dark:text-orange-400">
                    {result.weightGainCalories}
                  </div>
                  <div className="text-sm text-muted-foreground">Weight Gain</div>
                  <div className="text-xs text-muted-foreground">~1 lb/week gain</div>
                </div>
              </div>
            </div>

            <div className="text-center text-sm text-muted-foreground">
              Activity Level: {result.activityLevel}
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="gender">Gender</Label>
            <Select value={gender} onValueChange={(value: Gender) => setGender(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="age">Age (years)</Label>
            <Input
              id="age"
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="e.g., 30"
              min="1"
              max="120"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Weight</Label>
          <div className="flex gap-2">
            <Input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder={weightUnit === 'kg' ? 'e.g., 70' : 'e.g., 154'}
              min="1"
              step="0.1"
              className="flex-1"
            />
            <Select value={weightUnit} onValueChange={(value: 'kg' | 'lbs') => setWeightUnit(value)}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="kg">kg</SelectItem>
                <SelectItem value="lbs">lbs</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Height</Label>
          <div className="flex gap-2">
            {heightUnit === 'ft' ? (
              <>
                <Input
                  type="number"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)}
                  placeholder="Feet"
                  min="1"
                  max="8"
                  className="flex-1"
                />
                <Input
                  type="number"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)}
                  placeholder="Inches"
                  min="0"
                  max="11"
                  className="flex-1"
                />
              </>
            ) : (
              <Input
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="e.g., 175"
                min="1"
                max="250"
                className="flex-1"
              />
            )}
            <Select value={heightUnit} onValueChange={(value: 'cm' | 'ft') => setHeightUnit(value)}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ft">ft/in</SelectItem>
                <SelectItem value="cm">cm</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="activityLevel">Activity Level</Label>
          <Select value={activityLevel} onValueChange={(value: ActivityLevel) => setActivityLevel(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
              <SelectItem value="light">Light (light exercise 1-3 days/week)</SelectItem>
              <SelectItem value="moderate">Moderate (moderate exercise 3-5 days/week)</SelectItem>
              <SelectItem value="active">Active (hard exercise 6-7 days/week)</SelectItem>
              <SelectItem value="very_active">Very Active (very hard exercise, physical job)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Calorie Needs
        </Button>
      </div>
    </CalculatorLayout>
  );
}

