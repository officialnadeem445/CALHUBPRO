'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateEMI, generateAmortizationCSV, downloadCSV, type EMIResult } from '@/lib/finance-calculations';
import { Download, Eye, EyeOff } from 'lucide-react';

export function LoanEMICalculator() {
  const [principal, setPrincipal] = useState('');
  const [annualRate, setAnnualRate] = useState('');
  const [tenureYears, setTenureYears] = useState('');
  const [result, setResult] = useState<EMIResult | null>(null);
  const [error, setError] = useState('');
  const [showSchedule, setShowSchedule] = useState(false);

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('loan-emi-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setPrincipal(data.principal || '');
        setAnnualRate(data.annualRate || '');
        setTenureYears(data.tenureYears || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('loan-emi-calculator', JSON.stringify({ 
      principal, 
      annualRate, 
      tenureYears 
    }));
  }, [principal, annualRate, tenureYears]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!principal || !annualRate || !tenureYears) {
      setError('Please fill in all fields');
      return;
    }

    const principalNum = parseFloat(principal);
    const rateNum = parseFloat(annualRate);
    const tenureNum = parseFloat(tenureYears);

    if (isNaN(principalNum) || isNaN(rateNum) || isNaN(tenureNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (principalNum <= 0 || rateNum < 0 || tenureNum <= 0) {
      setError('Principal and tenure must be positive, rate cannot be negative');
      return;
    }

    try {
      const emiResult = calculateEMI(principalNum, rateNum, tenureNum * 12);
      setResult(emiResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleDownloadCSV = () => {
    if (!result) return;
    
    const csvContent = generateAmortizationCSV(result.amortizationSchedule);
    const filename = `loan_amortization_${new Date().toISOString().split('T')[0]}.csv`;
    downloadCSV(csvContent, filename);
  };

  const formatResult = (result: EMIResult) => {
    return `EMI: $${result.emi}, Total Amount: $${result.totalAmount}, Total Interest: $${result.totalInterest}`;
  };

  const faqs = [
    {
      question: 'What is EMI?',
      answer: 'EMI (Equated Monthly Installment) is a fixed payment amount made by a borrower to a lender at a specified date each calendar month.',
    },
    {
      question: 'How is EMI calculated?',
      answer: 'EMI is calculated using the formula: P × r × (1 + r)^n / ((1 + r)^n - 1), where P is principal, r is monthly interest rate, and n is number of months.',
    },
    {
      question: 'What is an amortization schedule?',
      answer: 'An amortization schedule is a table showing each loan payment over time, breaking down how much goes toward principal and interest.',
    },
  ];

  return (
    <CalculatorLayout
      title="Loan EMI Calculator"
      description="Calculate loan EMI with amortization schedule"
      category="finance"
      faqs={faqs}
      disclaimer="This calculator provides estimates for educational purposes. Actual loan terms may vary based on lender policies and individual circumstances."
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">${result.emi}</div>
                <div className="text-sm text-muted-foreground">Monthly EMI</div>
              </div>
              <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  ${result.totalAmount}
                </div>
                <div className="text-sm text-muted-foreground">Total Amount</div>
              </div>
              <div className="text-center p-4 bg-red-50 dark:bg-red-950 rounded-lg">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                  ${result.totalInterest}
                </div>
                <div className="text-sm text-muted-foreground">Total Interest</div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowSchedule(!showSchedule)}
                className="flex-1"
              >
                {showSchedule ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
                {showSchedule ? 'Hide' : 'Show'} Schedule
              </Button>
              <Button variant="outline" onClick={handleDownloadCSV}>
                <Download className="h-4 w-4 mr-2" />
                Download CSV
              </Button>
            </div>

            {showSchedule && (
              <div className="max-h-96 overflow-y-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="p-2 text-left">Month</th>
                      <th className="p-2 text-right">EMI</th>
                      <th className="p-2 text-right">Principal</th>
                      <th className="p-2 text-right">Interest</th>
                      <th className="p-2 text-right">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.amortizationSchedule.map((entry) => (
                      <tr key={entry.month} className="border-t">
                        <td className="p-2">{entry.month}</td>
                        <td className="p-2 text-right">${entry.emi}</td>
                        <td className="p-2 text-right">${entry.principalPayment}</td>
                        <td className="p-2 text-right">${entry.interestPayment}</td>
                        <td className="p-2 text-right">${entry.remainingBalance}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="principal">Loan Amount ($)</Label>
          <Input
            id="principal"
            type="number"
            value={principal}
            onChange={(e) => setPrincipal(e.target.value)}
            placeholder="e.g., 250000"
            min="0"
            step="1000"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="annualRate">Annual Interest Rate (%)</Label>
          <Input
            id="annualRate"
            type="number"
            value={annualRate}
            onChange={(e) => setAnnualRate(e.target.value)}
            placeholder="e.g., 7.5"
            min="0"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tenureYears">Loan Tenure (years)</Label>
          <Input
            id="tenureYears"
            type="number"
            value={tenureYears}
            onChange={(e) => setTenureYears(e.target.value)}
            placeholder="e.g., 20"
            min="0"
            step="1"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate EMI
        </Button>
      </div>
    </CalculatorLayout>
  );
}

