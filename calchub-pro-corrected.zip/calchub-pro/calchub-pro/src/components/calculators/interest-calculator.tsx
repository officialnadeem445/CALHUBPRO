'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateInterest, type InterestResult } from '@/lib/calculations';

export function InterestCalculator() {
  const [principal, setPrincipal] = useState('');
  const [rate, setRate] = useState('');
  const [time, setTime] = useState('');
  const [compoundFrequency, setCompoundFrequency] = useState('1');
  const [result, setResult] = useState<InterestResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('interest-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setPrincipal(data.principal || '');
        setRate(data.rate || '');
        setTime(data.time || '');
        setCompoundFrequency(data.compoundFrequency || '1');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('interest-calculator', JSON.stringify({ 
      principal, 
      rate, 
      time, 
      compoundFrequency 
    }));
  }, [principal, rate, time, compoundFrequency]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!principal || !rate || !time) {
      setError('Please enter principal, rate, and time');
      return;
    }

    const principalNum = parseFloat(principal);
    const rateNum = parseFloat(rate);
    const timeNum = parseFloat(time);
    const frequencyNum = parseInt(compoundFrequency);

    if (isNaN(principalNum) || isNaN(rateNum) || isNaN(timeNum) || principalNum <= 0 || rateNum < 0 || timeNum <= 0) {
      setError('Please enter valid positive numbers');
      return;
    }

    try {
      const interestResult = calculateInterest(principalNum, rateNum, timeNum, frequencyNum);
      setResult(interestResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: InterestResult) => {
    return `Simple Interest: $${result.simpleInterest}, Compound Interest: $${result.compoundInterest}, Difference: $${result.difference}`;
  };

  const getFrequencyText = (frequency: string) => {
    switch (frequency) {
      case '1': return 'Annually';
      case '2': return 'Semi-annually';
      case '4': return 'Quarterly';
      case '12': return 'Monthly';
      case '365': return 'Daily';
      default: return 'Custom';
    }
  };

  const faqs = [
    {
      question: 'What is the difference between simple and compound interest?',
      answer: 'Simple interest is calculated only on the principal amount, while compound interest is calculated on the principal plus any previously earned interest.',
    },
    {
      question: 'How does compounding frequency affect the result?',
      answer: 'Higher compounding frequency (like daily vs annually) results in more interest earned because interest is calculated and added to the principal more often.',
    },
    {
      question: 'What is the formula for compound interest?',
      answer: 'Compound Interest = P(1 + r/n)^(nt) - P, where P is principal, r is annual rate, n is compounding frequency, and t is time in years.',
    },
  ];

  return (
    <CalculatorLayout
      title="Interest Calculator"
      description="Calculate simple and compound interest"
      category="finance"
      faqs={faqs}
      disclaimer="This calculator provides estimates for educational purposes. Actual interest calculations may vary based on specific terms and conditions."
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  ${result.simpleInterest}
                </div>
                <div className="text-sm text-muted-foreground">Simple Interest</div>
                <div className="text-sm text-muted-foreground mt-1">
                  Total: ${result.totalAmountSimple}
                </div>
              </div>
              
              <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  ${result.compoundInterest}
                </div>
                <div className="text-sm text-muted-foreground">Compound Interest</div>
                <div className="text-sm text-muted-foreground mt-1">
                  Total: ${result.totalAmountCompound}
                </div>
              </div>
            </div>
            
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <div className="text-lg font-semibold">
                Compound earns ${result.difference} more
              </div>
              <div className="text-sm text-muted-foreground">
                Compounding frequency: {getFrequencyText(compoundFrequency)}
              </div>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="principal">Principal Amount ($)</Label>
          <Input
            id="principal"
            type="number"
            value={principal}
            onChange={(e) => setPrincipal(e.target.value)}
            placeholder="e.g., 10000"
            min="0"
            step="0.01"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="rate">Annual Interest Rate (%)</Label>
          <Input
            id="rate"
            type="number"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
            placeholder="e.g., 5"
            min="0"
            step="0.01"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="time">Time Period (years)</Label>
          <Input
            id="time"
            type="number"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            placeholder="e.g., 5"
            min="0"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="frequency">Compounding Frequency</Label>
          <Select value={compoundFrequency} onValueChange={setCompoundFrequency}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Annually (1x per year)</SelectItem>
              <SelectItem value="2">Semi-annually (2x per year)</SelectItem>
              <SelectItem value="4">Quarterly (4x per year)</SelectItem>
              <SelectItem value="12">Monthly (12x per year)</SelectItem>
              <SelectItem value="365">Daily (365x per year)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Interest
        </Button>
      </div>
    </CalculatorLayout>
  );
}

