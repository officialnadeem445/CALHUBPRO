'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateIncomeTax, type TaxResult } from '@/lib/finance-calculations';
import { TAX_SYSTEMS, getTaxSystem } from '@/data/tax-slabs';

export function TaxCalculator() {
  const [grossIncome, setGrossIncome] = useState('');
  const [deductions, setDeductions] = useState('');
  const [taxSystem, setTaxSystem] = useState('us-2024');
  const [result, setResult] = useState<TaxResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tax-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setGrossIncome(data.grossIncome || '');
        setDeductions(data.deductions || '');
        setTaxSystem(data.taxSystem || 'us-2024');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('tax-calculator', JSON.stringify({ 
      grossIncome, 
      deductions, 
      taxSystem 
    }));
  }, [grossIncome, deductions, taxSystem]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!grossIncome) {
      setError('Please enter gross income');
      return;
    }

    const grossIncomeNum = parseFloat(grossIncome);
    const deductionsNum = parseFloat(deductions) || 0;

    if (isNaN(grossIncomeNum) || isNaN(deductionsNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (grossIncomeNum < 0 || deductionsNum < 0) {
      setError('Income and deductions cannot be negative');
      return;
    }

    try {
      const selectedSystem = getTaxSystem(taxSystem);
      const taxResult = calculateIncomeTax(grossIncomeNum, deductionsNum, selectedSystem.slabs);
      setResult(taxResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: TaxResult) => {
    const selectedSystem = getTaxSystem(taxSystem);
    return `Tax: ${selectedSystem.currency} ${result.totalTax}, Net Income: ${selectedSystem.currency} ${result.netIncome}, Effective Rate: ${result.effectiveRate}%`;
  };

  const selectedSystem = getTaxSystem(taxSystem);

  const faqs = [
    {
      question: 'How is income tax calculated?',
      answer: 'Income tax is calculated using progressive tax brackets. Different portions of your income are taxed at different rates, with higher income levels taxed at higher rates.',
    },
    {
      question: 'What are deductions?',
      answer: 'Deductions are expenses or allowances that reduce your taxable income. Common deductions include standard deduction, charitable donations, mortgage interest, and business expenses.',
    },
    {
      question: 'What is effective tax rate?',
      answer: 'Effective tax rate is your total tax divided by your gross income, expressed as a percentage. It represents the average rate at which your income is taxed.',
    },
  ];

  return (
    <CalculatorLayout
      title="Tax Calculator"
      description="Calculate income tax with progressive brackets"
      category="finance"
      faqs={faqs}
      disclaimer="This calculator provides estimates based on standard tax brackets. Actual tax calculations may vary based on specific circumstances, additional taxes, and local regulations. Consult a tax professional for accurate advice."
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-red-50 dark:bg-red-950 rounded-lg">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {selectedSystem.currency} {result.totalTax}
                </div>
                <div className="text-sm text-muted-foreground">Total Tax</div>
              </div>
              <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {selectedSystem.currency} {result.netIncome}
                </div>
                <div className="text-sm text-muted-foreground">Net Income</div>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{selectedSystem.currency} {result.grossIncome}</div>
                <div className="text-sm text-muted-foreground">Gross Income</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{selectedSystem.currency} {result.taxableIncome}</div>
                <div className="text-sm text-muted-foreground">Taxable Income</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.effectiveRate}%</div>
                <div className="text-sm text-muted-foreground">Effective Rate</div>
              </div>
            </div>

            {result.taxBreakdown.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-semibold">Tax Breakdown by Bracket</h3>
                <div className="space-y-2">
                  {result.taxBreakdown.map((breakdown, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg text-sm">
                      <div>
                        {breakdown.slab.rate}% on {selectedSystem.currency} {breakdown.taxableAmount}
                        <div className="text-xs text-muted-foreground">
                          ({selectedSystem.currency} {breakdown.slab.min} - {breakdown.slab.max ? `${selectedSystem.currency} ${breakdown.slab.max}` : 'above'})
                        </div>
                      </div>
                      <div className="font-semibold">
                        {selectedSystem.currency} {breakdown.tax}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="taxSystem">Tax System</Label>
          <Select value={taxSystem} onValueChange={setTaxSystem}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TAX_SYSTEMS.map((system) => (
                <SelectItem key={system.id} value={system.id}>
                  {system.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="grossIncome">Gross Annual Income ({selectedSystem.currency})</Label>
          <Input
            id="grossIncome"
            type="number"
            value={grossIncome}
            onChange={(e) => setGrossIncome(e.target.value)}
            placeholder="e.g., 75000"
            min="0"
            step="1000"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="deductions">Total Deductions ({selectedSystem.currency})</Label>
          <Input
            id="deductions"
            type="number"
            value={deductions}
            onChange={(e) => setDeductions(e.target.value)}
            placeholder="e.g., 12000"
            min="0"
            step="100"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Tax
        </Button>

        {/* Tax Brackets Reference */}
        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h3 className="font-semibold mb-2">{selectedSystem.name} Tax Brackets</h3>
          <div className="space-y-1 text-sm">
            {selectedSystem.slabs.map((slab, index) => (
              <div key={index} className="flex justify-between">
                <span>
                  {selectedSystem.currency} {slab.min.toLocaleString()} - {slab.max ? `${selectedSystem.currency} ${slab.max.toLocaleString()}` : 'above'}
                </span>
                <span className="font-medium">{slab.rate}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </CalculatorLayout>
  );
}

