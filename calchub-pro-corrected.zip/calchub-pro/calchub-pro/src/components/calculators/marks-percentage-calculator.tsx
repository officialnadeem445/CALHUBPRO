'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateMarksPercentage, type PercentageResult } from '@/lib/calculations';

export function MarksPercentageCalculator() {
  const [obtainedMarks, setObtainedMarks] = useState('');
  const [totalMarks, setTotalMarks] = useState('');
  const [result, setResult] = useState<PercentageResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('marks-percentage-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setObtainedMarks(data.obtainedMarks || '');
        setTotalMarks(data.totalMarks || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('marks-percentage-calculator', JSON.stringify({ 
      obtainedMarks, 
      totalMarks 
    }));
  }, [obtainedMarks, totalMarks]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!obtainedMarks || !totalMarks) {
      setError('Please enter both obtained marks and total marks');
      return;
    }

    const obtainedNum = parseFloat(obtainedMarks);
    const totalNum = parseFloat(totalMarks);

    if (isNaN(obtainedNum) || isNaN(totalNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (obtainedNum < 0 || totalNum <= 0) {
      setError('Marks must be positive numbers');
      return;
    }

    if (obtainedNum > totalNum) {
      setError('Obtained marks cannot be greater than total marks');
      return;
    }

    try {
      const percentageResult = calculateMarksPercentage(obtainedNum, totalNum);
      setResult(percentageResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const getGradeFromPercentage = (percentage: number) => {
    if (percentage >= 90) return { grade: 'A+', color: 'text-green-600' };
    if (percentage >= 80) return { grade: 'A', color: 'text-green-500' };
    if (percentage >= 70) return { grade: 'B', color: 'text-blue-600' };
    if (percentage >= 60) return { grade: 'C', color: 'text-yellow-600' };
    if (percentage >= 50) return { grade: 'D', color: 'text-orange-600' };
    return { grade: 'F', color: 'text-red-600' };
  };

  const formatResult = (result: PercentageResult) => {
    const gradeInfo = getGradeFromPercentage(result.result);
    return `Percentage: ${result.result}% (Grade: ${gradeInfo.grade})`;
  };

  const faqs = [
    {
      question: 'How is percentage calculated from marks?',
      answer: 'Percentage is calculated by dividing obtained marks by total marks and multiplying by 100. Formula: (Obtained Marks ÷ Total Marks) × 100',
    },
    {
      question: 'What grading scale is used?',
      answer: 'The calculator shows a common grading scale: A+ (90-100%), A (80-89%), B (70-79%), C (60-69%), D (50-59%), F (below 50%).',
    },
    {
      question: 'Can I use this for multiple subjects?',
      answer: 'Yes, you can calculate percentage for individual subjects or combine marks from multiple subjects by adding them together.',
    },
  ];

  return (
    <CalculatorLayout
      title="Marks Percentage Calculator"
      description="Calculate percentage from marks and total marks"
      category="education"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className="text-4xl font-bold text-primary">
                {result.result}%
              </div>
              <div className="text-lg font-semibold mt-2">
                Your Percentage
              </div>
            </div>
            
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className={`text-2xl font-bold ${getGradeFromPercentage(result.result).color}`}>
                Grade: {getGradeFromPercentage(result.result).grade}
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm">
                <strong>Formula:</strong> {result.formula}
              </p>
              <p className="text-sm text-muted-foreground">
                Obtained: {obtainedMarks} marks out of {totalMarks} total marks
              </p>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="obtainedMarks">Obtained Marks</Label>
          <Input
            id="obtainedMarks"
            type="number"
            value={obtainedMarks}
            onChange={(e) => setObtainedMarks(e.target.value)}
            placeholder="e.g., 85"
            min="0"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="totalMarks">Total Marks</Label>
          <Input
            id="totalMarks"
            type="number"
            value={totalMarks}
            onChange={(e) => setTotalMarks(e.target.value)}
            placeholder="e.g., 100"
            min="0"
            step="0.1"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Percentage
        </Button>

        {/* Quick Grade Reference */}
        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h3 className="font-semibold mb-2">Grade Scale Reference</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex justify-between">
              <span>A+:</span> <span className="text-green-600">90-100%</span>
            </div>
            <div className="flex justify-between">
              <span>A:</span> <span className="text-green-500">80-89%</span>
            </div>
            <div className="flex justify-between">
              <span>B:</span> <span className="text-blue-600">70-79%</span>
            </div>
            <div className="flex justify-between">
              <span>C:</span> <span className="text-yellow-600">60-69%</span>
            </div>
            <div className="flex justify-between">
              <span>D:</span> <span className="text-orange-600">50-59%</span>
            </div>
            <div className="flex justify-between">
              <span>F:</span> <span className="text-red-600">Below 50%</span>
            </div>
          </div>
        </div>
      </div>
    </CalculatorLayout>
  );
}

