'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateGPA, type Course, type GPAResult } from '@/lib/calculations';
import { Plus, Trash2 } from 'lucide-react';

export function GPACalculator() {
  const [courses, setCourses] = useState<Course[]>([
    { name: '', grade: 0, credits: 0 }
  ]);
  const [result, setResult] = useState<GPAResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('gpa-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        if (data.courses && data.courses.length > 0) {
          setCourses(data.courses);
        }
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('gpa-calculator', JSON.stringify({ courses }));
  }, [courses]);

  const addCourse = () => {
    setCourses([...courses, { name: '', grade: 0, credits: 0 }]);
  };

  const removeCourse = (index: number) => {
    if (courses.length > 1) {
      setCourses(courses.filter((_, i) => i !== index));
    }
  };

  const updateCourse = (index: number, field: keyof Course, value: string | number) => {
    const updatedCourses = courses.map((course, i) => {
      if (i === index) {
        return { ...course, [field]: value };
      }
      return course;
    });
    setCourses(updatedCourses);
  };

  const handleCalculate = () => {
    setError('');
    setResult(null);

    // Filter out empty courses
    const validCourses = courses.filter(course => 
      course.name.trim() !== '' && course.credits > 0
    );

    if (validCourses.length === 0) {
      setError('Please add at least one course with valid credits');
      return;
    }

    // Validate grades and credits
    for (const course of validCourses) {
      if (course.grade < 0 || course.grade > 4) {
        setError('Grades must be between 0.0 and 4.0');
        return;
      }
      if (course.credits <= 0) {
        setError('Credits must be positive numbers');
        return;
      }
    }

    try {
      const gpaResult = calculateGPA(validCourses);
      setResult(gpaResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: GPAResult) => {
    return `GPA: ${result.gpa} (${result.totalCredits} total credits)`;
  };

  const getGradeColor = (gpa: number) => {
    if (gpa >= 3.7) return 'text-green-600';
    if (gpa >= 3.0) return 'text-blue-600';
    if (gpa >= 2.0) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getGradeDescription = (gpa: number) => {
    if (gpa >= 3.7) return 'Excellent';
    if (gpa >= 3.0) return 'Good';
    if (gpa >= 2.0) return 'Satisfactory';
    return 'Needs Improvement';
  };

  const faqs = [
    {
      question: 'How is GPA calculated?',
      answer: 'GPA is calculated by dividing the total grade points (grade × credits for each course) by the total number of credits.',
    },
    {
      question: 'What grade scale does this calculator use?',
      answer: 'This calculator uses the standard 4.0 scale where A=4.0, B=3.0, C=2.0, D=1.0, F=0.0. You can enter decimal values like 3.7 for A-.',
    },
    {
      question: 'Can I calculate cumulative GPA?',
      answer: 'Yes, just enter all your courses from all semesters with their respective grades and credits to get your cumulative GPA.',
    },
  ];

  return (
    <CalculatorLayout
      title="GPA Calculator"
      description="Calculate your Grade Point Average with custom weights"
      category="education"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className={`text-3xl font-bold ${getGradeColor(result.gpa)}`}>
                {result.gpa}
              </div>
              <div className="text-lg font-semibold mt-2">
                {getGradeDescription(result.gpa)}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.totalCredits}</div>
                <div className="text-sm text-muted-foreground">Total Credits</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.totalGradePoints}</div>
                <div className="text-sm text-muted-foreground">Grade Points</div>
              </div>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-4">
          {courses.map((course, index) => (
            <div key={index} className="p-4 border rounded-lg space-y-3">
              <div className="flex justify-between items-center">
                <Label className="text-sm font-semibold">Course {index + 1}</Label>
                {courses.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCourse(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor={`course-name-${index}`}>Course Name</Label>
                <Input
                  id={`course-name-${index}`}
                  type="text"
                  value={course.name}
                  onChange={(e) => updateCourse(index, 'name', e.target.value)}
                  placeholder="e.g., Mathematics 101"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor={`grade-${index}`}>Grade (0.0-4.0)</Label>
                  <Input
                    id={`grade-${index}`}
                    type="number"
                    value={course.grade || ''}
                    onChange={(e) => updateCourse(index, 'grade', parseFloat(e.target.value) || 0)}
                    placeholder="e.g., 3.7"
                    min="0"
                    max="4"
                    step="0.1"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor={`credits-${index}`}>Credits</Label>
                  <Input
                    id={`credits-${index}`}
                    type="number"
                    value={course.credits || ''}
                    onChange={(e) => updateCourse(index, 'credits', parseFloat(e.target.value) || 0)}
                    placeholder="e.g., 3"
                    min="0"
                    step="0.5"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <Button variant="outline" onClick={addCourse} className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Add Course
        </Button>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate GPA
        </Button>
      </div>
    </CalculatorLayout>
  );
}

