'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  fetchExchangeRates, 
  convertCurrency, 
  getCurrencySymbol,
  getCurrencyName,
  POPULAR_CURRENCIES,
  type CurrencyData,
  type ConversionResult 
} from '@/lib/currency-api';
import { ArrowLeftRight, RefreshCw } from 'lucide-react';

export function CurrencyConverter() {
  const [amount, setAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [currencyData, setCurrencyData] = useState<CurrencyData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('currency-converter');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setAmount(data.amount || '');
        setFromCurrency(data.fromCurrency || 'USD');
        setToCurrency(data.toCurrency || 'EUR');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('currency-converter', JSON.stringify({ 
      amount, 
      fromCurrency, 
      toCurrency 
    }));
  }, [amount, fromCurrency, toCurrency]);

  // Fetch exchange rates on component mount
  useEffect(() => {
    loadExchangeRates();
  }, []);

  const loadExchangeRates = async () => {
    setLoading(true);
    setError('');
    
    try {
      const data = await fetchExchangeRates('USD');
      setCurrencyData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load exchange rates');
    } finally {
      setLoading(false);
    }
  };

  const handleConvert = () => {
    setError('');
    setResult(null);

    if (!amount || !currencyData) {
      setError('Please enter an amount and ensure exchange rates are loaded');
      return;
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum < 0) {
      setError('Please enter a valid positive amount');
      return;
    }

    try {
      const conversionResult = convertCurrency(
        amountNum,
        fromCurrency,
        toCurrency,
        currencyData.rates,
        currencyData.base
      );
      setResult(conversionResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Conversion failed');
    }
  };

  const swapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  const formatResult = (result: ConversionResult) => {
    const fromSymbol = getCurrencySymbol(result.from);
    const toSymbol = getCurrencySymbol(result.to);
    return `${fromSymbol}${result.amount} = ${toSymbol}${result.convertedAmount}`;
  };

  const faqs = [
    {
      question: 'How often are exchange rates updated?',
      answer: 'Exchange rates are fetched from a live API and are typically updated daily. Click the refresh button to get the latest rates.',
    },
    {
      question: 'Are these rates suitable for actual transactions?',
      answer: 'These are indicative rates for reference only. Actual exchange rates for transactions may vary depending on your bank or exchange service.',
    },
    {
      question: 'Which currencies are supported?',
      answer: 'The converter supports major world currencies including USD, EUR, GBP, JPY, and many others. The most popular currencies are shown in the dropdown.',
    },
  ];

  return (
    <CalculatorLayout
      title="Currency Converter"
      description="Convert between different currencies with live rates"
      category="finance"
      faqs={faqs}
      disclaimer="Exchange rates are for reference only and may not reflect actual transaction rates. Consult your bank or financial institution for precise rates."
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className="text-sm text-muted-foreground mb-2">
                {getCurrencyName(result.from)} to {getCurrencyName(result.to)}
              </div>
              <div className="text-3xl font-bold text-primary">
                {getCurrencySymbol(result.to)}{result.convertedAmount}
              </div>
              <div className="text-lg mt-2">
                {getCurrencySymbol(result.from)}{result.amount} {result.from}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.rate}</div>
                <div className="text-sm text-muted-foreground">
                  1 {result.from} = {result.rate} {result.to}
                </div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{(1 / result.rate).toFixed(4)}</div>
                <div className="text-sm text-muted-foreground">
                  1 {result.to} = {(1 / result.rate).toFixed(4)} {result.from}
                </div>
              </div>
            </div>

            {currencyData && (
              <div className="text-center text-sm text-muted-foreground">
                Rates updated: {currencyData.date}
              </div>
            )}

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount">Amount</Label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 100"
            min="0"
            step="0.01"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fromCurrency">From Currency</Label>
          <Select value={fromCurrency} onValueChange={setFromCurrency}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {POPULAR_CURRENCIES.map((currency) => (
                <SelectItem key={currency.code} value={currency.code}>
                  {currency.symbol} {currency.code} - {currency.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex justify-center">
          <Button variant="outline" size="icon" onClick={swapCurrencies}>
            <ArrowLeftRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="toCurrency">To Currency</Label>
          <Select value={toCurrency} onValueChange={setToCurrency}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {POPULAR_CURRENCIES.map((currency) => (
                <SelectItem key={currency.code} value={currency.code}>
                  {currency.symbol} {currency.code} - {currency.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={loadExchangeRates} 
            disabled={loading}
            className="flex-shrink-0"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh Rates
          </Button>
          <Button onClick={handleConvert} className="flex-1" disabled={loading}>
            Convert
          </Button>
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        {loading && (
          <div className="text-sm text-muted-foreground text-center">
            Loading exchange rates...
          </div>
        )}
      </div>
    </CalculatorLayout>
  );
}

