'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  calculateDateDifference, 
  formatDuration,
  type DateDifferenceResult 
} from '@/lib/date-calculations';

export function DateDifferenceCalculator() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [result, setResult] = useState<DateDifferenceResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('date-difference-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setStartDate(data.startDate || '');
        setEndDate(data.endDate || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('date-difference-calculator', JSON.stringify({ 
      startDate, 
      endDate 
    }));
  }, [startDate, endDate]);

  // Set default dates on component mount
  useEffect(() => {
    if (!startDate && !endDate) {
      const today = new Date();
      const nextWeek = new Date(today);
      nextWeek.setDate(today.getDate() + 7);
      
      setStartDate(today.toISOString().split('T')[0]);
      setEndDate(nextWeek.toISOString().split('T')[0]);
    }
  }, [startDate, endDate]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!startDate || !endDate) {
      setError('Please select both start and end dates');
      return;
    }

    try {
      const dateResult = calculateDateDifference(startDate, endDate);
      setResult(dateResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: DateDifferenceResult) => {
    return `${result.years} years, ${result.months} months, ${result.days} days (${result.totalDays} total days)`;
  };

  const faqs = [
    {
      question: 'How are business days calculated?',
      answer: 'Business days exclude weekends (Saturday and Sunday). The calculator counts Monday through Friday as business days.',
    },
    {
      question: 'What is the difference between total days and the years/months/days breakdown?',
      answer: 'Total days is the exact number of days between dates. The breakdown shows the difference in calendar terms (years, months, and remaining days).',
    },
    {
      question: 'Are leap years considered?',
      answer: 'Yes, the calculator automatically accounts for leap years when calculating date differences.',
    },
  ];

  return (
    <CalculatorLayout
      title="Date Difference Calculator"
      description="Calculate the difference between two dates"
      category="date"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className="text-3xl font-bold text-primary">{result.totalDays}</div>
              <div className="text-lg font-semibold mt-2">Total Days</div>
              <div className="text-sm text-muted-foreground mt-1">
                {formatDuration(result.totalDays)}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.years}</div>
                <div className="text-sm text-muted-foreground">Years</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.months}</div>
                <div className="text-sm text-muted-foreground">Months</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.days}</div>
                <div className="text-sm text-muted-foreground">Days</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                  {result.businessDays}
                </div>
                <div className="text-sm text-muted-foreground">Business Days</div>
                <div className="text-xs text-muted-foreground">Mon-Fri</div>
              </div>
              <div className="text-center p-4 bg-orange-50 dark:bg-orange-950 rounded-lg">
                <div className="text-xl font-bold text-orange-600 dark:text-orange-400">
                  {result.weekends}
                </div>
                <div className="text-sm text-muted-foreground">Weekend Days</div>
                <div className="text-xs text-muted-foreground">Sat-Sun</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.totalWeeks}</div>
                <div className="text-sm text-muted-foreground">Total Weeks</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.totalHours.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Total Hours</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.totalMinutes.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Total Minutes</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{result.totalSeconds.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Total Seconds</div>
              </div>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="startDate">Start Date</Label>
          <Input
            id="startDate"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="endDate">End Date</Label>
          <Input
            id="endDate"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Difference
        </Button>

        <div className="text-center">
          <Button
            variant="outline"
            onClick={() => {
              const today = new Date().toISOString().split('T')[0];
              setStartDate(today);
              setEndDate(today);
            }}
            className="text-sm"
          >
            Use Today's Date
          </Button>
        </div>
      </div>
    </CalculatorLayout>
  );
}

