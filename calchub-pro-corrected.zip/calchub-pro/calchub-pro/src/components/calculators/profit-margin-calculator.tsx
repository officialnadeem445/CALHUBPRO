'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  calculateProfitMargin, 
  calculateSellingPriceFromMargin,
  calculateSellingPriceFromMarkup,
  type ProfitMarginResult 
} from '@/lib/finance-calculations';

type CalculationType = 'margin' | 'sellingFromMargin' | 'sellingFromMarkup';

export function ProfitMarginCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>('margin');
  const [costPrice, setCostPrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [targetMargin, setTargetMargin] = useState('');
  const [targetMarkup, setTargetMarkup] = useState('');
  const [result, setResult] = useState<ProfitMarginResult | number | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('profit-margin-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setCalculationType(data.calculationType || 'margin');
        setCostPrice(data.costPrice || '');
        setSellingPrice(data.sellingPrice || '');
        setTargetMargin(data.targetMargin || '');
        setTargetMarkup(data.targetMarkup || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('profit-margin-calculator', JSON.stringify({ 
      calculationType,
      costPrice, 
      sellingPrice,
      targetMargin,
      targetMarkup
    }));
  }, [calculationType, costPrice, sellingPrice, targetMargin, targetMarkup]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    const costNum = parseFloat(costPrice);
    
    if (!costPrice || isNaN(costNum) || costNum <= 0) {
      setError('Please enter a valid cost price');
      return;
    }

    try {
      switch (calculationType) {
        case 'margin': {
          const sellingNum = parseFloat(sellingPrice);
          if (!sellingPrice || isNaN(sellingNum) || sellingNum <= 0) {
            setError('Please enter a valid selling price');
            return;
          }
          const marginResult = calculateProfitMargin(costNum, sellingNum);
          setResult(marginResult);
          break;
        }
        case 'sellingFromMargin': {
          const marginNum = parseFloat(targetMargin);
          if (!targetMargin || isNaN(marginNum) || marginNum < 0 || marginNum >= 100) {
            setError('Please enter a valid margin percentage (0-99%)');
            return;
          }
          const sellingPriceResult = calculateSellingPriceFromMargin(costNum, marginNum);
          setResult(sellingPriceResult);
          break;
        }
        case 'sellingFromMarkup': {
          const markupNum = parseFloat(targetMarkup);
          if (!targetMarkup || isNaN(markupNum) || markupNum < 0) {
            setError('Please enter a valid markup percentage');
            return;
          }
          const sellingPriceResult = calculateSellingPriceFromMarkup(costNum, markupNum);
          setResult(sellingPriceResult);
          break;
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = () => {
    if (typeof result === 'number') {
      return `Required selling price: $${result}`;
    } else if (result && typeof result === 'object') {
      return `Profit Margin: ${result.profitMargin}%, Markup: ${result.markup}%, Profit: $${result.profit}`;
    }
    return '';
  };

  const faqs = [
    {
      question: 'What is the difference between profit margin and markup?',
      answer: 'Profit margin is profit as a percentage of selling price, while markup is profit as a percentage of cost price. Margin = (Selling Price - Cost) / Selling Price × 100.',
    },
    {
      question: 'Which is better to use - margin or markup?',
      answer: 'Both are useful. Margin shows profitability relative to sales, while markup shows how much you\'re adding to cost. Many businesses use margin for financial analysis and markup for pricing.',
    },
    {
      question: 'How do I set a good profit margin?',
      answer: 'Good profit margins vary by industry. Research your industry standards, consider your costs, competition, and value proposition. Typical retail margins range from 2-20%, while services can be 15-50%.',
    },
  ];

  return (
    <CalculatorLayout
      title="Profit Margin Calculator"
      description="Calculate profit margin and markup"
      category="finance"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            {typeof result === 'number' ? (
              <div className="text-center p-6 bg-primary/10 rounded-lg">
                <div className="text-3xl font-bold text-primary">${result}</div>
                <div className="text-lg font-semibold mt-2">
                  {calculationType === 'sellingFromMargin' ? 'Required Selling Price (from Margin)' : 'Required Selling Price (from Markup)'}
                </div>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                      {result.profitMargin}%
                    </div>
                    <div className="text-sm text-muted-foreground">Profit Margin</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {result.markup}%
                    </div>
                    <div className="text-sm text-muted-foreground">Markup</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">${result.costPrice}</div>
                    <div className="text-sm text-muted-foreground">Cost Price</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">${result.profit}</div>
                    <div className="text-sm text-muted-foreground">Profit</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">${result.sellingPrice}</div>
                    <div className="text-sm text-muted-foreground">Selling Price</div>
                  </div>
                </div>
              </>
            )}

            <CopyButton text={formatResult()} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="calculationType">Calculation Type</Label>
          <Select 
            value={calculationType} 
            onValueChange={(value: CalculationType) => setCalculationType(value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="margin">Calculate Margin & Markup</SelectItem>
              <SelectItem value="sellingFromMargin">Find Selling Price from Margin</SelectItem>
              <SelectItem value="sellingFromMarkup">Find Selling Price from Markup</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="costPrice">Cost Price ($)</Label>
          <Input
            id="costPrice"
            type="number"
            value={costPrice}
            onChange={(e) => setCostPrice(e.target.value)}
            placeholder="e.g., 50"
            min="0"
            step="0.01"
          />
        </div>

        {calculationType === 'margin' && (
          <div className="space-y-2">
            <Label htmlFor="sellingPrice">Selling Price ($)</Label>
            <Input
              id="sellingPrice"
              type="number"
              value={sellingPrice}
              onChange={(e) => setSellingPrice(e.target.value)}
              placeholder="e.g., 75"
              min="0"
              step="0.01"
            />
          </div>
        )}

        {calculationType === 'sellingFromMargin' && (
          <div className="space-y-2">
            <Label htmlFor="targetMargin">Target Profit Margin (%)</Label>
            <Input
              id="targetMargin"
              type="number"
              value={targetMargin}
              onChange={(e) => setTargetMargin(e.target.value)}
              placeholder="e.g., 30"
              min="0"
              max="99"
              step="0.1"
            />
          </div>
        )}

        {calculationType === 'sellingFromMarkup' && (
          <div className="space-y-2">
            <Label htmlFor="targetMarkup">Target Markup (%)</Label>
            <Input
              id="targetMarkup"
              type="number"
              value={targetMarkup}
              onChange={(e) => setTargetMarkup(e.target.value)}
              placeholder="e.g., 50"
              min="0"
              step="0.1"
            />
          </div>
        )}

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate
        </Button>
      </div>
    </CalculatorLayout>
  );
}

