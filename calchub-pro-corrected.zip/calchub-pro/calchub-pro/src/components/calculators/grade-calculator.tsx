'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateRequiredGrade, type GradeCalculation } from '@/lib/calculations';

export function GradeCalculator() {
  const [currentGrade, setCurrentGrade] = useState('');
  const [currentWeight, setCurrentWeight] = useState('');
  const [finalWeight, setFinalWeight] = useState('');
  const [targetGrade, setTargetGrade] = useState('');
  const [result, setResult] = useState<GradeCalculation | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('grade-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setCurrentGrade(data.currentGrade || '');
        setCurrentWeight(data.currentWeight || '');
        setFinalWeight(data.finalWeight || '');
        setTargetGrade(data.targetGrade || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('grade-calculator', JSON.stringify({ 
      currentGrade, 
      currentWeight, 
      finalWeight, 
      targetGrade 
    }));
  }, [currentGrade, currentWeight, finalWeight, targetGrade]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!currentGrade || !currentWeight || !finalWeight || !targetGrade) {
      setError('Please fill in all fields');
      return;
    }

    const currentGradeNum = parseFloat(currentGrade);
    const currentWeightNum = parseFloat(currentWeight);
    const finalWeightNum = parseFloat(finalWeight);
    const targetGradeNum = parseFloat(targetGrade);

    if (isNaN(currentGradeNum) || isNaN(currentWeightNum) || isNaN(finalWeightNum) || isNaN(targetGradeNum)) {
      setError('Please enter valid numbers');
      return;
    }

    if (currentGradeNum < 0 || currentGradeNum > 100 || targetGradeNum < 0 || targetGradeNum > 100) {
      setError('Grades must be between 0 and 100');
      return;
    }

    if (currentWeightNum < 0 || finalWeightNum < 0 || currentWeightNum + finalWeightNum !== 100) {
      setError('Weights must be positive and sum to 100%');
      return;
    }

    try {
      const gradeResult = calculateRequiredGrade(
        currentGradeNum, 
        currentWeightNum, 
        finalWeightNum, 
        targetGradeNum
      );
      setResult(gradeResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: GradeCalculation) => {
    return `Required final grade: ${result.requiredFinalGrade}% (${result.isAchievable ? 'Achievable' : 'Not achievable'})`;
  };

  const faqs = [
    {
      question: 'How does this calculator work?',
      answer: 'This calculator determines what grade you need on your final exam/assignment to achieve your target overall grade, based on your current grade and the weight distribution.',
    },
    {
      question: 'What if the required grade is over 100%?',
      answer: 'If the required grade exceeds 100%, it means your target overall grade is not achievable with the current grade and weight distribution.',
    },
    {
      question: 'Can I use this for multiple assignments?',
      answer: 'Yes, you can use this for any scenario where you have a current grade and need to know what score is required on remaining work to reach a target.',
    },
  ];

  return (
    <CalculatorLayout
      title="Grade Calculator"
      description="Calculate final grades and required scores"
      category="education"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className={`text-center p-6 rounded-lg ${
              result.isAchievable 
                ? 'bg-green-50 dark:bg-green-950' 
                : 'bg-red-50 dark:bg-red-950'
            }`}>
              <div className={`text-3xl font-bold ${
                result.isAchievable 
                  ? 'text-green-600 dark:text-green-400' 
                  : 'text-red-600 dark:text-red-400'
              }`}>
                {result.requiredFinalGrade}%
              </div>
              <div className="text-lg font-semibold mt-2">
                Required Final Grade
              </div>
              <div className={`text-sm mt-1 ${
                result.isAchievable 
                  ? 'text-green-600 dark:text-green-400' 
                  : 'text-red-600 dark:text-red-400'
              }`}>
                {result.isAchievable ? '✓ Achievable' : '✗ Not Achievable'}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.currentGrade}%</div>
                <div className="text-sm text-muted-foreground">Current Grade</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-xl font-bold">{result.possibleGrade}%</div>
                <div className="text-sm text-muted-foreground">Max Possible Grade</div>
              </div>
            </div>

            {!result.isAchievable && (
              <div className="p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  <strong>Tip:</strong> Your target grade is not achievable with the current grade. 
                  Consider adjusting your target or exploring extra credit opportunities.
                </p>
              </div>
            )}

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="currentGrade">Current Grade (%)</Label>
          <Input
            id="currentGrade"
            type="number"
            value={currentGrade}
            onChange={(e) => setCurrentGrade(e.target.value)}
            placeholder="e.g., 85"
            min="0"
            max="100"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="currentWeight">Current Grade Weight (%)</Label>
          <Input
            id="currentWeight"
            type="number"
            value={currentWeight}
            onChange={(e) => setCurrentWeight(e.target.value)}
            placeholder="e.g., 60"
            min="0"
            max="100"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="finalWeight">Final Exam/Assignment Weight (%)</Label>
          <Input
            id="finalWeight"
            type="number"
            value={finalWeight}
            onChange={(e) => setFinalWeight(e.target.value)}
            placeholder="e.g., 40"
            min="0"
            max="100"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="targetGrade">Target Overall Grade (%)</Label>
          <Input
            id="targetGrade"
            type="number"
            value={targetGrade}
            onChange={(e) => setTargetGrade(e.target.value)}
            placeholder="e.g., 90"
            min="0"
            max="100"
            step="0.1"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Required Grade
        </Button>
      </div>
    </CalculatorLayout>
  );
}

