'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { convertUnit, type ConversionResult, type UnitCategory } from '@/lib/utility-calculations';

const UNIT_OPTIONS = {
  length: [
    { value: 'meter', label: 'Meter (m)' },
    { value: 'kilometer', label: 'Kilometer (km)' },
    { value: 'centimeter', label: 'Centimeter (cm)' },
    { value: 'millimeter', label: 'Millimeter (mm)' },
    { value: 'inch', label: 'Inch (in)' },
    { value: 'foot', label: 'Foot (ft)' },
    { value: 'yard', label: 'Yard (yd)' },
    { value: 'mile', label: 'Mile (mi)' },
  ],
  weight: [
    { value: 'kilogram', label: 'Kilogram (kg)' },
    { value: 'gram', label: 'Gram (g)' },
    { value: 'pound', label: 'Pound (lb)' },
    { value: 'ounce', label: 'Ounce (oz)' },
    { value: 'ton', label: 'Ton (t)' },
    { value: 'stone', label: 'Stone (st)' },
  ],
  temperature: [
    { value: 'celsius', label: 'Celsius (°C)' },
    { value: 'fahrenheit', label: 'Fahrenheit (°F)' },
    { value: 'kelvin', label: 'Kelvin (K)' },
  ],
  volume: [
    { value: 'liter', label: 'Liter (L)' },
    { value: 'milliliter', label: 'Milliliter (mL)' },
    { value: 'gallon', label: 'Gallon (gal)' },
    { value: 'quart', label: 'Quart (qt)' },
    { value: 'pint', label: 'Pint (pt)' },
    { value: 'cup', label: 'Cup' },
    { value: 'fluid_ounce', label: 'Fluid Ounce (fl oz)' },
  ],
  area: [
    { value: 'square_meter', label: 'Square Meter (m²)' },
    { value: 'square_kilometer', label: 'Square Kilometer (km²)' },
    { value: 'square_centimeter', label: 'Square Centimeter (cm²)' },
    { value: 'square_inch', label: 'Square Inch (in²)' },
    { value: 'square_foot', label: 'Square Foot (ft²)' },
    { value: 'square_yard', label: 'Square Yard (yd²)' },
    { value: 'acre', label: 'Acre' },
    { value: 'hectare', label: 'Hectare (ha)' },
  ],
  speed: [
    { value: 'meter_per_second', label: 'Meter per Second (m/s)' },
    { value: 'kilometer_per_hour', label: 'Kilometer per Hour (km/h)' },
    { value: 'mile_per_hour', label: 'Mile per Hour (mph)' },
    { value: 'foot_per_second', label: 'Foot per Second (ft/s)' },
    { value: 'knot', label: 'Knot (kn)' },
  ],
};

export function UnitConverter() {
  const [category, setCategory] = useState<UnitCategory>('length');
  const [value, setValue] = useState('');
  const [fromUnit, setFromUnit] = useState('meter');
  const [toUnit, setToUnit] = useState('foot');
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('unit-converter');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setCategory(data.category || 'length');
        setValue(data.value || '');
        setFromUnit(data.fromUnit || 'meter');
        setToUnit(data.toUnit || 'foot');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('unit-converter', JSON.stringify({ 
      category, 
      value, 
      fromUnit, 
      toUnit 
    }));
  }, [category, value, fromUnit, toUnit]);

  // Reset units when category changes
  useEffect(() => {
    const units = UNIT_OPTIONS[category];
    if (units.length >= 2) {
      setFromUnit(units[0].value);
      setToUnit(units[1].value);
    }
    setResult(null);
  }, [category]);

  const handleConvert = () => {
    setError('');
    setResult(null);

    if (!value) {
      setError('Please enter a value to convert');
      return;
    }

    const valueNum = parseFloat(value);
    if (isNaN(valueNum)) {
      setError('Please enter a valid number');
      return;
    }

    if (valueNum < 0 && category !== 'temperature') {
      setError('Value cannot be negative for this unit type');
      return;
    }

    if (fromUnit === toUnit) {
      setError('Please select different units');
      return;
    }

    try {
      const conversionResult = convertUnit(valueNum, fromUnit, toUnit, category);
      setResult(conversionResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleSwapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
    setResult(null);
  };

  const formatResult = (result: ConversionResult) => {
    const fromLabel = UNIT_OPTIONS[category].find(u => u.value === result.fromUnit)?.label || result.fromUnit;
    const toLabel = UNIT_OPTIONS[category].find(u => u.value === result.toUnit)?.label || result.toUnit;
    return `${result.value} ${fromLabel} = ${result.result} ${toLabel}`;
  };

  const faqs = [
    {
      question: 'How accurate are the conversions?',
      answer: 'Our conversions use standard conversion factors and are accurate to 6 decimal places. Temperature conversions use precise formulas for accurate results.',
    },
    {
      question: 'Can I convert negative values?',
      answer: 'Negative values are allowed for temperature conversions (e.g., below freezing). For other units like length, weight, and volume, negative values are not meaningful.',
    },
    {
      question: 'What units are supported?',
      answer: 'We support conversions for length, weight, temperature, volume, area, and speed. Each category includes both metric and imperial units.',
    },
  ];

  return (
    <CalculatorLayout
      title="Unit Converter"
      description="Convert between different units of measurement"
      category="utility"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className="text-3xl font-bold text-primary">
                {result.result.toLocaleString()}
              </div>
              <div className="text-lg font-semibold mt-2">
                {UNIT_OPTIONS[category].find(u => u.value === result.toUnit)?.label}
              </div>
            </div>
            
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-lg">
                <span className="font-semibold">{result.value.toLocaleString()}</span> {UNIT_OPTIONS[category].find(u => u.value === result.fromUnit)?.label}
                <span className="mx-2">=</span>
                <span className="font-semibold">{result.result.toLocaleString()}</span> {UNIT_OPTIONS[category].find(u => u.value === result.toUnit)?.label}
              </div>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select value={category} onValueChange={(value: UnitCategory) => setCategory(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="length">Length</SelectItem>
              <SelectItem value="weight">Weight</SelectItem>
              <SelectItem value="temperature">Temperature</SelectItem>
              <SelectItem value="volume">Volume</SelectItem>
              <SelectItem value="area">Area</SelectItem>
              <SelectItem value="speed">Speed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="value">Value</Label>
          <Input
            id="value"
            type="number"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Enter value to convert"
            step="any"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="fromUnit">From</Label>
            <Select value={fromUnit} onValueChange={setFromUnit}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {UNIT_OPTIONS[category].map((unit) => (
                  <SelectItem key={unit.value} value={unit.value}>
                    {unit.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="toUnit">To</Label>
            <Select value={toUnit} onValueChange={setToUnit}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {UNIT_OPTIONS[category].map((unit) => (
                  <SelectItem key={unit.value} value={unit.value}>
                    {unit.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex justify-center">
          <Button variant="outline" onClick={handleSwapUnits} className="text-sm">
            ⇄ Swap Units
          </Button>
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleConvert} className="w-full">
          Convert
        </Button>
      </div>
    </CalculatorLayout>
  );
}

