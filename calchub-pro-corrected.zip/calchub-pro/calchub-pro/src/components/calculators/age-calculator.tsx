'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { calculateAge, type AgeResult } from '@/lib/calculations';

export function AgeCalculator() {
  const [birthDate, setBirthDate] = useState('');
  const [result, setResult] = useState<AgeResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('age-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setBirthDate(data.birthDate || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    if (birthDate) {
      localStorage.setItem('age-calculator', JSON.stringify({ birthDate }));
    }
  }, [birthDate]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!birthDate) {
      setError('Please enter your birth date');
      return;
    }

    try {
      const birth = new Date(birthDate);
      const ageResult = calculateAge(birth);
      setResult(ageResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: AgeResult) => {
    return `Age: ${result.years} years, ${result.months} months, ${result.days} days (Total: ${result.totalDays} days)`;
  };

  const faqs = [
    {
      question: 'How is age calculated?',
      answer: 'Age is calculated by finding the difference between your birth date and the current date, accounting for leap years and varying month lengths.',
    },
    {
      question: 'Why does the calculator show months and days?',
      answer: 'This provides a more precise age calculation than just years, which is useful for various applications like insurance, legal documents, or personal interest.',
    },
    {
      question: 'What is the total days calculation?',
      answer: 'Total days shows exactly how many days you have been alive since your birth date, which can be interesting for milestone celebrations.',
    },
  ];

  return (
    <CalculatorLayout
      title="Age Calculator"
      description="Calculate your exact age in years, months, and days"
      category="basic"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">{result.years}</div>
                <div className="text-sm text-muted-foreground">Years</div>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">{result.months}</div>
                <div className="text-sm text-muted-foreground">Months</div>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">{result.days}</div>
                <div className="text-sm text-muted-foreground">Days</div>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">{result.totalDays}</div>
                <div className="text-sm text-muted-foreground">Total Days</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Next birthday: {result.nextBirthday.toLocaleDateString()}
              </p>
              <p className="text-sm text-muted-foreground">
                Days until birthday: {result.daysUntilBirthday}
              </p>
            </div>

            <CopyButton text={formatResult(result)} className="w-full" />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="birthDate">Birth Date</Label>
          <Input
            id="birthDate"
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            max={new Date().toISOString().split('T')[0]}
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate Age
        </Button>
      </div>
    </CalculatorLayout>
  );
}

