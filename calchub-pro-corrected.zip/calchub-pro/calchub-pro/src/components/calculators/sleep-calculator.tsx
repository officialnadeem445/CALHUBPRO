'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  calculateOptimalSleep, 
  calculateBestWakeupTimes,
  type SleepResult 
} from '@/lib/health-calculations';

type CalculationMode = 'bedtime' | 'wakeup';

export function SleepCalculator() {
  const [mode, setMode] = useState<CalculationMode>('bedtime');
  const [wakeupTime, setWakeupTime] = useState('07:00');
  const [bedtime, setBedtime] = useState('23:00');
  const [sleepDuration, setSleepDuration] = useState('8');
  const [result, setResult] = useState<SleepResult | null>(null);
  const [wakeupTimes, setWakeupTimes] = useState<string[]>([]);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('sleep-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setMode(data.mode || 'bedtime');
        setWakeupTime(data.wakeupTime || '07:00');
        setBedtime(data.bedtime || '23:00');
        setSleepDuration(data.sleepDuration || '8');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('sleep-calculator', JSON.stringify({ 
      mode, 
      wakeupTime, 
      bedtime, 
      sleepDuration 
    }));
  }, [mode, wakeupTime, bedtime, sleepDuration]);

  const handleCalculate = () => {
    setError('');
    setResult(null);
    setWakeupTimes([]);

    const durationNum = parseFloat(sleepDuration);
    if (isNaN(durationNum) || durationNum < 4 || durationNum > 12) {
      setError('Sleep duration should be between 4 and 12 hours');
      return;
    }

    try {
      if (mode === 'bedtime') {
        const sleepResult = calculateOptimalSleep(wakeupTime, durationNum);
        setResult(sleepResult);
      } else {
        const bestWakeupTimes = calculateBestWakeupTimes(bedtime);
        setWakeupTimes(bestWakeupTimes);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const formatResult = (result: SleepResult) => {
    return `Bedtime: ${result.bedtime}, Wake up: ${result.wakeupTime}, Sleep cycles: ${result.sleepCycles}, Quality: ${result.sleepQuality}`;
  };

  const getSleepQualityColor = (quality: string) => {
    switch (quality) {
      case 'Optimal': return 'text-green-600 dark:text-green-400';
      case 'Adequate': return 'text-blue-600 dark:text-blue-400';
      case 'Extended': return 'text-yellow-600 dark:text-yellow-400';
      case 'Insufficient': return 'text-red-600 dark:text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  const faqs = [
    {
      question: 'What are sleep cycles?',
      answer: 'Sleep cycles are approximately 90-minute periods that include different stages of sleep (light sleep, deep sleep, and REM sleep). Waking up at the end of a cycle typically feels more refreshing.',
    },
    {
      question: 'How much sleep do I need?',
      answer: 'Most adults need 7-9 hours of sleep per night. However, individual needs can vary. Quality of sleep is as important as quantity.',
    },
    {
      question: 'Why does timing matter?',
      answer: 'Your body follows a natural circadian rhythm. Going to bed and waking up at consistent times helps regulate this rhythm, leading to better sleep quality and daytime alertness.',
    },
  ];

  return (
    <CalculatorLayout
      title="Sleep Calculator"
      description="Calculate optimal bedtime and wake-up times"
      category="health"
      faqs={faqs}
      disclaimer="This calculator provides general sleep recommendations. Individual sleep needs may vary. Consult a healthcare professional for persistent sleep issues."
      result={
        (result || wakeupTimes.length > 0) && (
          <div className="space-y-4">
            {result && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {result.bedtime}
                    </div>
                    <div className="text-sm text-muted-foreground">Recommended Bedtime</div>
                  </div>
                  
                  <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                      {result.wakeupTime}
                    </div>
                    <div className="text-sm text-muted-foreground">Wake-up Time</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">{result.sleepCycles}</div>
                    <div className="text-sm text-muted-foreground">Sleep Cycles</div>
                    <div className="text-xs text-muted-foreground">90 min each</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">{result.totalSleepHours}h</div>
                    <div className="text-sm text-muted-foreground">Total Sleep</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <div className={`text-lg font-bold ${getSleepQualityColor(result.sleepQuality)}`}>
                    {result.sleepQuality} Sleep Duration
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Sleep Recommendations:</h3>
                  <ul className="space-y-1 text-sm">
                    {result.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <CopyButton text={formatResult(result)} className="w-full" />
              </>
            )}

            {wakeupTimes.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-semibold text-center">Optimal Wake-up Times</h3>
                <div className="space-y-2">
                  {wakeupTimes.map((time, index) => (
                    <div key={index} className="p-3 bg-muted/50 rounded-lg text-center">
                      <div className="font-medium">{time}</div>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground text-center">
                  These times align with the end of sleep cycles for more refreshing wake-ups.
                </p>
              </div>
            )}
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="mode">Calculation Mode</Label>
          <Select value={mode} onValueChange={(value: CalculationMode) => setMode(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="bedtime">Find Bedtime (I know when to wake up)</SelectItem>
              <SelectItem value="wakeup">Find Wake-up Times (I know when to sleep)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {mode === 'bedtime' ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="wakeupTime">Desired Wake-up Time</Label>
              <Input
                id="wakeupTime"
                type="time"
                value={wakeupTime}
                onChange={(e) => setWakeupTime(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sleepDuration">Desired Sleep Duration (hours)</Label>
              <Select value={sleepDuration} onValueChange={setSleepDuration}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="6">6 hours</SelectItem>
                  <SelectItem value="6.5">6.5 hours</SelectItem>
                  <SelectItem value="7">7 hours</SelectItem>
                  <SelectItem value="7.5">7.5 hours</SelectItem>
                  <SelectItem value="8">8 hours</SelectItem>
                  <SelectItem value="8.5">8.5 hours</SelectItem>
                  <SelectItem value="9">9 hours</SelectItem>
                  <SelectItem value="9.5">9.5 hours</SelectItem>
                  <SelectItem value="10">10 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        ) : (
          <div className="space-y-2">
            <Label htmlFor="bedtime">Bedtime</Label>
            <Input
              id="bedtime"
              type="time"
              value={bedtime}
              onChange={(e) => setBedtime(e.target.value)}
            />
          </div>
        )}

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          {mode === 'bedtime' ? 'Calculate Bedtime' : 'Calculate Wake-up Times'}
        </Button>
      </div>
    </CalculatorLayout>
  );
}

