'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalculatorLayout } from '@/components/common/calculator-layout';
import { CopyButton } from '@/components/common/copy-button';
import { 
  calculatePercentage, 
  calculatePercentageOf, 
  calculatePercentageChange,
  type PercentageResult 
} from '@/lib/calculations';

type CalculationType = 'percentage' | 'percentageOf' | 'percentageChange';

export function PercentageCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>('percentage');
  const [value1, setValue1] = useState('');
  const [value2, setValue2] = useState('');
  const [result, setResult] = useState<PercentageResult | null>(null);
  const [error, setError] = useState('');

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('percentage-calculator');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setCalculationType(data.calculationType || 'percentage');
        setValue1(data.value1 || '');
        setValue2(data.value2 || '');
      } catch (err) {
        console.error('Failed to load saved data:', err);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('percentage-calculator', JSON.stringify({ 
      calculationType, 
      value1, 
      value2 
    }));
  }, [calculationType, value1, value2]);

  const handleCalculate = () => {
    setError('');
    setResult(null);

    if (!value1 || !value2) {
      setError('Please enter both values');
      return;
    }

    const num1 = parseFloat(value1);
    const num2 = parseFloat(value2);

    if (isNaN(num1) || isNaN(num2)) {
      setError('Please enter valid numbers');
      return;
    }

    try {
      let calcResult: PercentageResult;
      
      switch (calculationType) {
        case 'percentage':
          calcResult = calculatePercentage(num1, num2);
          break;
        case 'percentageOf':
          calcResult = calculatePercentageOf(num1, num2);
          break;
        case 'percentageChange':
          calcResult = calculatePercentageChange(num1, num2);
          break;
        default:
          throw new Error('Invalid calculation type');
      }
      
      setResult(calcResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const getLabels = () => {
    switch (calculationType) {
      case 'percentage':
        return { label1: 'Value', label2: 'Total', placeholder1: 'e.g., 25', placeholder2: 'e.g., 100' };
      case 'percentageOf':
        return { label1: 'Percentage', label2: 'Total', placeholder1: 'e.g., 25', placeholder2: 'e.g., 200' };
      case 'percentageChange':
        return { label1: 'Original Value', label2: 'New Value', placeholder1: 'e.g., 100', placeholder2: 'e.g., 120' };
      default:
        return { label1: 'Value 1', label2: 'Value 2', placeholder1: '', placeholder2: '' };
    }
  };

  const getResultLabel = () => {
    switch (calculationType) {
      case 'percentage':
        return 'Percentage';
      case 'percentageOf':
        return 'Result';
      case 'percentageChange':
        return 'Percentage Change';
      default:
        return 'Result';
    }
  };

  const labels = getLabels();

  const faqs = [
    {
      question: 'How do I calculate what percentage one number is of another?',
      answer: 'Use the "What percentage" option. Enter the part value and the total value. For example, 25 out of 100 is 25%.',
    },
    {
      question: 'How do I find a percentage of a number?',
      answer: 'Use the "Percentage of" option. Enter the percentage and the total. For example, 25% of 200 is 50.',
    },
    {
      question: 'How do I calculate percentage change?',
      answer: 'Use the "Percentage change" option. Enter the original value and the new value. The result shows the percentage increase or decrease.',
    },
  ];

  return (
    <CalculatorLayout
      title="Percentage Calculator"
      description="Calculate percentages, percentage change, and more"
      category="basic"
      faqs={faqs}
      result={
        result && (
          <div className="space-y-4">
            <div className="text-center p-6 bg-primary/10 rounded-lg">
              <div className="text-3xl font-bold text-primary">
                {calculationType === 'percentageOf' ? result.result : `${result.result}%`}
              </div>
              <div className="text-lg font-semibold mt-2">{getResultLabel()}</div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm">
                <strong>Formula:</strong> {result.formula}
              </p>
            </div>

            <CopyButton 
              text={`${getResultLabel()}: ${calculationType === 'percentageOf' ? result.result : `${result.result}%`}`} 
              className="w-full" 
            />
          </div>
        )
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="calculationType">Calculation Type</Label>
          <Select 
            value={calculationType} 
            onValueChange={(value: CalculationType) => setCalculationType(value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="percentage">What percentage is X of Y?</SelectItem>
              <SelectItem value="percentageOf">What is X% of Y?</SelectItem>
              <SelectItem value="percentageChange">Percentage change from X to Y</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="value1">{labels.label1}</Label>
          <Input
            id="value1"
            type="number"
            value={value1}
            onChange={(e) => setValue1(e.target.value)}
            placeholder={labels.placeholder1}
            step="0.01"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="value2">{labels.label2}</Label>
          <Input
            id="value2"
            type="number"
            value={value2}
            onChange={(e) => setValue2(e.target.value)}
            placeholder={labels.placeholder2}
            step="0.01"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 dark:text-red-400">{error}</div>
        )}

        <Button onClick={handleCalculate} className="w-full">
          Calculate
        </Button>
      </div>
    </CalculatorLayout>
  );
}

