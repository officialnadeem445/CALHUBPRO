'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Calculator as CalculatorIcon, 
  GraduationCap, 
  DollarSign, 
  Heart, 
  Clock, 
  Smile,
  ArrowRight
} from 'lucide-react';
import { calculators, categories, getCalculatorsByCategory } from '@/data/calculators';

interface CategoryPageProps {
  categoryId: string;
}

const categoryIcons = {
  basic: CalculatorIcon,
  education: GraduationCap,
  finance: DollarSign,
  health: Heart,
  datetime: Clock,
  utility: Smile,
};

export function CategoryPage({ categoryId }: CategoryPageProps) {
  const category = categories.find(cat => cat.id === categoryId);
  const categoryCalculators = getCalculatorsByCategory(categoryId);
  
  if (!category) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Category Not Found</h1>
          <p className="text-muted-foreground mt-2">The requested category does not exist.</p>
          <Link href="/">
            <Button className="mt-4">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const IconComponent = categoryIcons[categoryId as keyof typeof categoryIcons] || CalculatorIcon;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Category Header */}
      <div className="rounded-lg border p-8 mb-8 bg-muted/50">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-background rounded-lg shadow-sm">
            <IconComponent className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">{category.name} Calculators</h1>
            <p className="text-muted-foreground mt-2">
              {categoryCalculators.length} calculators available
            </p>
          </div>
        </div>
        <p className="text-lg leading-relaxed">
          Explore our collection of {category.name.toLowerCase()} calculators designed for accuracy and ease of use.
        </p>
      </div>

      {/* Calculators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {categoryCalculators.map((calculator) => (
          <Card key={calculator.id} className="group hover:shadow-lg transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg group-hover:text-primary transition-colors">
                    {calculator.title}
                  </CardTitle>
                  <CardDescription className="mt-2">
                    {calculator.description}
                  </CardDescription>
                </div>
                <Badge variant="secondary" className="ml-2 capitalize">
                  {calculator.category}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  {calculator.keywords.slice(0, 3).map((keyword) => (
                    <Badge key={keyword} variant="outline" className="text-xs">
                      {keyword}
                    </Badge>
                  ))}
                </div>
                <Link href={calculator.path}>
                  <Button size="sm" className="group/btn">
                    Try Now
                    <ArrowRight className="ml-1 h-3 w-3 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Related Categories */}
      <div className="border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Explore Other Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories
            .filter(cat => cat.id !== categoryId)
            .map((cat) => {
              const CatIcon = categoryIcons[cat.id as keyof typeof categoryIcons] || CalculatorIcon;
              const catCalculators = getCalculatorsByCategory(cat.id);
              return (
                <Link key={cat.id} href={`/category/${cat.id}`}>
                  <Card className="text-center hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <CatIcon className="h-6 w-6 mx-auto mb-2 text-primary" />
                      <h3 className="font-semibold text-sm">{cat.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {catCalculators.length} calculators
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
        </div>
      </div>
    </div>
  );
}

