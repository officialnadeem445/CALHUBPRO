'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { X, Cookie, Shield, BarChart3 } from 'lucide-react';
import { hasAnalyticsConsent, setAnalyticsConsent } from '@/lib/analytics';

export function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    // Show banner if no consent decision has been made
    const hasConsent = localStorage.getItem('analytics-consent');
    if (hasConsent === null) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    setAnalyticsConsent(true);
    setIsVisible(false);
  };

  const handleDecline = () => {
    setAnalyticsConsent(false);
    setIsVisible(false);
  };

  const handleAcceptEssential = () => {
    setAnalyticsConsent(false);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4">
      <Card className="mx-auto max-w-4xl border-2 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <Cookie className="h-6 w-6 text-primary" />
            </div>
            
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">
                We value your privacy
              </h3>
              
              {!showDetails ? (
                <div>
                  <p className="text-sm text-muted-foreground mb-4">
                    We use cookies to enhance your experience and analyze site usage. 
                    Your data helps us improve our calculators and provide better service.
                  </p>
                  
                  <div className="flex flex-wrap gap-3">
                    <Button onClick={handleAccept} size="sm">
                      Accept All
                    </Button>
                    <Button onClick={handleAcceptEssential} variant="outline" size="sm">
                      Essential Only
                    </Button>
                    <Button 
                      onClick={() => setShowDetails(true)} 
                      variant="ghost" 
                      size="sm"
                    >
                      Customize
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Choose which cookies you want to accept. You can change these settings at any time.
                  </p>
                  
                  <div className="space-y-4 mb-4">
                    <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                      <Shield className="h-5 w-5 text-green-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">Essential Cookies</h4>
                        <p className="text-xs text-muted-foreground">
                          Required for the website to function properly. Cannot be disabled.
                        </p>
                      </div>
                      <div className="text-xs text-green-600 font-medium">Always On</div>
                    </div>
                    
                    <div className="flex items-start gap-3 p-3 border rounded-lg">
                      <BarChart3 className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">Analytics Cookies</h4>
                        <p className="text-xs text-muted-foreground">
                          Help us understand how visitors use our site to improve performance and user experience.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    <Button onClick={handleAccept} size="sm">
                      Accept All
                    </Button>
                    <Button onClick={handleAcceptEssential} variant="outline" size="sm">
                      Essential Only
                    </Button>
                    <Button 
                      onClick={() => setShowDetails(false)} 
                      variant="ghost" 
                      size="sm"
                    >
                      Back
                    </Button>
                  </div>
                </div>
              )}
            </div>
            
            <Button
              onClick={handleDecline}
              variant="ghost"
              size="sm"
              className="flex-shrink-0 h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

