'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Zap, TrendingUp, Star } from 'lucide-react';

interface AdBannerProps {
  position: 'top' | 'sidebar' | 'bottom' | 'inline';
  className?: string;
}

// Sample ad content - in production, this would come from an ad network
const adContent = {
  top: {
    title: 'Boost Your Financial Knowledge',
    description: 'Learn advanced investment strategies with our premium course',
    cta: 'Get 50% Off Today',
    badge: 'Sponsored',
    icon: TrendingUp,
  },
  sidebar: {
    title: 'Premium Calculator Tools',
    description: 'Unlock advanced features and save your calculations',
    cta: 'Upgrade Now',
    badge: 'Pro',
    icon: Zap,
  },
  bottom: {
    title: 'Recommended Financial App',
    description: 'Track expenses and manage budgets with ease',
    cta: 'Download Free',
    badge: 'Partner',
    icon: Star,
  },
  inline: {
    title: 'Educational Resources',
    description: 'Free guides and tutorials for better calculations',
    cta: 'Learn More',
    badge: 'Free',
    icon: ExternalLink,
  },
};

export function AdBanner({ position, className = '' }: AdBannerProps) {
  const ad = adContent[position];
  const IconComponent = ad.icon;

  // Don't show ads in development or if explicitly disabled
  if (process.env.NODE_ENV === 'development' || process.env.NEXT_PUBLIC_DISABLE_ADS === 'true') {
    return null;
  }

  const handleAdClick = () => {
    // Track ad click
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'ad_click', {
        event_category: 'monetization',
        event_label: `${position}_banner`,
      });
    }
  };

  const getLayoutClasses = () => {
    switch (position) {
      case 'top':
        return 'w-full max-w-4xl mx-auto';
      case 'sidebar':
        return 'w-full max-w-xs';
      case 'bottom':
        return 'w-full max-w-2xl mx-auto';
      case 'inline':
        return 'w-full max-w-md';
      default:
        return 'w-full';
    }
  };

  const getContentLayout = () => {
    if (position === 'top' || position === 'bottom') {
      return 'flex items-center gap-4 p-4';
    }
    return 'p-4 text-center';
  };

  return (
    <div className={`${getLayoutClasses()} ${className}`}>
      <Card className="border-dashed border-2 border-muted-foreground/20 bg-muted/10 hover:bg-muted/20 transition-colors cursor-pointer">
        <CardContent className={getContentLayout()} onClick={handleAdClick}>
          <div className="flex-shrink-0">
            <div className="p-2 bg-primary/10 rounded-lg">
              <IconComponent className="h-6 w-6 text-primary" />
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-sm truncate">{ad.title}</h3>
              <Badge variant="secondary" className="text-xs">
                {ad.badge}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
              {ad.description}
            </p>
            <div className="flex items-center gap-1 text-xs text-primary font-medium">
              <span>{ad.cta}</span>
              <ExternalLink className="h-3 w-3" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Specific ad components for different positions
export function TopAdBanner({ className }: { className?: string }) {
  return <AdBanner position="top" className={className} />;
}

export function SidebarAdBanner({ className }: { className?: string }) {
  return <AdBanner position="sidebar" className={className} />;
}

export function BottomAdBanner({ className }: { className?: string }) {
  return <AdBanner position="bottom" className={className} />;
}

export function InlineAdBanner({ className }: { className?: string }) {
  return <AdBanner position="inline" className={className} />;
}

