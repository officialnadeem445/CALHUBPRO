import { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Users, AlertTriangle, Scale, Shield, Gavel } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Terms of Use | CalcHub Pro',
  description: 'Terms and conditions for using CalcHub Pro online calculators and services. Please read these terms carefully before using our website.',
  robots: {
    index: true,
    follow: true,
  },
};

export default function TermsOfUsePage() {
  const lastUpdated = 'January 15, 2024';

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <FileText className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold">Terms of Use</h1>
        </div>
        <p className="text-muted-foreground">
          Last updated: {lastUpdated}
        </p>
      </div>

      <div className="space-y-8">
        {/* Introduction */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Agreement to Terms
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Welcome to CalcHub Pro! These Terms of Use ("Terms") govern your use of our website 
              and online calculator services. By accessing or using CalcHub Pro, you agree to be 
              bound by these Terms and our Privacy Policy.
            </p>
            <p>
              <strong>If you do not agree to these Terms, please do not use our services.</strong>
            </p>
          </CardContent>
        </Card>

        {/* Service Description */}
        <Card>
          <CardHeader>
            <CardTitle>Our Services</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              CalcHub Pro provides free online calculators and utilities for various purposes including:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Basic mathematical calculations</li>
              <li>Financial and business calculations</li>
              <li>Health and fitness calculations</li>
              <li>Educational tools and grade calculators</li>
              <li>Date, time, and utility calculators</li>
              <li>Unit conversion tools</li>
            </ul>
            <p>
              All calculations are performed locally in your browser for privacy and speed. 
              We do not store your calculation data on our servers.
            </p>
          </CardContent>
        </Card>

        {/* Acceptable Use */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Acceptable Use
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">You May:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Use our calculators for personal, educational, or commercial purposes</li>
                <li>Share links to our calculators with others</li>
                <li>Bookmark and return to use our services</li>
                <li>Provide feedback and suggestions for improvement</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">You May Not:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Attempt to reverse engineer, decompile, or hack our website</li>
                <li>Use automated tools to scrape or download our content</li>
                <li>Interfere with the proper functioning of our services</li>
                <li>Use our services for illegal or harmful activities</li>
                <li>Violate any applicable laws or regulations</li>
                <li>Impersonate others or provide false information</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Accuracy Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Accuracy and Reliability
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 p-4 rounded-lg">
              <p className="font-semibold text-amber-800 dark:text-amber-200 mb-2">
                Important Notice
              </p>
              <p className="text-sm text-amber-700 dark:text-amber-300">
                While we strive for accuracy, our calculators are provided for informational purposes only. 
                Always verify important calculations with professional tools or consult qualified professionals 
                for critical decisions.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Our Commitment</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>We use industry-standard formulas and algorithms</li>
                <li>We regularly test and update our calculators</li>
                <li>We welcome feedback about errors or improvements</li>
                <li>We provide clear documentation for complex calculations</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Your Responsibility</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Verify results for important financial or health decisions</li>
                <li>Consult professionals for complex calculations</li>
                <li>Use appropriate calculators for your specific needs</li>
                <li>Report any errors or inconsistencies you discover</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Intellectual Property */}
        <Card>
          <CardHeader>
            <CardTitle>Intellectual Property</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Our Content</h3>
              <p className="text-sm">
                The CalcHub Pro website, including its design, code, text, graphics, and functionality, 
                is owned by us and protected by copyright and other intellectual property laws. 
                You may not copy, modify, or distribute our content without permission.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Your Content</h3>
              <p className="text-sm">
                Any feedback, suggestions, or ideas you provide to us may be used to improve our services 
                without compensation or attribution, unless otherwise agreed in writing.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Third-Party Content</h3>
              <p className="text-sm">
                We may include links to third-party websites or services. We do not control or endorse 
                these external resources and are not responsible for their content or practices.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Limitation of Liability */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scale className="h-5 w-5" />
              Limitation of Liability
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 p-4 rounded-lg">
              <p className="font-semibold text-red-800 dark:text-red-200 mb-2">
                Disclaimer of Warranties
              </p>
              <p className="text-sm text-red-700 dark:text-red-300">
                Our services are provided "as is" without warranties of any kind. We do not guarantee 
                that our calculators will be error-free, uninterrupted, or suitable for your specific needs.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Limitation of Damages</h3>
              <p className="text-sm">
                To the maximum extent permitted by law, we shall not be liable for any indirect, 
                incidental, special, or consequential damages arising from your use of our services, 
                including but not limited to:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm mt-2">
                <li>Financial losses due to calculation errors</li>
                <li>Business interruption or lost profits</li>
                <li>Data loss or corruption</li>
                <li>Personal injury or property damage</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Maximum Liability</h3>
              <p className="text-sm">
                Our total liability to you for any claims arising from these Terms or your use of 
                our services shall not exceed $100 USD or the amount you paid us in the past 12 months, 
                whichever is greater.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Privacy */}
        <Card>
          <CardHeader>
            <CardTitle>Privacy and Data Protection</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Your privacy is important to us. Our collection and use of your information is governed 
              by our Privacy Policy, which is incorporated into these Terms by reference. Please review 
              our Privacy Policy to understand our practices.
            </p>
          </CardContent>
        </Card>

        {/* Modifications */}
        <Card>
          <CardHeader>
            <CardTitle>Changes to Terms</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              We may update these Terms from time to time to reflect changes in our services, 
              legal requirements, or business practices. When we make material changes, we will:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Update the "Last updated" date at the top of this page</li>
              <li>Notify users through our website or email (if applicable)</li>
              <li>Provide a reasonable notice period before changes take effect</li>
            </ul>
            <p>
              Your continued use of our services after changes take effect constitutes acceptance 
              of the updated Terms.
            </p>
          </CardContent>
        </Card>

        {/* Termination */}
        <Card>
          <CardHeader>
            <CardTitle>Termination</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Your Rights</h3>
              <p className="text-sm">
                You may stop using our services at any time. Your locally stored data will remain 
                in your browser until you clear it.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Our Rights</h3>
              <p className="text-sm">
                We may suspend or terminate your access to our services if you violate these Terms 
                or engage in harmful activities. We will provide notice when reasonably possible.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Governing Law */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gavel className="h-5 w-5" />
              Governing Law and Disputes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Applicable Law</h3>
              <p className="text-sm">
                These Terms are governed by the laws of [Your Jurisdiction], without regard to 
                conflict of law principles.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Dispute Resolution</h3>
              <p className="text-sm">
                We encourage resolving disputes through direct communication. If formal legal action 
                becomes necessary, disputes will be resolved in the courts of [Your Jurisdiction].
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              If you have questions about these Terms of Use, please contact us:
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <p><strong>Email:</strong> legal@calchub-pro.com</p>
              <p><strong>Subject Line:</strong> Terms of Use Inquiry</p>
              <p><strong>Response Time:</strong> We aim to respond within 48 hours</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

