import { Metadata } from 'next';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, ArrowRight, TrendingUp, BookOpen, Calculator } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Calculator Tips & Guides | CalcHub Pro Blog',
  description: 'Learn how to use calculators effectively with our comprehensive guides, tips, and tutorials. Master financial, health, and educational calculations.',
  keywords: ['calculator guides', 'math tips', 'financial calculations', 'calculator tutorials', 'how to calculate'],
  openGraph: {
    title: 'Calculator Tips & Guides | CalcHub Pro Blog',
    description: 'Learn how to use calculators effectively with our comprehensive guides, tips, and tutorials.',
    type: 'website',
  },
};

// Sample blog posts data
const blogPosts = [
  {
    id: 1,
    title: 'How to Calculate Your Ideal Body Weight: A Comprehensive Guide',
    excerpt: 'Learn different methods to calculate your ideal body weight, including BMI, body fat percentage, and other health metrics.',
    category: 'Health',
    readTime: '5 min read',
    publishDate: '2024-01-15',
    slug: 'calculate-ideal-body-weight-guide',
    featured: true,
  },
  {
    id: 2,
    title: 'Understanding Compound Interest: Make Your Money Work for You',
    excerpt: 'Master the power of compound interest with practical examples and learn how to calculate returns on your investments.',
    category: 'Finance',
    readTime: '7 min read',
    publishDate: '2024-01-12',
    slug: 'compound-interest-guide',
    featured: true,
  },
  {
    id: 3,
    title: 'GPA Calculation Made Simple: A Student\'s Complete Guide',
    excerpt: 'Everything you need to know about calculating GPA, including weighted grades, credit hours, and different grading systems.',
    category: 'Education',
    readTime: '6 min read',
    publishDate: '2024-01-10',
    slug: 'gpa-calculation-guide',
    featured: false,
  },
  {
    id: 4,
    title: 'Loan EMI Calculator: How to Plan Your Home Loan',
    excerpt: 'Learn how to use EMI calculators effectively to plan your home loan and understand amortization schedules.',
    category: 'Finance',
    readTime: '8 min read',
    publishDate: '2024-01-08',
    slug: 'loan-emi-planning-guide',
    featured: false,
  },
  {
    id: 5,
    title: 'Percentage Calculations in Real Life: Practical Examples',
    excerpt: 'Discover how percentage calculations apply to everyday situations like discounts, tips, taxes, and business metrics.',
    category: 'Math',
    readTime: '4 min read',
    publishDate: '2024-01-05',
    slug: 'percentage-calculations-real-life',
    featured: false,
  },
  {
    id: 6,
    title: 'Time Zone Conversions: A Global Professional\'s Guide',
    excerpt: 'Master time zone calculations for international business, travel planning, and remote work coordination.',
    category: 'Utility',
    readTime: '5 min read',
    publishDate: '2024-01-03',
    slug: 'time-zone-conversion-guide',
    featured: false,
  },
];

const categories = ['All', 'Finance', 'Health', 'Education', 'Math', 'Utility'];

export default function BlogPage() {
  const featuredPosts = blogPosts.filter(post => post.featured);
  const regularPosts = blogPosts.filter(post => !post.featured);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2 mb-4">
          <BookOpen className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold">Calculator Guides & Tips</h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Master the art of calculations with our comprehensive guides, tutorials, and practical tips for everyday math.
        </p>
      </div>

      {/* Featured Posts */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <TrendingUp className="h-6 w-6 text-primary" />
          Featured Articles
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {featuredPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary">{post.category}</Badge>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="group-hover:text-primary transition-colors">
                  {post.title}
                </CardTitle>
                <CardDescription className="text-base">
                  {post.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    {new Date(post.publishDate).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </div>
                  <Button variant="ghost" size="sm" className="group/btn">
                    Read More
                    <ArrowRight className="ml-1 h-3 w-3 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Category Filter */}
      <section className="mb-8">
        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map((category) => (
            <Button
              key={category}
              variant={category === 'All' ? 'default' : 'outline'}
              size="sm"
              className="rounded-full"
            >
              {category}
            </Button>
          ))}
        </div>
      </section>

      {/* All Posts */}
      <section>
        <h2 className="text-2xl font-bold mb-6">All Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="text-xs">
                    {post.category}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="text-lg group-hover:text-primary transition-colors line-clamp-2">
                  {post.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {new Date(post.publishDate).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric'
                    })}
                  </div>
                  <Button variant="ghost" size="sm" className="text-xs h-8">
                    Read More
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="mt-16 text-center">
        <div className="bg-primary/5 rounded-lg p-8">
          <Calculator className="h-12 w-12 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Ready to Start Calculating?</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Put your knowledge to practice with our comprehensive collection of online calculators.
          </p>
          <Link href="/">
            <Button size="lg">
              Explore Calculators
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}

