import { Metadata } from 'next';
import { CurrencyConverter } from '@/components/calculators/currency-converter';

export const metadata: Metadata = {
  title: 'Currency Converter - Live Exchange Rates | CalcHub Pro',
  description: 'Convert between different currencies with live exchange rates. Supports major world currencies including USD, EUR, GBP, JPY, and more.',
  keywords: ['currency converter', 'exchange rates', 'currency calculator', 'foreign exchange', 'forex converter'],
  openGraph: {
    title: 'Currency Converter - Live Exchange Rates',
    description: 'Convert between different currencies with live exchange rates. Supports major world currencies including USD, EUR, GBP, JPY, and more.',
    type: 'website',
  },
};

export default function CurrencyConverterPage() {
  return <CurrencyConverter />;
}

