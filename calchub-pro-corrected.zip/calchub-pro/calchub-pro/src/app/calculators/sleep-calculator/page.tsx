import { Metadata } from 'next';
import { SleepCalculator } from '@/components/calculators/sleep-calculator';

export const metadata: Metadata = {
  title: 'Sleep Calculator - Optimal Bedtime & Wake-up Times | CalcHub Pro',
  description: 'Calculate optimal bedtime and wake-up times based on sleep cycles. Improve your sleep quality with science-based recommendations.',
  keywords: ['sleep calculator', 'bedtime calculator', 'wake up time calculator', 'sleep cycles', 'sleep quality'],
  openGraph: {
    title: 'Sleep Calculator - Optimal Bedtime & Wake-up Times',
    description: 'Calculate optimal bedtime and wake-up times based on sleep cycles. Improve your sleep quality with science-based recommendations.',
    type: 'website',
  },
};

export default function SleepCalculatorPage() {
  return <SleepCalculator />;
}

