import { Metadata } from 'next';
import { TipCalculator } from '@/components/calculators/tip-calculator';

export const metadata: Metadata = {
  title: 'Tip Calculator - Calculate Tips & Split Bills | CalcHub Pro',
  description: 'Calculate tips and split bills easily. Perfect for restaurants, delivery, and service industries with customizable tip percentages.',
  keywords: ['tip calculator', 'bill splitter', 'restaurant tip', 'gratuity calculator', 'split bill calculator'],
  openGraph: {
    title: 'Tip Calculator - Calculate Tips & Split Bills',
    description: 'Calculate tips and split bills easily. Perfect for restaurants, delivery, and service industries with customizable tip percentages.',
    type: 'website',
  },
};

export default function TipCalculatorPage() {
  return <TipCalculator />;
}

