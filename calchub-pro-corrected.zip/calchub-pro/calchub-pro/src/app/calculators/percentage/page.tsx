import { Metadata } from 'next';
import { PercentageCalculator } from '@/components/calculators/percentage-calculator';

export const metadata: Metadata = {
  title: 'Percentage Calculator - Calculate Percentages & Changes | CalcHub Pro',
  description: 'Calculate percentages, percentage of numbers, and percentage changes. Easy-to-use percentage calculator with step-by-step formulas.',
  keywords: ['percentage calculator', 'percent calculator', 'percentage change', 'percentage of', 'math calculator'],
  openGraph: {
    title: 'Percentage Calculator - Calculate Percentages & Changes',
    description: 'Calculate percentages, percentage of numbers, and percentage changes. Easy-to-use percentage calculator with step-by-step formulas.',
    type: 'website',
  },
};

export default function PercentageCalculatorPage() {
  return <PercentageCalculator />;
}

