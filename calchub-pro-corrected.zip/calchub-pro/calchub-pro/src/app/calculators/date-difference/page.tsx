import { Metadata } from 'next';
import { DateDifferenceCalculator } from '@/components/calculators/date-difference-calculator';

export const metadata: Metadata = {
  title: 'Date Difference Calculator - Calculate Days Between Dates | CalcHub Pro',
  description: 'Calculate the difference between two dates in years, months, days, business days, and more. Perfect for project planning and date calculations.',
  keywords: ['date difference calculator', 'days between dates', 'business days calculator', 'date calculator', 'time difference'],
  openGraph: {
    title: 'Date Difference Calculator - Calculate Days Between Dates',
    description: 'Calculate the difference between two dates in years, months, days, business days, and more. Perfect for project planning and date calculations.',
    type: 'website',
  },
};

export default function DateDifferenceCalculatorPage() {
  return <DateDifferenceCalculator />;
}

