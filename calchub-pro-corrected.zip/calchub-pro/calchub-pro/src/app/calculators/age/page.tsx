import { Metadata } from 'next';
import { AgeCalculator } from '@/components/calculators/age-calculator';

export const metadata: Metadata = {
  title: 'Age Calculator - Calculate Your Exact Age | CalcHub Pro',
  description: 'Calculate your exact age in years, months, and days. Find out how many days you\'ve been alive and when your next birthday is.',
  keywords: ['age calculator', 'calculate age', 'birthday calculator', 'days alive', 'age in days'],
  openGraph: {
    title: 'Age Calculator - Calculate Your Exact Age',
    description: 'Calculate your exact age in years, months, and days. Find out how many days you\'ve been alive and when your next birthday is.',
    type: 'website',
  },
};

export default function AgeCalculatorPage() {
  return <AgeCalculator />;
}

