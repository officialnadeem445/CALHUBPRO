import { Metadata } from 'next';
import { PasswordGenerator } from '@/components/calculators/password-generator';

export const metadata: Metadata = {
  title: 'Password Generator - Create Secure Passwords | CalcHub Pro',
  description: 'Generate strong, secure passwords with customizable options. Includes password strength analysis and entropy calculation for maximum security.',
  keywords: ['password generator', 'secure password', 'random password', 'password strength', 'password security'],
  openGraph: {
    title: 'Password Generator - Create Secure Passwords',
    description: 'Generate strong, secure passwords with customizable options. Includes password strength analysis and entropy calculation for maximum security.',
    type: 'website',
  },
};

export default function PasswordGeneratorPage() {
  return <PasswordGenerator />;
}

