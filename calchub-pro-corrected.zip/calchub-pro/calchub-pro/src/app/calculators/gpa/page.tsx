import { Metadata } from 'next';
import { GPACalculator } from '@/components/calculators/gpa-calculator';

export const metadata: Metadata = {
  title: 'GPA Calculator - Grade Point Average Calculator | CalcHub Pro',
  description: 'Calculate your GPA (Grade Point Average) with custom course weights and credits. Supports 4.0 scale with decimal grades.',
  keywords: ['gpa calculator', 'grade point average', 'cgpa calculator', 'student calculator', 'academic calculator'],
  openGraph: {
    title: 'GPA Calculator - Grade Point Average Calculator',
    description: 'Calculate your GPA (Grade Point Average) with custom course weights and credits. Supports 4.0 scale with decimal grades.',
    type: 'website',
  },
};

export default function GPACalculatorPage() {
  return <GPACalculator />;
}

