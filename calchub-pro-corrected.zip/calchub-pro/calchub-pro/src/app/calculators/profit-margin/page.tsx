import { Metadata } from 'next';
import { ProfitMarginCalculator } from '@/components/calculators/profit-margin-calculator';

export const metadata: Metadata = {
  title: 'Profit Margin Calculator - Calculate Business Profitability | CalcHub Pro',
  description: 'Calculate profit margin, markup, and find optimal selling prices. Essential tool for business owners and entrepreneurs.',
  keywords: ['profit margin calculator', 'markup calculator', 'business calculator', 'pricing calculator', 'profitability calculator'],
  openGraph: {
    title: 'Profit Margin Calculator - Calculate Business Profitability',
    description: 'Calculate profit margin, markup, and find optimal selling prices. Essential tool for business owners and entrepreneurs.',
    type: 'website',
  },
};

export default function ProfitMarginCalculatorPage() {
  return <ProfitMarginCalculator />;
}

