import { Metadata } from 'next';
import { MarksPercentageCalculator } from '@/components/calculators/marks-percentage-calculator';

export const metadata: Metadata = {
  title: 'Marks Percentage Calculator - Calculate Grade Percentage | CalcHub Pro',
  description: 'Calculate percentage from obtained marks and total marks. Includes grade scale reference and formula explanation.',
  keywords: ['marks percentage calculator', 'grade percentage', 'exam percentage', 'marks calculator', 'student calculator'],
  openGraph: {
    title: 'Marks Percentage Calculator - Calculate Grade Percentage',
    description: 'Calculate percentage from obtained marks and total marks. Includes grade scale reference and formula explanation.',
    type: 'website',
  },
};

export default function MarksPercentageCalculatorPage() {
  return <MarksPercentageCalculator />;
}

