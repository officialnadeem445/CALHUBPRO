import { Metadata } from 'next';
import { BMICalculator } from '@/components/calculators/bmi-calculator';

export const metadata: Metadata = {
  title: 'BMI Calculator - Body Mass Index Calculator | CalcHub Pro',
  description: 'Calculate your Body Mass Index (BMI) and determine your health status. Supports both metric and imperial units.',
  keywords: ['bmi calculator', 'body mass index', 'weight calculator', 'health calculator', 'obesity calculator'],
  openGraph: {
    title: 'BMI Calculator - Body Mass Index Calculator',
    description: 'Calculate your Body Mass Index (BMI) and determine your health status. Supports both metric and imperial units.',
    type: 'website',
  },
};

export default function BMICalculatorPage() {
  return <BMICalculator />;
}

