import { Metadata } from 'next';
import { InterestCalculator } from '@/components/calculators/interest-calculator';

export const metadata: Metadata = {
  title: 'Interest Calculator - Simple & Compound Interest | CalcHub Pro',
  description: 'Calculate simple and compound interest with different compounding frequencies. Compare returns and see the power of compound interest.',
  keywords: ['interest calculator', 'compound interest', 'simple interest', 'investment calculator', 'savings calculator'],
  openGraph: {
    title: 'Interest Calculator - Simple & Compound Interest',
    description: 'Calculate simple and compound interest with different compounding frequencies. Compare returns and see the power of compound interest.',
    type: 'website',
  },
};

export default function InterestCalculatorPage() {
  return <InterestCalculator />;
}

