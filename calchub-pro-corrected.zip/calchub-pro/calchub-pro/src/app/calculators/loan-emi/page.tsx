import { Metadata } from 'next';
import { LoanEMICalculator } from '@/components/calculators/loan-emi-calculator';

export const metadata: Metadata = {
  title: 'Loan EMI Calculator - Calculate Monthly Payments | CalcHub Pro',
  description: 'Calculate loan EMI (Equated Monthly Installment) with detailed amortization schedule. Download payment schedule as CSV.',
  keywords: ['loan emi calculator', 'mortgage calculator', 'loan payment calculator', 'amortization calculator', 'monthly payment'],
  openGraph: {
    title: 'Loan EMI Calculator - Calculate Monthly Payments',
    description: 'Calculate loan EMI (Equated Monthly Installment) with detailed amortization schedule. Download payment schedule as CSV.',
    type: 'website',
  },
};

export default function LoanEMICalculatorPage() {
  return <LoanEMICalculator />;
}

