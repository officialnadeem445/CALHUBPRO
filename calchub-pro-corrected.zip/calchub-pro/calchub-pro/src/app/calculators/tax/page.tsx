import { Metadata } from 'next';
import { TaxCalculator } from '@/components/calculators/tax-calculator';

export const metadata: Metadata = {
  title: 'Tax Calculator - Income Tax Calculator | CalcHub Pro',
  description: 'Calculate income tax with progressive tax brackets for US, UK, Canada, and India. Includes tax breakdown and effective rate calculation.',
  keywords: ['tax calculator', 'income tax calculator', 'tax brackets', 'effective tax rate', 'tax planning'],
  openGraph: {
    title: 'Tax Calculator - Income Tax Calculator',
    description: 'Calculate income tax with progressive tax brackets for US, UK, Canada, and India. Includes tax breakdown and effective rate calculation.',
    type: 'website',
  },
};

export default function TaxCalculatorPage() {
  return <TaxCalculator />;
}

