import { Metadata } from 'next';
import { UnitConverter } from '@/components/calculators/unit-converter';

export const metadata: Metadata = {
  title: 'Unit Converter - Convert Length, Weight, Temperature & More | CalcHub Pro',
  description: 'Convert between different units of measurement including length, weight, temperature, volume, area, and speed. Accurate metric and imperial conversions.',
  keywords: ['unit converter', 'metric conversion', 'imperial conversion', 'length converter', 'weight converter', 'temperature converter'],
  openGraph: {
    title: 'Unit Converter - Convert Length, Weight, Temperature & More',
    description: 'Convert between different units of measurement including length, weight, temperature, volume, area, and speed. Accurate metric and imperial conversions.',
    type: 'website',
  },
};

export default function UnitConverterPage() {
  return <UnitConverter />;
}

