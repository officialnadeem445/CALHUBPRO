import { Metadata } from 'next';
import { CalorieNeedsCalculator } from '@/components/calculators/calorie-needs-calculator';

export const metadata: Metadata = {
  title: 'Calorie Needs Calculator - BMR & TDEE Calculator | CalcHub Pro',
  description: 'Calculate your daily calorie needs with BMR and TDEE calculations. Includes weight loss and weight gain calorie recommendations.',
  keywords: ['calorie calculator', 'BMR calculator', 'TDEE calculator', 'daily calorie needs', 'weight loss calculator'],
  openGraph: {
    title: 'Calorie Needs Calculator - BMR & TDEE Calculator',
    description: 'Calculate your daily calorie needs with BMR and TDEE calculations. Includes weight loss and weight gain calorie recommendations.',
    type: 'website',
  },
};

export default function CalorieNeedsCalculatorPage() {
  return <CalorieNeedsCalculator />;
}

