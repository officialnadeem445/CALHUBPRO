import { Metadata } from 'next';
import { ScientificCalculator } from '@/components/calculators/scientific-calculator';

export const metadata: Metadata = {
  title: 'Scientific Calculator - Advanced Math Calculator | CalcHub Pro',
  description: 'Advanced scientific calculator with trigonometric functions, logarithms, square roots, and more. Perfect for students and professionals.',
  keywords: ['scientific calculator', 'trigonometry calculator', 'logarithm calculator', 'advanced calculator', 'math calculator'],
  openGraph: {
    title: 'Scientific Calculator - Advanced Math Calculator',
    description: 'Advanced scientific calculator with trigonometric functions, logarithms, square roots, and more. Perfect for students and professionals.',
    type: 'website',
  },
};

export default function ScientificCalculatorPage() {
  return <ScientificCalculator />;
}

