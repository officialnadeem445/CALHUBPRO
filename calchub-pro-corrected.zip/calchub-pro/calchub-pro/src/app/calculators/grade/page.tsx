import { Metadata } from 'next';
import { GradeCalculator } from '@/components/calculators/grade-calculator';

export const metadata: Metadata = {
  title: 'Grade Calculator - Calculate Required Final Grade | CalcHub Pro',
  description: 'Calculate what grade you need on your final exam or assignment to achieve your target overall grade. Perfect for students planning their studies.',
  keywords: ['grade calculator', 'final grade calculator', 'required grade', 'student calculator', 'exam calculator'],
  openGraph: {
    title: 'Grade Calculator - Calculate Required Final Grade',
    description: 'Calculate what grade you need on your final exam or assignment to achieve your target overall grade. Perfect for students planning their studies.',
    type: 'website',
  },
};

export default function GradeCalculatorPage() {
  return <GradeCalculator />;
}

