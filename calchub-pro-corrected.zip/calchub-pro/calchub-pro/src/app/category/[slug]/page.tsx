import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { CategoryPage } from '@/components/category/category-page';
import { categories, getCalculatorsByCategory } from '@/data/calculators';
import { generateCategorySEO } from '@/lib/seo';

interface CategoryPageProps {
  params: {
    slug: string;
  };
}

export async function generateStaticParams() {
  return categories.map((category) => ({
    slug: category.id,
  }));
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const category = categories.find(cat => cat.id === params.slug);
  
  if (!category) {
    return {
      title: 'Category Not Found | CalcHub Pro',
      description: 'The requested calculator category was not found.',
    };
  }

  const calculatorList = getCalculatorsByCategory(params.slug);
  const calculatorNames = calculatorList.map(calc => calc.title);
  const seoData = generateCategorySEO(category.name, calculatorList.length, calculatorNames);

  return {
    title: seoData.title,
    description: seoData.description,
    keywords: seoData.keywords,
    openGraph: {
      title: seoData.title,
      description: seoData.description,
      type: 'website',
      url: `https://calchub-pro.com/category/${params.slug}`,
    },
    twitter: {
      card: 'summary_large_image',
      title: seoData.title,
      description: seoData.description,
    },
    other: {
      'application/ld+json': JSON.stringify(seoData.structuredData),
    },
  };
}

export default function CategoryPageRoute({ params }: CategoryPageProps) {
  const category = categories.find(cat => cat.id === params.slug);
  
  if (!category) {
    notFound();
  }

  return <CategoryPage categoryId={params.slug} />;
}

