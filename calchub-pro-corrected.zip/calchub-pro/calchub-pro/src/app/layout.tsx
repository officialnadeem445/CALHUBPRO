import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { GoogleAnalytics, PlausibleAnalytics } from '@/components/analytics/google-analytics';
import { CookieBanner } from '@/components/common/cookie-banner';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'CalcHub Pro - Online Calculators & Utilities',
  description:
    'Fast, accurate online calculators for students, creators, and professionals. Calculate age, BMI, loans, taxes, and more.',
  keywords: [
    'calculator',
    'online calculator',
    'math calculator',
    'financial calculator',
    'health calculator',
    'utility tools',
  ],
  authors: [{ name: 'CalcHub Pro' }],
  creator: 'CalcHub Pro',
  publisher: 'CalcHub Pro',
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: '/',
    title: 'CalcHub Pro - Online Calculators & Utilities',
    description:
      'Fast, accurate online calculators for students, creators, and professionals. Calculate age, BMI, loans, taxes, and more.',
    siteName: 'CalcHub Pro',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CalcHub Pro - Online Calculators & Utilities',
    description:
      'Fast, accurate online calculators for students, creators, and professionals. Calculate age, BMI, loans, taxes, and more.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <CookieBanner />
        </ThemeProvider>
        <GoogleAnalytics />
        <PlausibleAnalytics />
      </body>
    </html>
  );
}
