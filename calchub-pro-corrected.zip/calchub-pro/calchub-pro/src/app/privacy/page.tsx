import { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Eye, Cookie, Database, Lock, Mail } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Privacy Policy | CalcHub Pro',
  description: 'Learn how CalcHub Pro protects your privacy and handles your data. We are committed to transparency and user privacy.',
  robots: {
    index: true,
    follow: true,
  },
};

export default function PrivacyPolicyPage() {
  const lastUpdated = 'January 15, 2024';

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Shield className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold">Privacy Policy</h1>
        </div>
        <p className="text-muted-foreground">
          Last updated: {lastUpdated}
        </p>
      </div>

      <div className="space-y-8">
        {/* Introduction */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Our Commitment to Privacy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              At CalcHub Pro, we are committed to protecting your privacy and ensuring transparency 
              about how we collect, use, and protect your information. This Privacy Policy explains 
              our practices regarding your personal data when you use our online calculator services.
            </p>
            <p>
              <strong>Key Principle:</strong> All calculations are performed locally in your browser. 
              Your calculation data never leaves your device unless you explicitly choose to share it.
            </p>
          </CardContent>
        </Card>

        {/* Information We Collect */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Information We Collect
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Information You Provide</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Calculator inputs and preferences (stored locally in your browser)</li>
                <li>Search queries within our website</li>
                <li>Feedback or contact information when you reach out to us</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Information We Collect Automatically</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Usage analytics (page views, calculator usage, session duration)</li>
                <li>Device information (browser type, operating system, screen resolution)</li>
                <li>IP address and general location (country/region level only)</li>
                <li>Referrer information (which website directed you to us)</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Local Storage</h3>
              <p className="text-sm">
                We use your browser's local storage to save your calculator preferences and recent 
                inputs for your convenience. This data remains on your device and is not transmitted to our servers.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* How We Use Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              How We Use Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Service Improvement</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Analyze usage patterns to improve calculator functionality</li>
                <li>Identify and fix technical issues</li>
                <li>Develop new calculators based on user needs</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Communication</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Respond to your inquiries and support requests</li>
                <li>Send important service updates (if you've subscribed)</li>
                <li>Provide educational content about calculations (optional)</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Legal Compliance</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Comply with applicable laws and regulations</li>
                <li>Protect our rights and prevent misuse of our services</li>
                <li>Respond to legal requests from authorities</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Cookies and Tracking */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cookie className="h-5 w-5" />
              Cookies and Tracking Technologies
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Essential Cookies</h3>
              <p className="text-sm">
                Required for the website to function properly. These include session management, 
                security features, and accessibility preferences. These cannot be disabled.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Analytics Cookies</h3>
              <p className="text-sm">
                Help us understand how visitors use our site through Google Analytics and Plausible Analytics. 
                These are only activated with your consent and can be disabled at any time.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Your Cookie Choices</h3>
              <p className="text-sm">
                You can manage your cookie preferences through our cookie banner or your browser settings. 
                Disabling analytics cookies will not affect the functionality of our calculators.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Data Sharing */}
        <Card>
          <CardHeader>
            <CardTitle>Data Sharing and Third Parties</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              <strong>We do not sell your personal data.</strong> We may share information only in these limited circumstances:
            </p>
            
            <div>
              <h3 className="font-semibold mb-2">Service Providers</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Google Analytics (with IP anonymization enabled)</li>
                <li>Plausible Analytics (privacy-focused, GDPR compliant)</li>
                <li>Hosting providers (Vercel/Netlify) for website delivery</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Legal Requirements</h3>
              <p className="text-sm">
                We may disclose information if required by law, court order, or to protect our rights and safety.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Your Rights */}
        <Card>
          <CardHeader>
            <CardTitle>Your Privacy Rights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Access and Control</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Access your locally stored calculator data through browser developer tools</li>
                <li>Delete your local data by clearing browser storage</li>
                <li>Opt out of analytics tracking through our cookie preferences</li>
                <li>Request deletion of any data we may have collected about you</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">GDPR Rights (EU Users)</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Right to access your personal data</li>
                <li>Right to rectification of inaccurate data</li>
                <li>Right to erasure ("right to be forgotten")</li>
                <li>Right to restrict processing</li>
                <li>Right to data portability</li>
                <li>Right to object to processing</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card>
          <CardHeader>
            <CardTitle>Data Security</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              We implement appropriate technical and organizational measures to protect your information:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>HTTPS encryption for all data transmission</li>
              <li>Local processing of sensitive calculation data</li>
              <li>Regular security updates and monitoring</li>
              <li>Limited data collection and retention</li>
              <li>Secure hosting infrastructure</li>
            </ul>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Contact Us
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              If you have questions about this Privacy Policy or want to exercise your privacy rights, please contact us:
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <p><strong>Email:</strong> privacy@calchub-pro.com</p>
              <p><strong>Response Time:</strong> We aim to respond within 48 hours</p>
            </div>
          </CardContent>
        </Card>

        {/* Updates */}
        <Card>
          <CardHeader>
            <CardTitle>Policy Updates</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of any material 
              changes by posting the new Privacy Policy on this page and updating the "Last updated" date. 
              We encourage you to review this Privacy Policy periodically.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

