import { HeroSection } from '@/components/home/hero-section';
import { CategoriesSection } from '@/components/home/categories-section';
import { FeaturesSection } from '@/components/home/features-section';
import { TopAdBanner, BottomAdBanner } from '@/components/common/ad-banner';

export default function Home() {
  return (
    <div className="space-y-8">
      <TopAdBanner className="mt-4" />
      <HeroSection />
      <CategoriesSection />
      <FeaturesSection />
      <BottomAdBanner className="mb-4" />
    </div>
  );
}
