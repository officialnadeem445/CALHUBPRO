import { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Heart, DollarSign, GraduationCap, Calculator, Info } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Disclaimer | CalcHub Pro',
  description: 'Important disclaimers for CalcHub Pro calculators. Please read these disclaimers before using our financial, health, or educational calculators.',
  robots: {
    index: true,
    follow: true,
  },
};

export default function DisclaimerPage() {
  const lastUpdated = 'January 15, 2024';

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <AlertTriangle className="h-8 w-8 text-amber-500" />
          <h1 className="text-4xl font-bold">Disclaimer</h1>
        </div>
        <p className="text-muted-foreground">
          Last updated: {lastUpdated}
        </p>
      </div>

      <div className="space-y-8">
        {/* General Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              General Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 p-4 rounded-lg">
              <p className="font-semibold text-amber-800 dark:text-amber-200 mb-2">
                Important Notice
              </p>
              <p className="text-sm text-amber-700 dark:text-amber-300">
                The calculators and tools provided by CalcHub Pro are for informational and educational 
                purposes only. While we strive for accuracy, we cannot guarantee that all calculations 
                are error-free or suitable for your specific situation.
              </p>
            </div>
            
            <p>
              <strong>Use at Your Own Risk:</strong> You acknowledge that you use our calculators at your own risk 
              and that you are responsible for verifying the accuracy of any results before making important decisions.
            </p>
            
            <p>
              <strong>No Professional Advice:</strong> Our calculators do not constitute professional advice of any kind. 
              Always consult with qualified professionals for important financial, health, legal, or educational decisions.
            </p>
          </CardContent>
        </Card>

        {/* Financial Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-600" />
              Financial Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 p-4 rounded-lg">
              <p className="font-semibold text-green-800 dark:text-green-200 mb-2">
                Financial Calculations Notice
              </p>
              <p className="text-sm text-green-700 dark:text-green-300">
                Our financial calculators (loan EMI, tax, profit margin, currency converter, etc.) 
                provide estimates based on the information you provide. Actual results may vary.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Important Considerations:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li><strong>Loan Calculations:</strong> Actual loan terms, fees, and interest rates may differ from calculations</li>
                <li><strong>Tax Calculations:</strong> Tax laws are complex and change frequently; consult a tax professional</li>
                <li><strong>Investment Returns:</strong> Past performance does not guarantee future results</li>
                <li><strong>Currency Conversion:</strong> Exchange rates fluctuate constantly; verify current rates</li>
                <li><strong>Business Calculations:</strong> Consider all factors affecting your specific business situation</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Professional Consultation Required:</h3>
              <p className="text-sm">
                For significant financial decisions, always consult with qualified financial advisors, 
                accountants, tax professionals, or other relevant experts who can consider your complete 
                financial situation and applicable laws.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">No Investment Advice:</h3>
              <p className="text-sm">
                Nothing on this website constitutes investment advice, financial planning advice, 
                or recommendations to buy or sell any financial instruments. We are not licensed 
                financial advisors or investment professionals.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Health Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-red-500" />
              Health and Medical Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 p-4 rounded-lg">
              <p className="font-semibold text-red-800 dark:text-red-200 mb-2">
                Medical Information Notice
              </p>
              <p className="text-sm text-red-700 dark:text-red-300">
                Our health calculators (BMI, calorie needs, sleep calculator, etc.) are for informational 
                purposes only and do not constitute medical advice, diagnosis, or treatment recommendations.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Important Health Considerations:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li><strong>BMI Limitations:</strong> BMI doesn't account for muscle mass, bone density, or body composition</li>
                <li><strong>Calorie Needs:</strong> Individual metabolic rates vary; calculations are estimates only</li>
                <li><strong>Sleep Recommendations:</strong> Sleep needs vary by individual and health conditions</li>
                <li><strong>General Health:</strong> Many factors affect health beyond what calculators can measure</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Consult Healthcare Professionals:</h3>
              <p className="text-sm">
                Always consult with qualified healthcare professionals, including doctors, nutritionists, 
                fitness trainers, or other medical experts for personalized health advice, especially if you have:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm mt-2">
                <li>Existing medical conditions</li>
                <li>Are taking medications</li>
                <li>Are pregnant or nursing</li>
                <li>Have dietary restrictions or allergies</li>
                <li>Are planning significant lifestyle changes</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Emergency Situations:</h3>
              <p className="text-sm">
                Our calculators are not intended for emergency situations. If you have a medical emergency, 
                contact emergency services immediately.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Educational Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-blue-600" />
              Educational Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 p-4 rounded-lg">
              <p className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                Educational Tools Notice
              </p>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                Our educational calculators (GPA, grade calculator, percentage calculator) are designed 
                to assist with academic calculations but may not reflect your institution's specific policies.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Academic Considerations:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li><strong>GPA Calculations:</strong> Different institutions use different GPA scales and calculation methods</li>
                <li><strong>Grade Weighting:</strong> Your school may have specific weighting policies not reflected in our calculators</li>
                <li><strong>Credit Hours:</strong> Credit hour systems vary between institutions</li>
                <li><strong>Grading Policies:</strong> Each institution has unique grading policies and requirements</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Verify with Your Institution:</h3>
              <p className="text-sm">
                Always verify calculations with your school's official records, academic advisors, 
                or registrar's office. Use our calculators as estimates and planning tools only.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Technical Disclaimer */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Technical Accuracy Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Calculation Methods:</h3>
              <p className="text-sm">
                We use widely accepted formulas and algorithms for our calculations. However, different 
                sources may use slightly different methods, leading to variations in results.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Rounding and Precision:</h3>
              <p className="text-sm">
                Results may be rounded for display purposes. The level of precision may not be suitable 
                for all applications, especially those requiring high precision calculations.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Browser Compatibility:</h3>
              <p className="text-sm">
                Our calculators are designed to work in modern web browsers. Older browsers or 
                those with JavaScript disabled may not function properly.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Data Input:</h3>
              <p className="text-sm">
                The accuracy of results depends on the accuracy of the data you input. Always 
                double-check your inputs before relying on the results.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Limitation of Liability */}
        <Card>
          <CardHeader>
            <CardTitle>Limitation of Liability</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              <strong>No Warranties:</strong> We provide our calculators "as is" without any warranties, 
              express or implied, including but not limited to warranties of accuracy, completeness, 
              or fitness for a particular purpose.
            </p>
            
            <p>
              <strong>Limitation of Damages:</strong> In no event shall CalcHub Pro, its owners, employees, 
              or affiliates be liable for any direct, indirect, incidental, special, or consequential 
              damages arising from the use of our calculators, including but not limited to:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Financial losses due to calculation errors</li>
              <li>Health consequences from following calculator results</li>
              <li>Academic consequences from grade miscalculations</li>
              <li>Business losses from incorrect business calculations</li>
              <li>Any other damages resulting from reliance on our tools</li>
            </ul>
          </CardContent>
        </Card>

        {/* Updates */}
        <Card>
          <CardHeader>
            <CardTitle>Updates to This Disclaimer</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              We may update this disclaimer from time to time to reflect changes in our services, 
              legal requirements, or to provide additional clarity. Please check this page periodically 
              for updates. The "Last updated" date at the top indicates when changes were last made.
            </p>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <CardHeader>
            <CardTitle>Questions About This Disclaimer</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              If you have questions about this disclaimer or need clarification about any of our calculators, 
              please contact us:
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <p><strong>Email:</strong> support@calchub-pro.com</p>
              <p><strong>Subject Line:</strong> Disclaimer Question</p>
              <p><strong>Response Time:</strong> We aim to respond within 48 hours</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

