import { describe, it, expect } from 'vitest';
import {
  calculateAge,
  calculateBMI,
  calculatePercentage,
  calculateSimpleInterest,
  calculateCompoundInterest,
} from '../lib/calculations';
import {
  calculateEMI,
  calculateProfitMargin,
  calculateTaxBrackets,
} from '../lib/finance-calculations';
import {
  calculateBMR,
  calculateTDEE,
  calculateSleepTimes,
  calculateDateDifference,
} from '../lib/health-calculations';

describe('Basic Calculations', () => {
  describe('calculateAge', () => {
    it('should calculate age correctly', () => {
      const birthDate = new Date('1990-01-01');
      const today = new Date('2024-01-01');
      const age = calculateAge(birthDate, today);
      
      expect(age.years).toBe(34);
      expect(age.months).toBe(0);
      expect(age.days).toBe(0);
    });

    it('should handle leap years correctly', () => {
      const birthDate = new Date('2000-02-29');
      const today = new Date('2024-02-28');
      const age = calculateAge(birthDate, today);
      
      expect(age.years).toBe(23);
      expect(age.months).toBe(11);
      expect(age.days).toBe(30);
    });
  });

  describe('calculateBMI', () => {
    it('should calculate BMI correctly for metric units', () => {
      const result = calculateBMI(70, 175, 'metric');
      expect(result.bmi).toBeCloseTo(22.86, 2);
      expect(result.category).toBe('Normal weight');
    });

    it('should calculate BMI correctly for imperial units', () => {
      const result = calculateBMI(154, 69, 'imperial'); // 154 lbs, 69 inches
      expect(result.bmi).toBeCloseTo(22.7, 1);
      expect(result.category).toBe('Normal weight');
    });

    it('should categorize BMI correctly', () => {
      expect(calculateBMI(45, 175, 'metric').category).toBe('Underweight');
      expect(calculateBMI(85, 175, 'metric').category).toBe('Overweight');
      expect(calculateBMI(110, 175, 'metric').category).toBe('Obese');
    });
  });

  describe('calculatePercentage', () => {
    it('should calculate percentage of a number', () => {
      expect(calculatePercentage(100, 25, 'of')).toBe(25);
      expect(calculatePercentage(200, 15, 'of')).toBe(30);
    });

    it('should calculate what percentage one number is of another', () => {
      expect(calculatePercentage(25, 100, 'is')).toBe(25);
      expect(calculatePercentage(30, 200, 'is')).toBe(15);
    });

    it('should calculate percentage change', () => {
      expect(calculatePercentage(100, 120, 'change')).toBe(20);
      expect(calculatePercentage(120, 100, 'change')).toBeCloseTo(-16.67, 2);
    });
  });
});

describe('Financial Calculations', () => {
  describe('calculateSimpleInterest', () => {
    it('should calculate simple interest correctly', () => {
      const result = calculateSimpleInterest(1000, 5, 2);
      expect(result.interest).toBe(100);
      expect(result.total).toBe(1100);
    });
  });

  describe('calculateCompoundInterest', () => {
    it('should calculate compound interest correctly', () => {
      const result = calculateCompoundInterest(1000, 5, 2, 1);
      expect(result.total).toBeCloseTo(1102.5, 2);
      expect(result.interest).toBeCloseTo(102.5, 2);
    });

    it('should handle different compounding frequencies', () => {
      const monthly = calculateCompoundInterest(1000, 5, 1, 12);
      const daily = calculateCompoundInterest(1000, 5, 1, 365);
      
      expect(monthly.total).toBeGreaterThan(1050);
      expect(daily.total).toBeGreaterThan(monthly.total);
    });
  });

  describe('calculateEMI', () => {
    it('should calculate EMI correctly', () => {
      const result = calculateEMI(100000, 10, 12); // 1 lakh, 10% annual, 1 year
      expect(result.emi).toBeCloseTo(8792, 0);
      expect(result.totalPayment).toBeCloseTo(105504, 0);
      expect(result.totalInterest).toBeCloseTo(5504, 0);
    });

    it('should generate amortization schedule', () => {
      const result = calculateEMI(100000, 10, 12);
      expect(result.schedule).toHaveLength(12);
      expect(result.schedule[0].month).toBe(1);
      expect(result.schedule[0].principal).toBeGreaterThan(0);
      expect(result.schedule[0].interest).toBeGreaterThan(0);
    });
  });

  describe('calculateProfitMargin', () => {
    it('should calculate profit margin correctly', () => {
      const result = calculateProfitMargin(100, 80, 'margin');
      expect(result.profitMargin).toBe(20);
      expect(result.markup).toBe(25);
    });

    it('should calculate markup correctly', () => {
      const result = calculateProfitMargin(80, 100, 'markup');
      expect(result.markup).toBe(25);
      expect(result.profitMargin).toBe(20);
    });
  });
});

describe('Health Calculations', () => {
  describe('calculateBMR', () => {
    it('should calculate BMR for men correctly', () => {
      const bmr = calculateBMR(70, 175, 30, 'male');
      expect(bmr).toBeCloseTo(1707, 0);
    });

    it('should calculate BMR for women correctly', () => {
      const bmr = calculateBMR(60, 165, 25, 'female');
      expect(bmr).toBeCloseTo(1442, 0);
    });
  });

  describe('calculateTDEE', () => {
    it('should calculate TDEE correctly', () => {
      const bmr = 1700;
      const tdee = calculateTDEE(bmr, 'moderate');
      expect(tdee).toBeCloseTo(2635, 0);
    });

    it('should handle different activity levels', () => {
      const bmr = 1700;
      const sedentary = calculateTDEE(bmr, 'sedentary');
      const active = calculateTDEE(bmr, 'active');
      
      expect(active).toBeGreaterThan(sedentary);
    });
  });

  describe('calculateSleepTimes', () => {
    it('should calculate optimal bedtimes', () => {
      const result = calculateSleepTimes('07:00', 'bedtime');
      expect(result.times).toHaveLength(4);
      expect(result.times[0]).toMatch(/^\d{2}:\d{2}$/);
    });

    it('should calculate optimal wake times', () => {
      const result = calculateSleepTimes('23:00', 'waketime');
      expect(result.times).toHaveLength(4);
      expect(result.times[0]).toMatch(/^\d{2}:\d{2}$/);
    });
  });

  describe('calculateDateDifference', () => {
    it('should calculate date difference correctly', () => {
      const start = new Date('2024-01-01');
      const end = new Date('2024-12-31');
      const result = calculateDateDifference(start, end);
      
      expect(result.days).toBe(365);
      expect(result.months).toBe(12);
      expect(result.years).toBe(1);
    });

    it('should calculate business days correctly', () => {
      const start = new Date('2024-01-01'); // Monday
      const end = new Date('2024-01-08'); // Monday
      const result = calculateDateDifference(start, end);
      
      expect(result.businessDays).toBe(5); // Mon-Fri
      expect(result.weekends).toBe(2); // Sat-Sun
    });
  });
});

describe('Utility Calculations', () => {
  describe('Tip Calculator', () => {
    it('should calculate tip correctly', () => {
      const bill = 100;
      const tipPercent = 18;
      const people = 4;
      
      const tip = (bill * tipPercent) / 100;
      const total = bill + tip;
      const perPerson = total / people;
      
      expect(tip).toBe(18);
      expect(total).toBe(118);
      expect(perPerson).toBe(29.5);
    });
  });

  describe('Unit Converter', () => {
    it('should convert length units correctly', () => {
      // 1 meter = 3.28084 feet
      const meters = 1;
      const feet = meters * 3.28084;
      expect(feet).toBeCloseTo(3.281, 3);
    });

    it('should convert weight units correctly', () => {
      // 1 kg = 2.20462 lbs
      const kg = 1;
      const lbs = kg * 2.20462;
      expect(lbs).toBeCloseTo(2.205, 3);
    });

    it('should convert temperature correctly', () => {
      // 0°C = 32°F
      const celsius = 0;
      const fahrenheit = (celsius * 9/5) + 32;
      expect(fahrenheit).toBe(32);
    });
  });

  describe('Password Generator', () => {
    it('should generate password of correct length', () => {
      const length = 12;
      const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let password = '';
      
      for (let i = 0; i < length; i++) {
        password += charset.charAt(Math.floor(Math.random() * charset.length));
      }
      
      expect(password).toHaveLength(length);
    });

    it('should calculate password strength correctly', () => {
      const strongPassword = 'Str0ng!P@ssw0rd123';
      const weakPassword = 'password';
      
      // Simple strength calculation based on length and character variety
      const calculateStrength = (pwd: string) => {
        let score = 0;
        if (pwd.length >= 8) score += 25;
        if (pwd.length >= 12) score += 25;
        if (/[a-z]/.test(pwd)) score += 10;
        if (/[A-Z]/.test(pwd)) score += 10;
        if (/[0-9]/.test(pwd)) score += 10;
        if (/[^A-Za-z0-9]/.test(pwd)) score += 20;
        return Math.min(score, 100);
      };
      
      expect(calculateStrength(strongPassword)).toBeGreaterThan(80);
      expect(calculateStrength(weakPassword)).toBeLessThan(50);
    });
  });
});

