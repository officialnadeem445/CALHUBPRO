// Utility and Fun Calculations

// Tip Calculator
export interface TipResult {
  tipAmount: number;
  totalAmount: number;
  perPersonAmount: number;
  perPersonTip: number;
}

export function calculateTip(
  billAmount: number,
  tipPercentage: number,
  numberOfPeople: number = 1
): TipResult {
  if (billAmount <= 0 || tipPercentage < 0 || numberOfPeople <= 0) {
    throw new Error('Invalid input values');
  }

  const tipAmount = (billAmount * tipPercentage) / 100;
  const totalAmount = billAmount + tipAmount;
  const perPersonAmount = totalAmount / numberOfPeople;
  const perPersonTip = tipAmount / numberOfPeople;

  return {
    tipAmount: Math.round(tipAmount * 100) / 100,
    totalAmount: Math.round(totalAmount * 100) / 100,
    perPersonAmount: Math.round(perPersonAmount * 100) / 100,
    perPersonTip: Math.round(perPersonTip * 100) / 100,
  };
}

// Unit Converter
export interface ConversionResult {
  value: number;
  fromUnit: string;
  toUnit: string;
  result: number;
  category: string;
}

export type UnitCategory = 'length' | 'weight' | 'temperature' | 'volume' | 'area' | 'speed';

export const UNIT_CONVERSIONS = {
  length: {
    meter: 1,
    kilometer: 0.001,
    centimeter: 100,
    millimeter: 1000,
    inch: 39.3701,
    foot: 3.28084,
    yard: 1.09361,
    mile: 0.000621371,
  },
  weight: {
    kilogram: 1,
    gram: 1000,
    pound: 2.20462,
    ounce: 35.274,
    ton: 0.001,
    stone: 0.157473,
  },
  temperature: {
    celsius: (c: number) => c,
    fahrenheit: (c: number) => (c * 9/5) + 32,
    kelvin: (c: number) => c + 273.15,
  },
  volume: {
    liter: 1,
    milliliter: 1000,
    gallon: 0.264172,
    quart: 1.05669,
    pint: 2.11338,
    cup: 4.22675,
    fluid_ounce: 33.814,
  },
  area: {
    square_meter: 1,
    square_kilometer: 0.000001,
    square_centimeter: 10000,
    square_inch: 1550.0031,
    square_foot: 10.7639,
    square_yard: 1.19599,
    acre: 0.000247105,
    hectare: 0.0001,
  },
  speed: {
    meter_per_second: 1,
    kilometer_per_hour: 3.6,
    mile_per_hour: 2.23694,
    foot_per_second: 3.28084,
    knot: 1.94384,
  },
};

export function convertUnit(
  value: number,
  fromUnit: string,
  toUnit: string,
  category: UnitCategory
): ConversionResult {
  if (value < 0) {
    throw new Error('Value cannot be negative');
  }

  let result: number;

  if (category === 'temperature') {
    // Special handling for temperature conversions
    let celsius: number;
    
    // Convert to Celsius first
    switch (fromUnit) {
      case 'celsius':
        celsius = value;
        break;
      case 'fahrenheit':
        celsius = (value - 32) * 5/9;
        break;
      case 'kelvin':
        celsius = value - 273.15;
        break;
      default:
        throw new Error('Invalid temperature unit');
    }

    // Convert from Celsius to target unit
    const tempConversions = UNIT_CONVERSIONS.temperature;
    switch (toUnit) {
      case 'celsius':
        result = tempConversions.celsius(celsius);
        break;
      case 'fahrenheit':
        result = tempConversions.fahrenheit(celsius);
        break;
      case 'kelvin':
        result = tempConversions.kelvin(celsius);
        break;
      default:
        throw new Error('Invalid temperature unit');
    }
  } else {
    // Standard unit conversions
    const conversions = UNIT_CONVERSIONS[category];
    if (!conversions || !(fromUnit in conversions) || !(toUnit in conversions)) {
      throw new Error('Invalid unit or category');
    }

    // Convert to base unit, then to target unit
    const baseValue = value / (conversions as any)[fromUnit];
    result = baseValue * (conversions as any)[toUnit];
  }

  return {
    value,
    fromUnit,
    toUnit,
    result: Math.round(result * 1000000) / 1000000, // Round to 6 decimal places
    category,
  };
}

// Password Generator
export interface PasswordOptions {
  length: number;
  includeUppercase: boolean;
  includeLowercase: boolean;
  includeNumbers: boolean;
  includeSymbols: boolean;
  excludeSimilar: boolean;
  excludeAmbiguous: boolean;
}

export interface PasswordResult {
  password: string;
  strength: 'Very Weak' | 'Weak' | 'Fair' | 'Good' | 'Strong' | 'Very Strong';
  entropy: number;
  estimatedCrackTime: string;
}

export function generatePassword(options: PasswordOptions): PasswordResult {
  if (options.length < 4 || options.length > 128) {
    throw new Error('Password length must be between 4 and 128 characters');
  }

  if (!options.includeUppercase && !options.includeLowercase && 
      !options.includeNumbers && !options.includeSymbols) {
    throw new Error('At least one character type must be selected');
  }

  let charset = '';
  
  if (options.includeLowercase) {
    charset += options.excludeSimilar ? 'abcdefghjkmnpqrstuvwxyz' : 'abcdefghijklmnopqrstuvwxyz';
  }
  
  if (options.includeUppercase) {
    charset += options.excludeSimilar ? 'ABCDEFGHJKMNPQRSTUVWXYZ' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  }
  
  if (options.includeNumbers) {
    charset += options.excludeSimilar ? '23456789' : '0123456789';
  }
  
  if (options.includeSymbols) {
    const symbols = options.excludeAmbiguous ? '!@#$%^&*()_+-=[]{}|;:,.<>?' : '!@#$%^&*()_+-=[]{}|;:,.<>?`~"\'\\/ ';
    charset += symbols;
  }

  let password = '';
  for (let i = 0; i < options.length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }

  const strength = calculatePasswordStrength(password);
  const entropy = Math.log2(charset.length) * options.length;
  const estimatedCrackTime = calculateCrackTime(entropy);

  return {
    password,
    strength,
    entropy: Math.round(entropy * 100) / 100,
    estimatedCrackTime,
  };
}

function calculatePasswordStrength(password: string): 'Very Weak' | 'Weak' | 'Fair' | 'Good' | 'Strong' | 'Very Strong' {
  let score = 0;
  
  // Length scoring
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (password.length >= 16) score += 1;
  
  // Character variety scoring
  if (/[a-z]/.test(password)) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  
  // Pattern penalties
  if (/(.)\1{2,}/.test(password)) score -= 1; // Repeated characters
  if (/123|abc|qwe/i.test(password)) score -= 1; // Common sequences
  
  if (score <= 2) return 'Very Weak';
  if (score <= 3) return 'Weak';
  if (score <= 4) return 'Fair';
  if (score <= 5) return 'Good';
  if (score <= 6) return 'Strong';
  return 'Very Strong';
}

function calculateCrackTime(entropy: number): string {
  // Assuming 1 billion guesses per second
  const guessesPerSecond = 1e9;
  const averageGuesses = Math.pow(2, entropy - 1);
  const seconds = averageGuesses / guessesPerSecond;
  
  if (seconds < 1) return 'Instant';
  if (seconds < 60) return `${Math.round(seconds)} seconds`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} minutes`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)} hours`;
  if (seconds < 31536000) return `${Math.round(seconds / 86400)} days`;
  if (seconds < 31536000000) return `${Math.round(seconds / 31536000)} years`;
  return 'Centuries';
}

// QR Code Generator (placeholder - would need actual QR library)
export interface QRCodeOptions {
  text: string;
  size: number;
  errorCorrection: 'L' | 'M' | 'Q' | 'H';
  margin: number;
}

export function generateQRCodeData(options: QRCodeOptions): string {
  // This is a placeholder - in a real implementation, you'd use a QR code library
  // For now, return a data URL that represents the concept
  const { text, size } = options;
  
  if (!text.trim()) {
    throw new Error('Text cannot be empty');
  }
  
  if (size < 100 || size > 1000) {
    throw new Error('Size must be between 100 and 1000 pixels');
  }
  
  // Return a placeholder data URL
  return `data:text/plain;base64,${btoa(`QR Code for: ${text} (${size}x${size})`)}`;
}

// Random Number Generator
export interface RandomNumberResult {
  numbers: number[];
  sum: number;
  average: number;
  min: number;
  max: number;
}

export function generateRandomNumbers(
  min: number,
  max: number,
  count: number = 1,
  allowDuplicates: boolean = true
): RandomNumberResult {
  if (min >= max) {
    throw new Error('Minimum value must be less than maximum value');
  }
  
  if (count <= 0 || count > 1000) {
    throw new Error('Count must be between 1 and 1000');
  }
  
  if (!allowDuplicates && (max - min + 1) < count) {
    throw new Error('Not enough unique numbers in range');
  }
  
  const numbers: number[] = [];
  const used = new Set<number>();
  
  for (let i = 0; i < count; i++) {
    let num: number;
    
    if (allowDuplicates) {
      num = Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
      do {
        num = Math.floor(Math.random() * (max - min + 1)) + min;
      } while (used.has(num));
      used.add(num);
    }
    
    numbers.push(num);
  }
  
  const sum = numbers.reduce((a, b) => a + b, 0);
  const average = sum / numbers.length;
  
  return {
    numbers,
    sum,
    average: Math.round(average * 100) / 100,
    min: Math.min(...numbers),
    max: Math.max(...numbers),
  };
}

