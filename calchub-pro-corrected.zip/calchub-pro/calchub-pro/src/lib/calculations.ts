// Age Calculator
export interface AgeResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalMonths: number;
  nextBirthday: Date;
  daysUntilBirthday: number;
}

export function calculateAge(birthDate: Date, currentDate: Date = new Date()): AgeResult {
  const birth = new Date(birthDate);
  const current = new Date(currentDate);
  
  if (birth > current) {
    throw new Error('Birth date cannot be in the future');
  }

  let years = current.getFullYear() - birth.getFullYear();
  let months = current.getMonth() - birth.getMonth();
  let days = current.getDate() - birth.getDate();

  if (days < 0) {
    months--;
    const lastMonth = new Date(current.getFullYear(), current.getMonth(), 0);
    days += lastMonth.getDate();
  }

  if (months < 0) {
    years--;
    months += 12;
  }

  const totalDays = Math.floor((current.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
  const totalMonths = years * 12 + months;

  // Calculate next birthday
  const nextBirthday = new Date(current.getFullYear(), birth.getMonth(), birth.getDate());
  if (nextBirthday < current) {
    nextBirthday.setFullYear(current.getFullYear() + 1);
  }

  const daysUntilBirthday = Math.ceil((nextBirthday.getTime() - current.getTime()) / (1000 * 60 * 60 * 24));

  return {
    years,
    months,
    days,
    totalDays,
    totalMonths,
    nextBirthday,
    daysUntilBirthday,
  };
}

// BMI Calculator
export interface BMIResult {
  bmi: number;
  category: string;
  healthyWeightRange: { min: number; max: number };
  weightToLose?: number;
  weightToGain?: number;
}

export function calculateBMI(weight: number, height: number, unit: 'metric' | 'imperial' = 'metric'): BMIResult {
  if (weight <= 0 || height <= 0) {
    throw new Error('Weight and height must be positive numbers');
  }

  let weightKg = weight;
  let heightM = height;

  if (unit === 'imperial') {
    weightKg = weight * 0.453592; // pounds to kg
    heightM = height * 0.0254; // inches to meters
  } else {
    heightM = height / 100; // cm to meters
  }

  const bmi = weightKg / (heightM * heightM);
  
  let category: string;
  if (bmi < 18.5) {
    category = 'Underweight';
  } else if (bmi < 25) {
    category = 'Normal weight';
  } else if (bmi < 30) {
    category = 'Overweight';
  } else {
    category = 'Obese';
  }

  // Healthy weight range (BMI 18.5-24.9)
  const minHealthyWeight = 18.5 * heightM * heightM;
  const maxHealthyWeight = 24.9 * heightM * heightM;

  const result: BMIResult = {
    bmi: Math.round(bmi * 10) / 10,
    category,
    healthyWeightRange: {
      min: unit === 'imperial' ? Math.round(minHealthyWeight * 2.20462) : Math.round(minHealthyWeight),
      max: unit === 'imperial' ? Math.round(maxHealthyWeight * 2.20462) : Math.round(maxHealthyWeight),
    },
  };

  if (bmi < 18.5) {
    result.weightToGain = unit === 'imperial' 
      ? Math.round((minHealthyWeight - weightKg) * 2.20462)
      : Math.round(minHealthyWeight - weightKg);
  } else if (bmi > 24.9) {
    result.weightToLose = unit === 'imperial'
      ? Math.round((weightKg - maxHealthyWeight) * 2.20462)
      : Math.round(weightKg - maxHealthyWeight);
  }

  return result;
}

// Percentage Calculator
export interface PercentageResult {
  result: number;
  formula: string;
}

export function calculatePercentage(value: number, total: number): PercentageResult {
  if (total === 0) {
    throw new Error('Total cannot be zero');
  }
  
  const result = (value / total) * 100;
  return {
    result: Math.round(result * 100) / 100,
    formula: `(${value} / ${total}) × 100 = ${Math.round(result * 100) / 100}%`,
  };
}

export function calculatePercentageOf(percentage: number, total: number): PercentageResult {
  const result = (percentage / 100) * total;
  return {
    result: Math.round(result * 100) / 100,
    formula: `(${percentage} / 100) × ${total} = ${Math.round(result * 100) / 100}`,
  };
}

export function calculatePercentageChange(oldValue: number, newValue: number): PercentageResult {
  if (oldValue === 0) {
    throw new Error('Original value cannot be zero');
  }
  
  const result = ((newValue - oldValue) / oldValue) * 100;
  return {
    result: Math.round(result * 100) / 100,
    formula: `((${newValue} - ${oldValue}) / ${oldValue}) × 100 = ${Math.round(result * 100) / 100}%`,
  };
}

// Interest Calculator
export interface InterestResult {
  simpleInterest: number;
  compoundInterest: number;
  totalAmountSimple: number;
  totalAmountCompound: number;
  difference: number;
}

export function calculateInterest(
  principal: number,
  rate: number,
  time: number,
  compoundFrequency: number = 1
): InterestResult {
  if (principal <= 0 || rate < 0 || time <= 0) {
    throw new Error('Principal and time must be positive, rate cannot be negative');
  }

  const rateDecimal = rate / 100;
  
  // Simple Interest: SI = P × R × T
  const simpleInterest = principal * rateDecimal * time;
  const totalAmountSimple = principal + simpleInterest;
  
  // Compound Interest: CI = P(1 + r/n)^(nt) - P
  const compoundAmount = principal * Math.pow(1 + rateDecimal / compoundFrequency, compoundFrequency * time);
  const compoundInterest = compoundAmount - principal;
  const totalAmountCompound = compoundAmount;
  
  const difference = compoundInterest - simpleInterest;

  return {
    simpleInterest: Math.round(simpleInterest * 100) / 100,
    compoundInterest: Math.round(compoundInterest * 100) / 100,
    totalAmountSimple: Math.round(totalAmountSimple * 100) / 100,
    totalAmountCompound: Math.round(totalAmountCompound * 100) / 100,
    difference: Math.round(difference * 100) / 100,
  };
}

// GPA Calculator
export interface Course {
  name: string;
  grade: number;
  credits: number;
}

export interface GPAResult {
  gpa: number;
  totalCredits: number;
  totalGradePoints: number;
}

export function calculateGPA(courses: Course[]): GPAResult {
  if (courses.length === 0) {
    throw new Error('At least one course is required');
  }

  let totalGradePoints = 0;
  let totalCredits = 0;

  for (const course of courses) {
    if (course.credits <= 0) {
      throw new Error('Credits must be positive');
    }
    if (course.grade < 0 || course.grade > 4) {
      throw new Error('Grade must be between 0 and 4');
    }
    
    totalGradePoints += course.grade * course.credits;
    totalCredits += course.credits;
  }

  const gpa = totalCredits > 0 ? totalGradePoints / totalCredits : 0;

  return {
    gpa: Math.round(gpa * 100) / 100,
    totalCredits,
    totalGradePoints: Math.round(totalGradePoints * 100) / 100,
  };
}

// Grade Calculator
export interface GradeCalculation {
  currentGrade: number;
  requiredFinalGrade: number;
  possibleGrade: number;
  isAchievable: boolean;
}

export function calculateRequiredGrade(
  currentGrade: number,
  currentWeight: number,
  finalWeight: number,
  targetGrade: number
): GradeCalculation {
  if (currentWeight + finalWeight !== 100) {
    throw new Error('Current weight and final weight must sum to 100%');
  }
  
  if (currentGrade < 0 || currentGrade > 100 || targetGrade < 0 || targetGrade > 100) {
    throw new Error('Grades must be between 0 and 100');
  }

  const currentContribution = (currentGrade * currentWeight) / 100;
  const requiredFinalContribution = targetGrade - currentContribution;
  const requiredFinalGrade = (requiredFinalContribution * 100) / finalWeight;
  
  const possibleGrade = currentContribution + (100 * finalWeight) / 100;
  const isAchievable = requiredFinalGrade <= 100;

  return {
    currentGrade,
    requiredFinalGrade: Math.round(requiredFinalGrade * 100) / 100,
    possibleGrade: Math.round(possibleGrade * 100) / 100,
    isAchievable,
  };
}

// Marks Percentage Calculator
export function calculateMarksPercentage(obtainedMarks: number, totalMarks: number): PercentageResult {
  if (totalMarks <= 0) {
    throw new Error('Total marks must be positive');
  }
  
  if (obtainedMarks < 0 || obtainedMarks > totalMarks) {
    throw new Error('Obtained marks must be between 0 and total marks');
  }

  return calculatePercentage(obtainedMarks, totalMarks);
}

