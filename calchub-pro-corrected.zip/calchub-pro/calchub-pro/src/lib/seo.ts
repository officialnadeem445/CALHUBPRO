// SEO and Metadata Utilities

export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  canonical?: string;
  ogImage?: string;
  structuredData?: any;
}

export function generateCalculatorSEO(
  calculatorTitle: string,
  description: string,
  keywords: string[],
  path: string
): SEOData {
  const title = `${calculatorTitle} | CalcHub Pro`;
  const fullDescription = `${description}. Free online calculator with instant results. No registration required.`;
  
  return {
    title,
    description: fullDescription,
    keywords: [...keywords, 'calculator', 'online', 'free', 'instant', 'accurate'],
    canonical: `https://calchub-pro.com${path}`,
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'WebApplication',
      name: calculatorTitle,
      description: fullDescription,
      url: `https://calchub-pro.com${path}`,
      applicationCategory: 'UtilityApplication',
      operatingSystem: 'Any',
      offers: {
        '@type': 'Offer',
        price: '0',
        priceCurrency: 'USD',
      },
      provider: {
        '@type': 'Organization',
        name: 'CalcHub Pro',
        url: 'https://calchub-pro.com',
      },
    },
  };
}

export function generateCategorySEO(
  categoryName: string,
  calculatorCount: number,
  calculatorNames: string[]
): SEOData {
  const title = `${categoryName} Calculators | CalcHub Pro`;
  const description = `${calculatorCount} free ${categoryName.toLowerCase()} calculators including ${calculatorNames.slice(0, 3).join(', ')} and more. Instant results, no registration required.`;
  
  return {
    title,
    description,
    keywords: [categoryName.toLowerCase(), 'calculators', 'online', 'free', 'tools'],
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'CollectionPage',
      name: title,
      description,
      mainEntity: {
        '@type': 'ItemList',
        numberOfItems: calculatorCount,
        itemListElement: calculatorNames.map((name, index) => ({
          '@type': 'ListItem',
          position: index + 1,
          name,
        })),
      },
    },
  };
}

export function generateHomepageSEO(): SEOData {
  return {
    title: 'CalcHub Pro - Free Online Calculators & Utilities',
    description: 'Access 20+ free online calculators for math, finance, health, education and more. Fast, accurate calculations with instant results. No registration required.',
    keywords: [
      'online calculator',
      'free calculator',
      'math calculator',
      'financial calculator',
      'health calculator',
      'education calculator',
      'utility tools',
      'instant calculations',
    ],
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'CalcHub Pro',
      description: 'Free online calculators and utilities for everyone',
      url: 'https://calchub-pro.com',
      potentialAction: {
        '@type': 'SearchAction',
        target: 'https://calchub-pro.com/search?q={search_term_string}',
        'query-input': 'required name=search_term_string',
      },
      publisher: {
        '@type': 'Organization',
        name: 'CalcHub Pro',
        url: 'https://calchub-pro.com',
      },
    },
  };
}

// Generate sitemap data
export function generateSitemapData() {
  const baseUrl = 'https://calchub-pro.com';
  const currentDate = new Date().toISOString().split('T')[0];
  
  return {
    pages: [
      {
        url: baseUrl,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '1.0',
      },
      {
        url: `${baseUrl}/category/basic`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/category/education`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/category/finance`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/category/health`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/category/datetime`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/category/utility`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.8',
      },
      {
        url: `${baseUrl}/blog`,
        lastmod: currentDate,
        changefreq: 'weekly',
        priority: '0.7',
      },
      {
        url: `${baseUrl}/privacy`,
        lastmod: currentDate,
        changefreq: 'monthly',
        priority: '0.3',
      },
      {
        url: `${baseUrl}/terms`,
        lastmod: currentDate,
        changefreq: 'monthly',
        priority: '0.3',
      },
    ],
  };
}

// Generate robots.txt content
export function generateRobotsTxt(): string {
  return `User-agent: *
Allow: /

# Sitemap
Sitemap: https://calchub-pro.com/sitemap.xml

# Crawl-delay
Crawl-delay: 1

# Disallow admin areas (if any)
Disallow: /admin/
Disallow: /_next/
Disallow: /api/

# Allow all calculators
Allow: /calculators/
Allow: /category/`;
}

// Meta tags for better social sharing
export function generateOpenGraphTags(seoData: SEOData) {
  return {
    'og:title': seoData.title,
    'og:description': seoData.description,
    'og:type': 'website',
    'og:url': seoData.canonical || 'https://calchub-pro.com',
    'og:image': seoData.ogImage || 'https://calchub-pro.com/og-image.png',
    'og:site_name': 'CalcHub Pro',
    'twitter:card': 'summary_large_image',
    'twitter:title': seoData.title,
    'twitter:description': seoData.description,
    'twitter:image': seoData.ogImage || 'https://calchub-pro.com/og-image.png',
  };
}

// Generate FAQ structured data
export function generateFAQStructuredData(faqs: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

