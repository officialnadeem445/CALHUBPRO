// Health and Lifestyle Calculations

// BMR and TDEE Calculator
export interface CalorieNeedsResult {
  bmr: number;
  tdee: number;
  activityLevel: string;
  weightLossCalories: number;
  weightGainCalories: number;
  maintenanceCalories: number;
}

export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
export type Gender = 'male' | 'female';

export function calculateBMR(
  weight: number, // in kg
  height: number, // in cm
  age: number,
  gender: Gender
): number {
  if (weight <= 0 || height <= 0 || age <= 0) {
    throw new Error('Weight, height, and age must be positive numbers');
  }

  // Mifflin-St Jeor Equation
  let bmr: number;
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }

  return Math.round(bmr * 100) / 100;
}

export function calculateTDEE(bmr: number, activityLevel: ActivityLevel): number {
  const activityMultipliers = {
    sedentary: 1.2,      // Little or no exercise
    light: 1.375,        // Light exercise 1-3 days/week
    moderate: 1.55,      // Moderate exercise 3-5 days/week
    active: 1.725,       // Hard exercise 6-7 days/week
    very_active: 1.9     // Very hard exercise, physical job
  };

  const tdee = bmr * activityMultipliers[activityLevel];
  return Math.round(tdee * 100) / 100;
}

export function calculateCalorieNeeds(
  weight: number,
  height: number,
  age: number,
  gender: Gender,
  activityLevel: ActivityLevel
): CalorieNeedsResult {
  const bmr = calculateBMR(weight, height, age, gender);
  const tdee = calculateTDEE(bmr, activityLevel);

  const activityLabels = {
    sedentary: 'Sedentary (little or no exercise)',
    light: 'Light (light exercise 1-3 days/week)',
    moderate: 'Moderate (moderate exercise 3-5 days/week)',
    active: 'Active (hard exercise 6-7 days/week)',
    very_active: 'Very Active (very hard exercise, physical job)'
  };

  return {
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    activityLevel: activityLabels[activityLevel],
    weightLossCalories: Math.round(tdee - 500), // 500 calorie deficit for ~1 lb/week loss
    weightGainCalories: Math.round(tdee + 500), // 500 calorie surplus for ~1 lb/week gain
    maintenanceCalories: Math.round(tdee),
  };
}

// Sleep Calculator
export interface SleepResult {
  bedtime: string;
  wakeupTime: string;
  sleepCycles: number;
  totalSleepHours: number;
  sleepQuality: string;
  recommendations: string[];
}

export function calculateOptimalSleep(
  targetWakeupTime: string,
  preferredSleepDuration: number = 8
): SleepResult {
  if (preferredSleepDuration < 4 || preferredSleepDuration > 12) {
    throw new Error('Sleep duration should be between 4 and 12 hours');
  }

  const wakeupDate = new Date(`2000-01-01T${targetWakeupTime}:00`);
  const sleepDate = new Date(wakeupDate.getTime() - (preferredSleepDuration * 60 * 60 * 1000));
  
  // Account for next day if bedtime is after midnight
  if (sleepDate.getDate() !== wakeupDate.getDate()) {
    sleepDate.setDate(sleepDate.getDate() + 1);
  }

  const bedtime = sleepDate.toTimeString().slice(0, 5);
  const sleepCycles = Math.round(preferredSleepDuration / 1.5); // 90-minute cycles
  
  let sleepQuality: string;
  let recommendations: string[] = [];

  if (preferredSleepDuration >= 7 && preferredSleepDuration <= 9) {
    sleepQuality = 'Optimal';
    recommendations.push('Great sleep duration for most adults');
  } else if (preferredSleepDuration >= 6 && preferredSleepDuration < 7) {
    sleepQuality = 'Adequate';
    recommendations.push('Consider extending sleep time for better health');
  } else if (preferredSleepDuration > 9) {
    sleepQuality = 'Extended';
    recommendations.push('Long sleep duration - ensure it\'s not due to underlying issues');
  } else {
    sleepQuality = 'Insufficient';
    recommendations.push('Increase sleep duration for better health and performance');
  }

  // Add general recommendations
  recommendations.push('Maintain consistent sleep schedule');
  recommendations.push('Avoid screens 1 hour before bedtime');
  recommendations.push('Keep bedroom cool, dark, and quiet');

  return {
    bedtime,
    wakeupTime: targetWakeupTime,
    sleepCycles,
    totalSleepHours: preferredSleepDuration,
    sleepQuality,
    recommendations,
  };
}

export function calculateBestWakeupTimes(bedtime: string): string[] {
  const bedtimeDate = new Date(`2000-01-01T${bedtime}:00`);
  const wakeupTimes: string[] = [];

  // Calculate wake-up times based on 90-minute sleep cycles
  // Starting from 4.5 hours (3 cycles) to 9 hours (6 cycles)
  for (let cycles = 3; cycles <= 6; cycles++) {
    const sleepDuration = cycles * 1.5; // hours
    const wakeupDate = new Date(bedtimeDate.getTime() + (sleepDuration * 60 * 60 * 1000));
    
    // Handle next day
    if (wakeupDate.getDate() !== bedtimeDate.getDate()) {
      wakeupDate.setDate(wakeupDate.getDate() + 1);
    }
    
    const wakeupTime = wakeupDate.toTimeString().slice(0, 5);
    wakeupTimes.push(`${wakeupTime} (${sleepDuration}h - ${cycles} cycles)`);
  }

  return wakeupTimes;
}

// Unit conversion helpers
export function poundsToKg(pounds: number): number {
  return pounds * 0.453592;
}

export function kgToPounds(kg: number): number {
  return kg * 2.20462;
}

export function feetInchesToCm(feet: number, inches: number): number {
  return (feet * 12 + inches) * 2.54;
}

export function cmToFeetInches(cm: number): { feet: number; inches: number } {
  const totalInches = cm / 2.54;
  const feet = Math.floor(totalInches / 12);
  const inches = Math.round(totalInches % 12);
  return { feet, inches };
}

