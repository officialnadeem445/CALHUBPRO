// Analytics and Tracking Utilities

declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    plausible: (...args: any[]) => void;
  }
}

// Google Analytics 4 Configuration
export const GA_TRACKING_ID = process.env.NEXT_PUBLIC_GA_ID || '';

// Track page views
export const trackPageView = (url: string) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('config', GA_TRACKING_ID, {
      page_location: url,
    });
  }
};

// Track custom events
export const trackEvent = (
  action: string,
  category: string,
  label?: string,
  value?: number
) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Track calculator usage
export const trackCalculatorUsage = (calculatorName: string, category: string) => {
  trackEvent('calculator_used', 'engagement', calculatorName);
  
  // Also track with Plausible if available
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('Calculator Used', {
      props: {
        calculator: calculatorName,
        category: category,
      },
    });
  }
};

// Track search queries
export const trackSearch = (query: string, resultsCount: number) => {
  trackEvent('search', 'engagement', query, resultsCount);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('Search', {
      props: {
        query: query,
        results: resultsCount,
      },
    });
  }
};

// Track result copying
export const trackResultCopy = (calculatorName: string) => {
  trackEvent('result_copied', 'engagement', calculatorName);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('Result Copied', {
      props: {
        calculator: calculatorName,
      },
    });
  }
};

// Track CSV downloads
export const trackCSVDownload = (calculatorName: string) => {
  trackEvent('csv_download', 'engagement', calculatorName);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('CSV Download', {
      props: {
        calculator: calculatorName,
      },
    });
  }
};

// Track external link clicks
export const trackExternalLink = (url: string, linkText: string) => {
  trackEvent('external_link_click', 'engagement', `${linkText} - ${url}`);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('External Link', {
      props: {
        url: url,
        text: linkText,
      },
    });
  }
};

// Track theme changes
export const trackThemeChange = (theme: string) => {
  trackEvent('theme_change', 'ui', theme);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('Theme Change', {
      props: {
        theme: theme,
      },
    });
  }
};

// Privacy-friendly analytics with Plausible
export const initPlausible = () => {
  if (typeof window !== 'undefined' && process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN) {
    const script = document.createElement('script');
    script.defer = true;
    script.src = 'https://plausible.io/js/script.js';
    script.setAttribute('data-domain', process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN);
    document.head.appendChild(script);
  }
};

// Cookie consent management
export const hasAnalyticsConsent = (): boolean => {
  if (typeof window === 'undefined') return false;
  return localStorage.getItem('analytics-consent') === 'true';
};

export const setAnalyticsConsent = (consent: boolean) => {
  if (typeof window === 'undefined') return;
  localStorage.setItem('analytics-consent', consent.toString());
  
  if (consent) {
    // Initialize analytics after consent
    initPlausible();
  }
};

// Performance tracking
export const trackPerformance = () => {
  if (typeof window === 'undefined') return;
  
  // Track Core Web Vitals
  const observer = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
      if (entry.entryType === 'navigation') {
        const navEntry = entry as PerformanceNavigationTiming;
        trackEvent('page_load_time', 'performance', 'load', Math.round(navEntry.loadEventEnd - navEntry.loadEventStart));
      }
      
      if (entry.entryType === 'paint') {
        if (entry.name === 'first-contentful-paint') {
          trackEvent('first_contentful_paint', 'performance', 'fcp', Math.round(entry.startTime));
        }
      }
    }
  });
  
  observer.observe({ entryTypes: ['navigation', 'paint'] });
};

// Error tracking
export const trackError = (error: Error, errorInfo?: any) => {
  trackEvent('javascript_error', 'error', error.message);
  
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible('JavaScript Error', {
      props: {
        error: error.message,
        stack: error.stack?.substring(0, 100) || 'No stack trace',
      },
    });
  }
};

// A/B Testing utilities
export const getABTestVariant = (testName: string, variants: string[]): string => {
  if (typeof window === 'undefined') return variants[0];
  
  const stored = localStorage.getItem(`ab-test-${testName}`);
  if (stored && variants.includes(stored)) {
    return stored;
  }
  
  // Simple hash-based assignment for consistent results
  const userId = localStorage.getItem('user-id') || Math.random().toString(36);
  const hash = userId.split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  
  const variant = variants[Math.abs(hash) % variants.length];
  localStorage.setItem(`ab-test-${testName}`, variant);
  
  return variant;
};

export const trackABTestView = (testName: string, variant: string) => {
  trackEvent('ab_test_view', 'experiment', `${testName}:${variant}`);
};

