// Loan EMI Calculator
export interface EMIResult {
  emi: number;
  totalAmount: number;
  totalInterest: number;
  amortizationSchedule: AmortizationEntry[];
}

export interface AmortizationEntry {
  month: number;
  emi: number;
  principalPayment: number;
  interestPayment: number;
  remainingBalance: number;
}

export function calculateEMI(
  principal: number,
  annualRate: number,
  tenureMonths: number
): EMIResult {
  if (principal <= 0 || annualRate < 0 || tenureMonths <= 0) {
    throw new Error('Principal and tenure must be positive, rate cannot be negative');
  }

  const monthlyRate = annualRate / 100 / 12;
  let emi: number;
  
  if (monthlyRate === 0) {
    // If interest rate is 0, EMI is simply principal divided by tenure
    emi = principal / tenureMonths;
  } else {
    // EMI formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
    const factor = Math.pow(1 + monthlyRate, tenureMonths);
    emi = (principal * monthlyRate * factor) / (factor - 1);
  }

  const totalAmount = emi * tenureMonths;
  const totalInterest = totalAmount - principal;

  // Generate amortization schedule
  const amortizationSchedule: AmortizationEntry[] = [];
  let remainingBalance = principal;

  for (let month = 1; month <= tenureMonths; month++) {
    const interestPayment = remainingBalance * monthlyRate;
    const principalPayment = emi - interestPayment;
    remainingBalance = Math.max(0, remainingBalance - principalPayment);

    amortizationSchedule.push({
      month,
      emi: Math.round(emi * 100) / 100,
      principalPayment: Math.round(principalPayment * 100) / 100,
      interestPayment: Math.round(interestPayment * 100) / 100,
      remainingBalance: Math.round(remainingBalance * 100) / 100,
    });
  }

  return {
    emi: Math.round(emi * 100) / 100,
    totalAmount: Math.round(totalAmount * 100) / 100,
    totalInterest: Math.round(totalInterest * 100) / 100,
    amortizationSchedule,
  };
}

// Profit Margin Calculator
export interface ProfitMarginResult {
  profitMargin: number;
  markup: number;
  profit: number;
  costPrice: number;
  sellingPrice: number;
}

export function calculateProfitMargin(
  costPrice: number,
  sellingPrice: number
): ProfitMarginResult {
  if (costPrice <= 0 || sellingPrice <= 0) {
    throw new Error('Cost price and selling price must be positive');
  }

  const profit = sellingPrice - costPrice;
  const profitMargin = (profit / sellingPrice) * 100;
  const markup = (profit / costPrice) * 100;

  return {
    profitMargin: Math.round(profitMargin * 100) / 100,
    markup: Math.round(markup * 100) / 100,
    profit: Math.round(profit * 100) / 100,
    costPrice: Math.round(costPrice * 100) / 100,
    sellingPrice: Math.round(sellingPrice * 100) / 100,
  };
}

export function calculateSellingPriceFromMargin(
  costPrice: number,
  targetMargin: number
): number {
  if (costPrice <= 0) {
    throw new Error('Cost price must be positive');
  }
  if (targetMargin < 0 || targetMargin >= 100) {
    throw new Error('Margin must be between 0 and 100%');
  }

  // Selling Price = Cost Price / (1 - Margin/100)
  const sellingPrice = costPrice / (1 - targetMargin / 100);
  return Math.round(sellingPrice * 100) / 100;
}

export function calculateSellingPriceFromMarkup(
  costPrice: number,
  targetMarkup: number
): number {
  if (costPrice <= 0) {
    throw new Error('Cost price must be positive');
  }
  if (targetMarkup < 0) {
    throw new Error('Markup cannot be negative');
  }

  // Selling Price = Cost Price * (1 + Markup/100)
  const sellingPrice = costPrice * (1 + targetMarkup / 100);
  return Math.round(sellingPrice * 100) / 100;
}

// Tax Calculator
export interface TaxSlab {
  min: number;
  max: number | null;
  rate: number;
}

export interface TaxResult {
  grossIncome: number;
  taxableIncome: number;
  totalTax: number;
  netIncome: number;
  effectiveRate: number;
  taxBreakdown: TaxSlabResult[];
}

export interface TaxSlabResult {
  slab: TaxSlab;
  taxableAmount: number;
  tax: number;
}

export function calculateIncomeTax(
  grossIncome: number,
  deductions: number,
  taxSlabs: TaxSlab[]
): TaxResult {
  if (grossIncome < 0 || deductions < 0) {
    throw new Error('Income and deductions cannot be negative');
  }

  const taxableIncome = Math.max(0, grossIncome - deductions);
  let totalTax = 0;
  let remainingIncome = taxableIncome;
  const taxBreakdown: TaxSlabResult[] = [];

  // Sort tax slabs by minimum amount
  const sortedSlabs = [...taxSlabs].sort((a, b) => a.min - b.min);

  for (const slab of sortedSlabs) {
    if (remainingIncome <= 0) break;

    const slabMin = slab.min;
    const slabMax = slab.max || Infinity;
    
    if (taxableIncome > slabMin) {
      const taxableInThisSlab = Math.min(
        remainingIncome,
        Math.min(slabMax, taxableIncome) - slabMin
      );
      
      if (taxableInThisSlab > 0) {
        const taxInThisSlab = (taxableInThisSlab * slab.rate) / 100;
        totalTax += taxInThisSlab;
        remainingIncome -= taxableInThisSlab;

        taxBreakdown.push({
          slab,
          taxableAmount: Math.round(taxableInThisSlab * 100) / 100,
          tax: Math.round(taxInThisSlab * 100) / 100,
        });
      }
    }
  }

  const netIncome = grossIncome - totalTax;
  const effectiveRate = grossIncome > 0 ? (totalTax / grossIncome) * 100 : 0;

  return {
    grossIncome: Math.round(grossIncome * 100) / 100,
    taxableIncome: Math.round(taxableIncome * 100) / 100,
    totalTax: Math.round(totalTax * 100) / 100,
    netIncome: Math.round(netIncome * 100) / 100,
    effectiveRate: Math.round(effectiveRate * 100) / 100,
    taxBreakdown,
  };
}

// CSV Export Utility
export function generateAmortizationCSV(schedule: AmortizationEntry[]): string {
  const headers = ['Month', 'EMI', 'Principal Payment', 'Interest Payment', 'Remaining Balance'];
  const csvContent = [
    headers.join(','),
    ...schedule.map(entry => [
      entry.month,
      entry.emi,
      entry.principalPayment,
      entry.interestPayment,
      entry.remainingBalance
    ].join(','))
  ].join('\n');

  return csvContent;
}

export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

