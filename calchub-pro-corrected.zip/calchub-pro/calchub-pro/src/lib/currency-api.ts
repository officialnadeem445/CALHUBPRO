// Currency API utilities
export interface ExchangeRates {
  [currency: string]: number;
}

export interface CurrencyData {
  base: string;
  date: string;
  rates: ExchangeRates;
}

export interface ConversionResult {
  from: string;
  to: string;
  amount: number;
  convertedAmount: number;
  rate: number;
  date: string;
}

// Popular currencies with their symbols
export const POPULAR_CURRENCIES = [
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF' },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥' },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹' },
  { code: 'KRW', name: 'South Korean Won', symbol: '₩' },
  { code: 'MXN', name: 'Mexican Peso', symbol: '$' },
  { code: 'NOK', name: 'Norwegian Krone', symbol: 'kr' },
  { code: 'NZD', name: 'New Zealand Dollar', symbol: 'NZ$' },
  { code: 'SEK', name: 'Swedish Krona', symbol: 'kr' },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$' },
];

export async function fetchExchangeRates(baseCurrency: string = 'USD'): Promise<CurrencyData> {
  const apiUrl = process.env.EXCHANGE_RATES_API_URL || 'https://api.exchangerate.host/latest';
  
  try {
    const response = await fetch(`${apiUrl}?base=${baseCurrency}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.success && data.success !== undefined) {
      throw new Error(data.error?.info || 'Failed to fetch exchange rates');
    }
    
    return {
      base: data.base || baseCurrency,
      date: data.date || new Date().toISOString().split('T')[0],
      rates: data.rates || {},
    };
  } catch (error) {
    console.error('Error fetching exchange rates:', error);
    throw new Error('Unable to fetch current exchange rates. Please try again later.');
  }
}

export function convertCurrency(
  amount: number,
  fromCurrency: string,
  toCurrency: string,
  rates: ExchangeRates,
  baseCurrency: string = 'USD'
): ConversionResult {
  if (amount < 0) {
    throw new Error('Amount cannot be negative');
  }

  if (fromCurrency === toCurrency) {
    return {
      from: fromCurrency,
      to: toCurrency,
      amount,
      convertedAmount: amount,
      rate: 1,
      date: new Date().toISOString().split('T')[0],
    };
  }

  let rate: number;

  if (fromCurrency === baseCurrency) {
    // Converting from base currency
    rate = rates[toCurrency];
    if (!rate) {
      throw new Error(`Exchange rate not available for ${toCurrency}`);
    }
  } else if (toCurrency === baseCurrency) {
    // Converting to base currency
    const fromRate = rates[fromCurrency];
    if (!fromRate) {
      throw new Error(`Exchange rate not available for ${fromCurrency}`);
    }
    rate = 1 / fromRate;
  } else {
    // Converting between two non-base currencies
    const fromRate = rates[fromCurrency];
    const toRate = rates[toCurrency];
    
    if (!fromRate || !toRate) {
      throw new Error(`Exchange rates not available for ${fromCurrency} or ${toCurrency}`);
    }
    
    rate = toRate / fromRate;
  }

  const convertedAmount = amount * rate;

  return {
    from: fromCurrency,
    to: toCurrency,
    amount,
    convertedAmount: Math.round(convertedAmount * 100) / 100,
    rate: Math.round(rate * 10000) / 10000,
    date: new Date().toISOString().split('T')[0],
  };
}

export function getCurrencySymbol(currencyCode: string): string {
  const currency = POPULAR_CURRENCIES.find(c => c.code === currencyCode);
  return currency?.symbol || currencyCode;
}

export function getCurrencyName(currencyCode: string): string {
  const currency = POPULAR_CURRENCIES.find(c => c.code === currencyCode);
  return currency?.name || currencyCode;
}

