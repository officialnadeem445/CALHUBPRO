// Date and Time Calculations

export interface DateDifferenceResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalWeeks: number;
  totalHours: number;
  totalMinutes: number;
  totalSeconds: number;
  businessDays: number;
  weekends: number;
}

export interface DaysBetweenResult {
  totalDays: number;
  businessDays: number;
  weekends: number;
  weeks: number;
  months: number;
  years: number;
}

export function calculateDateDifference(
  startDate: string,
  endDate: string
): DateDifferenceResult {
  const start = new Date(startDate);
  const end = new Date(endDate);

  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    throw new Error('Invalid date format');
  }

  if (start > end) {
    throw new Error('Start date must be before end date');
  }

  // Calculate total difference in milliseconds
  const timeDiff = end.getTime() - start.getTime();
  
  // Calculate various units
  const totalDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
  const totalWeeks = Math.floor(totalDays / 7);
  const totalHours = Math.floor(timeDiff / (1000 * 60 * 60));
  const totalMinutes = Math.floor(timeDiff / (1000 * 60));
  const totalSeconds = Math.floor(timeDiff / 1000);

  // Calculate years, months, and days
  let years = end.getFullYear() - start.getFullYear();
  let months = end.getMonth() - start.getMonth();
  let days = end.getDate() - start.getDate();

  // Adjust for negative days
  if (days < 0) {
    months--;
    const lastMonth = new Date(end.getFullYear(), end.getMonth(), 0);
    days += lastMonth.getDate();
  }

  // Adjust for negative months
  if (months < 0) {
    years--;
    months += 12;
  }

  // Calculate business days and weekends
  const { businessDays, weekends } = calculateBusinessDays(start, end);

  return {
    years,
    months,
    days,
    totalDays,
    totalWeeks,
    totalHours,
    totalMinutes,
    totalSeconds,
    businessDays,
    weekends,
  };
}

export function calculateDaysBetween(
  startDate: string,
  endDate: string
): DaysBetweenResult {
  const start = new Date(startDate);
  const end = new Date(endDate);

  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    throw new Error('Invalid date format');
  }

  if (start > end) {
    throw new Error('Start date must be before end date');
  }

  const timeDiff = end.getTime() - start.getTime();
  const totalDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
  
  const weeks = Math.floor(totalDays / 7);
  const months = Math.floor(totalDays / 30.44); // Average days per month
  const years = Math.floor(totalDays / 365.25); // Account for leap years

  const { businessDays, weekends } = calculateBusinessDays(start, end);

  return {
    totalDays,
    businessDays,
    weekends,
    weeks,
    months,
    years,
  };
}

function calculateBusinessDays(startDate: Date, endDate: Date): { businessDays: number; weekends: number } {
  let businessDays = 0;
  let weekends = 0;
  
  const currentDate = new Date(startDate);
  
  while (currentDate < endDate) {
    const dayOfWeek = currentDate.getDay();
    
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      // Sunday (0) or Saturday (6)
      weekends++;
    } else {
      // Monday (1) through Friday (5)
      businessDays++;
    }
    
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return { businessDays, weekends };
}

export function addDaysToDate(date: string, days: number): string {
  const targetDate = new Date(date);
  
  if (isNaN(targetDate.getTime())) {
    throw new Error('Invalid date format');
  }

  targetDate.setDate(targetDate.getDate() + days);
  return targetDate.toISOString().split('T')[0];
}

export function subtractDaysFromDate(date: string, days: number): string {
  return addDaysToDate(date, -days);
}

export function addBusinessDays(date: string, businessDays: number): string {
  const targetDate = new Date(date);
  
  if (isNaN(targetDate.getTime())) {
    throw new Error('Invalid date format');
  }

  let daysAdded = 0;
  let currentBusinessDays = 0;

  while (currentBusinessDays < businessDays) {
    daysAdded++;
    targetDate.setDate(targetDate.getDate() + 1);
    
    const dayOfWeek = targetDate.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      // Not weekend
      currentBusinessDays++;
    }
  }

  return targetDate.toISOString().split('T')[0];
}

export function getWeekNumber(date: string): number {
  const targetDate = new Date(date);
  
  if (isNaN(targetDate.getTime())) {
    throw new Error('Invalid date format');
  }

  // Copy date so don't modify original
  const d = new Date(Date.UTC(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate()));
  
  // Set to nearest Thursday: current date + 4 - current day number
  // Make Sunday's day number 7
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  
  // Get first day of year
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  
  // Calculate full weeks to nearest Thursday
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  
  return weekNo;
}

export function getDayOfYear(date: string): number {
  const targetDate = new Date(date);
  
  if (isNaN(targetDate.getTime())) {
    throw new Error('Invalid date format');
  }

  const start = new Date(targetDate.getFullYear(), 0, 0);
  const diff = targetDate.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  
  return Math.floor(diff / oneDay);
}

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

export function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

export function formatDuration(totalDays: number): string {
  if (totalDays === 0) return 'Same day';
  if (totalDays === 1) return '1 day';
  if (totalDays < 7) return `${totalDays} days`;
  if (totalDays < 30) {
    const weeks = Math.floor(totalDays / 7);
    const days = totalDays % 7;
    return `${weeks} week${weeks > 1 ? 's' : ''}${days > 0 ? ` and ${days} day${days > 1 ? 's' : ''}` : ''}`;
  }
  if (totalDays < 365) {
    const months = Math.floor(totalDays / 30.44);
    const days = Math.floor(totalDays % 30.44);
    return `${months} month${months > 1 ? 's' : ''}${days > 0 ? ` and ${days} day${days > 1 ? 's' : ''}` : ''}`;
  }
  
  const years = Math.floor(totalDays / 365.25);
  const remainingDays = Math.floor(totalDays % 365.25);
  const months = Math.floor(remainingDays / 30.44);
  
  let result = `${years} year${years > 1 ? 's' : ''}`;
  if (months > 0) {
    result += ` and ${months} month${months > 1 ? 's' : ''}`;
  }
  
  return result;
}

