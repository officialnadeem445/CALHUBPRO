import { TaxSlab } from '@/lib/finance-calculations';

// US Federal Tax Brackets for 2024 (Single Filers)
export const US_TAX_SLABS_2024: TaxSlab[] = [
  { min: 0, max: 11000, rate: 10 },
  { min: 11000, max: 44725, rate: 12 },
  { min: 44725, max: 95375, rate: 22 },
  { min: 95375, max: 182050, rate: 24 },
  { min: 182050, max: 231250, rate: 32 },
  { min: 231250, max: 578125, rate: 35 },
  { min: 578125, max: null, rate: 37 },
];

// UK Tax Brackets for 2024/25
export const UK_TAX_SLABS_2024: TaxSlab[] = [
  { min: 0, max: 12570, rate: 0 }, // Personal Allowance
  { min: 12570, max: 50270, rate: 20 }, // Basic Rate
  { min: 50270, max: 125140, rate: 40 }, // Higher Rate
  { min: 125140, max: null, rate: 45 }, // Additional Rate
];

// Canada Federal Tax Brackets for 2024
export const CANADA_TAX_SLABS_2024: TaxSlab[] = [
  { min: 0, max: 55867, rate: 15 },
  { min: 55867, max: 111733, rate: 20.5 },
  { min: 111733, max: 173205, rate: 26 },
  { min: 173205, max: 246752, rate: 29 },
  { min: 246752, max: null, rate: 33 },
];

// India Income Tax Slabs for 2024-25 (New Regime)
export const INDIA_TAX_SLABS_2024: TaxSlab[] = [
  { min: 0, max: 300000, rate: 0 },
  { min: 300000, max: 700000, rate: 5 },
  { min: 700000, max: 1000000, rate: 10 },
  { min: 1000000, max: 1200000, rate: 15 },
  { min: 1200000, max: 1500000, rate: 20 },
  { min: 1500000, max: null, rate: 30 },
];

export const TAX_SYSTEMS = [
  {
    id: 'us-2024',
    name: 'United States (2024)',
    currency: 'USD',
    slabs: US_TAX_SLABS_2024,
  },
  {
    id: 'uk-2024',
    name: 'United Kingdom (2024/25)',
    currency: 'GBP',
    slabs: UK_TAX_SLABS_2024,
  },
  {
    id: 'canada-2024',
    name: 'Canada Federal (2024)',
    currency: 'CAD',
    slabs: CANADA_TAX_SLABS_2024,
  },
  {
    id: 'india-2024',
    name: 'India New Regime (2024-25)',
    currency: 'INR',
    slabs: INDIA_TAX_SLABS_2024,
  },
];

export function getTaxSystem(id: string) {
  return TAX_SYSTEMS.find(system => system.id === id) || TAX_SYSTEMS[0];
}

