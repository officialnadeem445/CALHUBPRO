export interface Calculator {
  id: string;
  title: string;
  description: string;
  category: string;
  keywords: string[];
  path: string;
  icon: string;
}

export const calculators: Calculator[] = [
  // Basic Calculators
  {
    id: 'age',
    title: 'Age Calculator',
    description: 'Calculate your exact age in years, months, and days',
    category: 'basic',
    keywords: ['age', 'birthday', 'years', 'months', 'days'],
    path: '/calculators/age',
    icon: 'Calendar',
  },
  {
    id: 'bmi',
    title: 'BMI Calculator',
    description: 'Calculate your Body Mass Index and health status',
    category: 'basic',
    keywords: ['bmi', 'body mass index', 'weight', 'height', 'health'],
    path: '/calculators/bmi',
    icon: 'Activity',
  },
  {
    id: 'percentage',
    title: 'Percentage Calculator',
    description: 'Calculate percentages, percentage change, and more',
    category: 'basic',
    keywords: ['percentage', 'percent', 'change', 'increase', 'decrease'],
    path: '/calculators/percentage',
    icon: 'Percent',
  },
  {
    id: 'scientific',
    title: 'Scientific Calculator',
    description: 'Advanced calculator with scientific functions',
    category: 'basic',
    keywords: ['scientific', 'calculator', 'math', 'functions', 'trigonometry'],
    path: '/calculators/scientific',
    icon: 'Calculator',
  },

  // Education Calculators
  {
    id: 'gpa',
    title: 'GPA Calculator',
    description: 'Calculate your Grade Point Average with custom weights',
    category: 'education',
    keywords: ['gpa', 'grade point average', 'cgpa', 'grades', 'student'],
    path: '/calculators/gpa',
    icon: 'GraduationCap',
  },
  {
    id: 'grade',
    title: 'Grade Calculator',
    description: 'Calculate final grades and required scores',
    category: 'education',
    keywords: ['grade', 'final grade', 'score', 'exam', 'student'],
    path: '/calculators/grade',
    icon: 'BookOpen',
  },
  {
    id: 'marks-percentage',
    title: 'Marks Percentage Calculator',
    description: 'Calculate percentage from marks and total marks',
    category: 'education',
    keywords: ['marks', 'percentage', 'score', 'exam', 'result'],
    path: '/calculators/marks-percentage',
    icon: 'FileText',
  },
  {
    id: 'interest',
    title: 'Interest Calculator',
    description: 'Calculate simple and compound interest',
    category: 'education',
    keywords: ['interest', 'compound', 'simple', 'investment', 'savings'],
    path: '/calculators/interest',
    icon: 'TrendingUp',
  },

  // Finance Calculators
  {
    id: 'loan-emi',
    title: 'Loan EMI Calculator',
    description: 'Calculate loan EMI with amortization schedule',
    category: 'finance',
    keywords: ['loan', 'emi', 'mortgage', 'amortization', 'payment'],
    path: '/calculators/loan-emi',
    icon: 'CreditCard',
  },
  {
    id: 'profit-margin',
    title: 'Profit Margin Calculator',
    description: 'Calculate profit margin and markup',
    category: 'finance',
    keywords: ['profit', 'margin', 'markup', 'business', 'revenue'],
    path: '/calculators/profit-margin',
    icon: 'DollarSign',
  },
  {
    id: 'currency-converter',
    title: 'Currency Converter',
    description: 'Convert between different currencies with live rates',
    category: 'finance',
    keywords: ['currency', 'converter', 'exchange', 'rate', 'money'],
    path: '/calculators/currency-converter',
    icon: 'ArrowLeftRight',
  },
  {
    id: 'tax',
    title: 'Tax Calculator',
    description: 'Calculate income tax with progressive brackets',
    category: 'finance',
    keywords: ['tax', 'income tax', 'calculator', 'brackets', 'deduction'],
    path: '/calculators/tax',
    icon: 'Receipt',
  },

  // Health & Lifestyle Calculators
  {
    id: 'calorie-needs',
    title: 'Calorie Needs Calculator',
    description: 'Calculate BMR and TDEE for daily calorie needs',
    category: 'health',
    keywords: ['calorie', 'bmr', 'tdee', 'metabolism', 'diet'],
    path: '/calculators/calorie-needs',
    icon: 'Zap',
  },
  {
    id: 'sleep-calculator',
    title: 'Sleep Calculator',
    description: 'Calculate optimal bedtime and wake-up times',
    category: 'health',
    keywords: ['sleep', 'bedtime', 'wake up', 'cycles', 'rest'],
    path: '/calculators/sleep-calculator',
    icon: 'Moon',
  },

  // Date & Time Calculators
  {
    id: 'date-difference',
    title: 'Date Difference Calculator',
    description: 'Calculate the difference between two dates',
    category: 'datetime',
    keywords: ['date', 'difference', 'days', 'between', 'duration'],
    path: '/calculators/date-difference',
    icon: 'Calendar',
  },

  // Fun / Utility Calculators
  {
    id: 'tip-calculator',
    title: 'Tip Calculator',
    description: 'Calculate tips and split bills easily',
    category: 'utility',
    keywords: ['tip', 'gratuity', 'bill', 'split', 'restaurant'],
    path: '/calculators/tip-calculator',
    icon: 'Receipt',
  },
  {
    id: 'unit-converter',
    title: 'Unit Converter',
    description: 'Convert between different units of measurement',
    category: 'utility',
    keywords: ['unit', 'converter', 'metric', 'imperial', 'measurement'],
    path: '/calculators/unit-converter',
    icon: 'ArrowLeftRight',
  },
  {
    id: 'password-generator',
    title: 'Password Generator',
    description: 'Generate secure passwords with customizable options',
    category: 'utility',
    keywords: ['password', 'generator', 'secure', 'random', 'strength'],
    path: '/calculators/password-generator',
    icon: 'Shield',
  },
];

export const categories = [
  { id: 'basic', name: 'Basic', icon: 'Calculator' },
  { id: 'education', name: 'Education', icon: 'GraduationCap' },
  { id: 'finance', name: 'Finance', icon: 'DollarSign' },
  { id: 'health', name: 'Health & Lifestyle', icon: 'Heart' },
  { id: 'datetime', name: 'Date & Time', icon: 'Clock' },
  { id: 'utility', name: 'Fun & Utility', icon: 'Smile' },
];

export function getCalculatorsByCategory(category: string) {
  return calculators.filter((calc) => calc.category === category);
}

export function searchCalculators(query: string) {
  const lowercaseQuery = query.toLowerCase();
  return calculators.filter(
    (calc) =>
      calc.title.toLowerCase().includes(lowercaseQuery) ||
      calc.description.toLowerCase().includes(lowercaseQuery) ||
      calc.keywords.some((keyword) =>
        keyword.toLowerCase().includes(lowercaseQuery)
      )
  );
}

